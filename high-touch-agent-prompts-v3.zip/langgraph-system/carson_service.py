"""
Carson Service — Flask HTTP server for the multi-agent system.

Endpoints:
  GET  /          → Health check
  POST /ask       → Main query endpoint
  GET  /health    → Detailed health (LLM credentials, RAG status)
  POST /confirm   → Confirm a pending write operation
  POST /ingest    → Trigger RAG knowledge base ingestion
"""
import os
import sys
import json
import time
import logging
from collections import deque
from pathlib import Path

from flask import Flask, request, jsonify

# Add parent to path for imports
sys.path.insert(0, str(Path(__file__).parent))

from carson_agents.config import load_config, get_llm_config, get_rag_config
from carson_agents.workflow import get_workflow
from carson_agents.llm import create_llm_client

# Logging
logging.basicConfig(
    level=os.environ.get("LOG_LEVEL", "INFO"),
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s"
)
logger = logging.getLogger("carson.service")

app = Flask(__name__)

# Conversation memory (session-level, in-memory)
conversation_history = deque(maxlen=int(os.environ.get("CARSON_HISTORY_SIZE", "10")))

# Pending confirmations
pending_confirmations = {}


@app.route("/", methods=["GET"])
def index():
    return jsonify({
        "service": "Carson AI Butler",
        "version": "2.0.0",
        "status": "operational",
        "endpoints": ["/ask", "/health", "/confirm", "/ingest"]
    })


@app.route("/ask", methods=["POST"])
def ask():
    """Main query endpoint — routes to appropriate agent."""
    start = time.time()

    data = request.json or {}
    user_request = data.get("request", "").strip()

    if not user_request:
        return jsonify({"error": "Empty request. Provide 'request' in JSON body."}), 400

    logger.info(f"[REQUEST] {user_request[:100]}")

    try:
        # Build context from conversation history
        context_parts = []
        for h in conversation_history:
            context_parts.append(f"User: {h['q']}")
            context_parts.append(f"Carson: {h['a'][:200]}")
        conversation_context = "\n".join(context_parts)

        # Prepend conversation context if available
        full_request = user_request
        if conversation_context:
            full_request = (
                f"Previous conversation context:\n{conversation_context}\n\n"
                f"Current request: {user_request}"
            )

        # Run the workflow
        workflow = get_workflow()
        initial_state = {
            "user_request": full_request,
            "intent": None,
            "current_agent": None,
            "messages": [],
            "context": data.get("context", {}),
            "agent_response": None,
            "final_response": None,
            "confirmation_required": None,
            "confirmed": None,
        }

        result = workflow.invoke(initial_state)

        elapsed = time.time() - start
        agent = result.get("current_agent", "unknown")
        logger.info(f"[RESPONSE] agent={agent} time={elapsed:.2f}s")

        # Check if confirmation is needed
        if result.get("confirmation_required") and not result.get("confirmed"):
            # Store pending confirmation
            confirm_id = f"confirm_{int(time.time())}"
            pending_confirmations[confirm_id] = {
                "state": result,
                "original_request": user_request,
            }
            return jsonify({
                "confirmation_required": True,
                "confirm_id": confirm_id,
                "action": result["confirmation_required"],
                "message": f"Carson requires confirmation: {result['confirmation_required']}",
                "agent": agent,
            })

        # Store in conversation history
        final = result.get("final_response", result.get("agent_response", ""))
        conversation_history.append({"q": user_request, "a": final})

        return jsonify({
            "response": final,
            "agent": agent,
            "intent": result.get("intent"),
            "tool_results": result.get("tool_results_collected", []),
            "elapsed_seconds": round(elapsed, 2),
        })

    except Exception as e:
        err = str(e)
        logger.error(f"[ERROR] {err}")

        if "InvalidClientTokenId" in err or "ExpiredTokenException" in err or "Expecting value" in err:
            return jsonify({
                "error": "AWS credentials expired. Refresh via DevShell and restart Carson.",
                "action_required": "Run: DevShell → pci aws login → restart carson_service.py"
            }), 401

        return jsonify({"error": f"Internal error: {err}"}), 500


@app.route("/confirm", methods=["POST"])
def confirm():
    """Confirm a pending write operation."""
    data = request.json or {}
    confirm_id = data.get("confirm_id", "")
    confirmed = data.get("confirmed", False)

    if confirm_id not in pending_confirmations:
        return jsonify({"error": f"Unknown confirmation ID: {confirm_id}"}), 404

    pending = pending_confirmations.pop(confirm_id)

    if not confirmed:
        return jsonify({"response": "Very well, Sir/Madam. The operation has been cancelled."})

    # Resume workflow with confirmation
    state = pending["state"]
    state["confirmed"] = True

    try:
        workflow = get_workflow()
        result = workflow.invoke(state)

        final = result.get("final_response", result.get("agent_response", ""))
        conversation_history.append({"q": pending["original_request"], "a": final})

        return jsonify({
            "response": final,
            "agent": result.get("current_agent"),
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/health", methods=["GET"])
def health():
    """Detailed health check — tests LLM credentials and RAG status."""
    status = {"service": "ok", "llm": "unknown", "rag": "unknown"}

    try:
        llm = create_llm_client()
        status["llm"] = "ok" if llm.check_credentials() else "credentials_expired"
    except Exception as e:
        status["llm"] = f"error: {str(e)[:100]}"

    try:
        rag_config = get_rag_config()
        if rag_config.get("enabled"):
            from carson_agents.rag.knowledge_base import CarsonKnowledgeBase
            kb = CarsonKnowledgeBase(persist_dir=rag_config.get("persist_dir", "./carson_kb"))
            collections = kb.list_collections()
            counts = {c: kb.get_collection_count(c) for c in collections}
            status["rag"] = {"enabled": True, "collections": counts}
        else:
            status["rag"] = {"enabled": False}
    except Exception as e:
        status["rag"] = f"error: {str(e)[:100]}"

    return jsonify(status)


@app.route("/ingest", methods=["POST"])
def ingest():
    """Trigger RAG knowledge base ingestion."""
    try:
        rag_config = get_rag_config()
        if not rag_config.get("enabled"):
            return jsonify({"error": "RAG is not enabled in config.yaml"}), 400

        from carson_agents.rag.knowledge_base import CarsonKnowledgeBase
        kb = CarsonKnowledgeBase(persist_dir=rag_config.get("persist_dir", "./carson_kb"))

        data = request.json or {}
        repo_path = data.get("repo_path", ".")
        collection = data.get("collection", "repo_code")

        count = kb.ingest_repo(repo_path, collection_name=collection)
        return jsonify({"success": True, "chunks_ingested": count, "collection": collection})

    except Exception as e:
        return jsonify({"error": str(e)}), 500


def main():
    """Start the Carson service."""
    try:
        config = load_config()
    except FileNotFoundError as e:
        print(f"\n{'='*60}")
        print(f"  Carson Configuration Not Found")
        print(f"  {e}")
        print(f"{'='*60}\n")
        sys.exit(1)

    # Initialize LLM client early to catch credential errors
    try:
        llm = create_llm_client()
        logger.info(f"LLM provider: {config.get('llm', {}).get('provider', 'unknown')}")
    except Exception as e:
        logger.warning(f"LLM init warning: {e}")

    port = int(os.environ.get("CARSON_PORT", config.get("service", {}).get("port", 8765)))
    host = os.environ.get("CARSON_HOST", config.get("service", {}).get("host", "0.0.0.0"))
    debug = os.environ.get("CARSON_DEBUG", "false").lower() == "true"

    print(f"\n{'='*60}")
    print(f"  Carson AI Butler v2.0.0")
    print(f"  Listening on {host}:{port}")
    print(f"  LLM Provider: {config.get('llm', {}).get('provider', 'bedrock')}")
    print(f"  RAG Enabled: {config.get('rag', {}).get('enabled', False)}")
    print(f"{'='*60}\n")

    app.run(host=host, port=port, debug=debug)


if __name__ == "__main__":
    main()
