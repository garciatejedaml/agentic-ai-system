"""
Carson Configuration — Loads team-specific settings from config.yaml.

This is the heart of the generic onboarding system. Each team fills in
their own config.yaml to customize Carson for their environment.
"""
import os
import yaml
from pathlib import Path
from typing import Dict, Any, Optional


_config: Optional[Dict[str, Any]] = None


def load_config(config_path: Optional[str] = None) -> Dict[str, Any]:
    """Load configuration from YAML file."""
    global _config
    if _config is not None and config_path is None:
        return _config

    if config_path is None:
        config_path = os.environ.get(
            "CARSON_CONFIG",
            str(Path(__file__).parent.parent / "config.yaml")
        )

    path = Path(config_path)
    if not path.exists():
        raise FileNotFoundError(
            f"Config not found: {path}\n"
            f"Run 'python scripts/onboarding.py' to create one, "
            f"or copy config_template.yaml to config.yaml"
        )

    with open(path, encoding="utf-8") as f:
        _config = yaml.safe_load(f)

    return _config


def get_config() -> Dict[str, Any]:
    """Get the loaded config (loads if not yet loaded)."""
    return load_config()


def get_llm_config() -> Dict[str, Any]:
    """Get LLM provider configuration."""
    cfg = get_config()
    return cfg.get("llm", {})


def get_team_config() -> Dict[str, Any]:
    """Get team-specific configuration."""
    cfg = get_config()
    return cfg.get("team", {})


def get_agent_config(agent_name: str) -> Dict[str, Any]:
    """Get configuration for a specific agent."""
    cfg = get_config()
    agents = cfg.get("agents", {})
    return agents.get(agent_name, {"enabled": False})


def get_mcp_config() -> Dict[str, Any]:
    """Get MCP server configuration."""
    cfg = get_config()
    return cfg.get("mcp_servers", {})


def get_rag_config() -> Dict[str, Any]:
    """Get RAG/ChromaDB configuration."""
    cfg = get_config()
    return cfg.get("rag", {"enabled": False})


def get_bitbucket_projects() -> list:
    """
    Get the list of Bitbucket projects for this team.
    Returns list of dicts: [{"key": "PROJ", "description": "...", "repositories": [...]}]
    Returns empty list if team has no Bitbucket projects.
    """
    team = get_team_config()
    projects = team.get("bitbucket_projects", [])
    if projects is None:
        return []
    # Backwards compat: if old single-project format exists
    if not projects and team.get("bitbucket_project"):
        return [{"key": team["bitbucket_project"], "description": "", "repositories": []}]
    return projects


def get_default_bitbucket_project() -> str:
    """Get the default Bitbucket project key."""
    team = get_team_config()
    default = team.get("default_bitbucket_project", "")
    if not default:
        projects = get_bitbucket_projects()
        if projects:
            default = projects[0].get("key", "")
    return default


def get_all_bitbucket_project_keys() -> list:
    """Get just the project keys as a flat list."""
    return [p.get("key", "") for p in get_bitbucket_projects()]


def get_deploy_config() -> Dict[str, Any]:
    """Get deploy agent configuration (repo mappings, pipeline mappings)."""
    agent_cfg = get_agent_config("deploy")
    return {
        "repo_to_app_map": agent_cfg.get("repo_to_app_map", {}),
        "terraform_app_suffix": agent_cfg.get("terraform_app_suffix", ""),
        "branch_to_pipeline": agent_cfg.get("branch_to_pipeline", {}),
    }


def get_build_config() -> Dict[str, Any]:
    """Get build agent configuration (job format, etc.)."""
    agent_cfg = get_agent_config("build")
    return {
        "job_format": agent_cfg.get("job_format", "{project}/{repo}/{branch}"),
    }
