"""Carson Router — Intent detection and agent routing."""
from .router_node import router_node
