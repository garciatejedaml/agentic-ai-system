"""
Carson Router Node — LLM-based intent detection and agent routing.

Analyzes user requests and delegates to exactly ONE specialist agent.
"""
import json
import logging
from typing import Dict, Any

from ..agent_state import CarsonState
from ..llm import get_llm_client

logger = logging.getLogger("carson.router")


ROUTER_SYSTEM_PROMPT = """You are Carson, the distinguished AI butler and concierge.

## Your Role as Router
You analyze user requests and delegate to EXACTLY ONE specialist per request.
If the request is ambiguous, ask a clarifying question rather than guessing.

## Available Specialists
| Agent ID | Name | Specialty | Trigger Keywords |
|----------|------|-----------|-----------------|
| jira | Comptroller Jira | Jira ticket operations | ticket, Jira, sprint, story, epic, backlog, AHTW-, CREDITTECH- |
| git | Mr. Brandson | Git/Bitbucket operations (multi-project) | commit, PR, branch, merge, code review, pull request, push, repo |
| build | M. Jenkins | Build/CI pipeline | build, pipeline, CI, Jenkins, compile, test results |
| deploy | Madame Spinnaker | Deployments/Releases | deploy, release, rollback, Spinnaker, environment, prod, staging |
| terraform | M. Terraform Inspector | Infrastructure/AWS/TFE | terraform, ECS, EKS, RDS, ALB, infrastructure, AWS resource, workspace, plan, apply |
| docs | Secretary Confluence | Documentation | confluence, wiki, documentation, page, search docs, knowledge base |
| general | Inspector Clouseau | General knowledge | AMPS, AWS concepts, team processes, how does, what is, explain |

## Routing Rules (CRITICAL)
1. Route to EXACTLY ONE agent per request
2. If request mentions both Jira AND Git (e.g., "commit for ticket AHTW-123"):
   -> Route to jira FIRST to get context
3. NEVER route write/mutating operations without noting this to the agent
4. For read-only queries (search, list, status, get): route immediately
5. If uncertain which agent to use: route to "general"
6. For general knowledge questions about AMPS, AWS, team processes: route to "general"

## Response Format
You MUST respond with ONLY a valid JSON object, nothing else:
{"agent": "<agent_id>", "reasoning": "<one sentence why>"}

Valid agent IDs: jira, git, build, deploy, terraform, docs, general
"""


ROUTER_TOOLS = [
    {
        "name": "route_to_agent",
        "description": "Route the user's request to the appropriate specialist agent",
        "input_schema": {
            "type": "object",
            "properties": {
                "agent": {
                    "type": "string",
                    "description": "Agent ID to route to: jira, git, build, deploy, terraform, docs, general",
                    "enum": ["jira", "git", "build", "deploy", "terraform", "docs", "general"]
                },
                "reasoning": {
                    "type": "string",
                    "description": "Brief explanation of why this agent was chosen"
                }
            },
            "required": ["agent", "reasoning"]
        }
    }
]

# Agent display names for Carson's acknowledgment
AGENT_NAMES = {
    "jira": "Comptroller Jira",
    "git": "Mr. Brandson",
    "build": "M. Jenkins",
    "deploy": "Madame Spinnaker",
    "terraform": "M. Terraform Inspector",
    "docs": "Secretary Confluence",
    "general": "Inspector Clouseau",
}


def router_node(state: CarsonState) -> CarsonState:
    """
    Route user request to the appropriate specialist agent.

    Returns updated state with 'intent' set to the agent ID.
    """
    user_request = state.get("user_request", "")
    logger.info(f"[router] Routing: {user_request[:100]}")

    try:
        llm = get_llm_client()

        response = llm.converse(
            messages=[{"role": "user", "content": user_request}],
            system=[{"text": ROUTER_SYSTEM_PROMPT}],
            tools=ROUTER_TOOLS,
        )

        stop_reason = response.get("stop_reason", "end_turn")
        content = response.get("content", [])

        agent_id = "general"
        reasoning = ""

        if stop_reason == "tool_use":
            # LLM used the routing tool
            for block in content:
                if block.get("type") == "tool_use" and block.get("name") == "route_to_agent":
                    tool_input = block.get("input", {})
                    agent_id = tool_input.get("agent", "general")
                    reasoning = tool_input.get("reasoning", "")
                    break

        elif stop_reason == "end_turn":
            # Try to parse JSON from text response (fallback)
            for block in content:
                if block.get("type") == "text":
                    text = block.get("text", "").strip()
                    try:
                        parsed = json.loads(text)
                        agent_id = parsed.get("agent", "general")
                        reasoning = parsed.get("reasoning", "")
                    except json.JSONDecodeError:
                        # Try keyword-based routing as last resort
                        agent_id = _keyword_route(user_request)
                        reasoning = "Keyword-based fallback routing"
                    break

        # Validate agent ID
        if agent_id not in AGENT_NAMES:
            logger.warning(f"[router] Unknown agent '{agent_id}', defaulting to general")
            agent_id = "general"

        agent_display = AGENT_NAMES[agent_id]
        logger.info(f"[router] Routed to {agent_id} ({agent_display}): {reasoning}")

        return {
            **state,
            "intent": agent_id,
            "current_agent": agent_id,
        }

    except Exception as e:
        logger.error(f"[router] Routing error: {e}. Falling back to keyword routing.")
        agent_id = _keyword_route(user_request)
        return {
            **state,
            "intent": agent_id,
            "current_agent": agent_id,
        }


def _keyword_route(request: str) -> str:
    """Fallback keyword-based routing when LLM routing fails."""
    req = request.lower()

    keyword_map = {
        "jira": ["jira", "ticket", "sprint", "story", "epic", "backlog", "ahtw-", "credittech-"],
        "git": ["git", "commit", "branch", "merge", "pull request", "pr ", "bitbucket", "repo"],
        "build": ["build", "jenkins", "pipeline", "ci/cd", "compile", "test result"],
        "deploy": ["deploy", "spinnaker", "release", "rollback", "staging", "production"],
        "terraform": ["terraform", "ecs", "eks", "rds", "alb", "infrastructure", "aws resource", "workspace"],
        "docs": ["confluence", "wiki", "documentation", "page", "docs"],
    }

    for agent_id, keywords in keyword_map.items():
        if any(kw in req for kw in keywords):
            return agent_id

    return "general"
