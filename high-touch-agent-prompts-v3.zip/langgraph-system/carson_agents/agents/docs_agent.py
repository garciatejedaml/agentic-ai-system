"""
Secretary Confluence — Documentation Architect & Confluence Expert.

Handles: page search, reading, creation, updates, space management,
labels, attachments, page hierarchy, and professional documentation templates.
"""
import os
import sys
import re
import json
import logging
from pathlib import Path
from typing import Dict, Any

from .base_agent import BaseAgent, make_agent_node

logger = logging.getLogger("carson.agents.docs")

MCP_BASE = Path(__file__).parent.parent.parent.parent / "mcp-servers"


DOCS_TOOLS = [
    # --- Core Page Operations ---
    {
        "name": "search_pages",
        "description": "Search for Confluence pages by text query or CQL. Supports: text search, label filter, space filter, date ranges",
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search text or CQL query (e.g., 'text ~ \"runbook\" AND space = \"AHTW\"')"},
                "space_key": {"type": "string", "description": "Confluence space key (optional, narrows search)"},
                "limit": {"type": "number", "description": "Max results (default 10)"},
                "label": {"type": "string", "description": "Filter by label (optional)"}
            },
            "required": ["query"]
        }
    },
    {
        "name": "get_page",
        "description": "Get full content of a Confluence page by ID. Returns body in storage format (HTML).",
        "input_schema": {
            "type": "object",
            "properties": {
                "page_id": {"type": "string", "description": "Confluence page ID"},
                "expand": {"type": "string", "description": "Fields to expand (default: body.storage,version,ancestors)"}
            },
            "required": ["page_id"]
        }
    },
    {
        "name": "get_page_by_title",
        "description": "Find a Confluence page by its exact title within a space",
        "input_schema": {
            "type": "object",
            "properties": {
                "space_key": {"type": "string", "description": "Confluence space key"},
                "title": {"type": "string", "description": "Exact page title"}
            },
            "required": ["space_key", "title"]
        }
    },
    {
        "name": "get_page_children",
        "description": "List child pages of a parent page. Useful for navigating page hierarchy.",
        "input_schema": {
            "type": "object",
            "properties": {
                "page_id": {"type": "string", "description": "Parent page ID"},
                "limit": {"type": "number", "description": "Max results (default 25)"},
                "expand": {"type": "string", "description": "Fields to expand (default: version)"}
            },
            "required": ["page_id"]
        }
    },
    {
        "name": "get_page_history",
        "description": "Get version history for a page — who changed what and when",
        "input_schema": {
            "type": "object",
            "properties": {
                "page_id": {"type": "string", "description": "Confluence page ID"},
                "limit": {"type": "number", "description": "Max versions to return (default 10)"}
            },
            "required": ["page_id"]
        }
    },
    {
        "name": "create_page",
        "description": "Create a new Confluence page with storage format content. WRITE OPERATION.",
        "input_schema": {
            "type": "object",
            "properties": {
                "space_key": {"type": "string", "description": "Confluence space key"},
                "title": {"type": "string", "description": "Page title"},
                "content": {"type": "string", "description": "Page content in Confluence storage format (XHTML)"},
                "parent_id": {"type": "string", "description": "Parent page ID (optional — placed at space root if omitted)"},
                "labels": {"type": "array", "items": {"type": "string"}, "description": "Labels to add (e.g., ['runbook', 'production'])"}
            },
            "required": ["space_key", "title", "content"]
        }
    },
    {
        "name": "update_page",
        "description": "Update an existing Confluence page. WRITE OPERATION. Increments version automatically.",
        "input_schema": {
            "type": "object",
            "properties": {
                "page_id": {"type": "string", "description": "Confluence page ID to update"},
                "title": {"type": "string", "description": "New title (optional, keeps current if omitted)"},
                "content": {"type": "string", "description": "New content in Confluence storage format"},
                "version_comment": {"type": "string", "description": "Version comment explaining the change"}
            },
            "required": ["page_id", "content"]
        }
    },
    {
        "name": "move_page",
        "description": "Move a page to a new parent or space. WRITE OPERATION.",
        "input_schema": {
            "type": "object",
            "properties": {
                "page_id": {"type": "string", "description": "Page ID to move"},
                "target_parent_id": {"type": "string", "description": "New parent page ID"},
                "target_space_key": {"type": "string", "description": "Target space key (optional, same space if omitted)"}
            },
            "required": ["page_id", "target_parent_id"]
        }
    },
    # --- Space & Structure ---
    {
        "name": "get_spaces",
        "description": "List all accessible Confluence spaces",
        "input_schema": {
            "type": "object",
            "properties": {
                "limit": {"type": "number", "description": "Max results (default 25)"},
                "type": {"type": "string", "description": "Filter: global, personal (default: all)"}
            }
        }
    },
    {
        "name": "get_space",
        "description": "Get details of a specific Confluence space (key, name, homepage)",
        "input_schema": {
            "type": "object",
            "properties": {
                "space_key": {"type": "string", "description": "Confluence space key"}
            },
            "required": ["space_key"]
        }
    },
    {
        "name": "get_space_content",
        "description": "List all pages in a space (paginated). Good for auditing.",
        "input_schema": {
            "type": "object",
            "properties": {
                "space_key": {"type": "string", "description": "Confluence space key"},
                "type": {"type": "string", "description": "Content type: page, blogpost (default: page)"},
                "limit": {"type": "number", "description": "Max results (default 25)"},
                "start": {"type": "number", "description": "Offset for pagination"}
            },
            "required": ["space_key"]
        }
    },
    # --- Labels ---
    {
        "name": "get_labels",
        "description": "Get labels on a Confluence page",
        "input_schema": {
            "type": "object",
            "properties": {
                "page_id": {"type": "string", "description": "Page ID"}
            },
            "required": ["page_id"]
        }
    },
    {
        "name": "add_label",
        "description": "Add labels to a Confluence page. WRITE OPERATION.",
        "input_schema": {
            "type": "object",
            "properties": {
                "page_id": {"type": "string", "description": "Page ID"},
                "labels": {"type": "array", "items": {"type": "string"}, "description": "Labels to add"}
            },
            "required": ["page_id", "labels"]
        }
    },
    # --- Attachments ---
    {
        "name": "get_attachments",
        "description": "List attachments on a Confluence page",
        "input_schema": {
            "type": "object",
            "properties": {
                "page_id": {"type": "string", "description": "Page ID"}
            },
            "required": ["page_id"]
        }
    },
]


class DocsAgent(BaseAgent):
    AGENT_NAME = "docs"
    TOOLS = DOCS_TOOLS

    SYSTEM_PROMPT = """You are Secretary Confluence, a meticulous Documentation Architect and Confluence expert
within the Carson multi-agent system at JPMorgan Chase.

## Personality
- Organized, thorough, encyclopedic — like a master archivist who studied at the Society for Technical Communication
- Address users as "Sir" or "Madam"
- Use archival metaphors: "consulting the archives" (searching), "filing the record"
  (creating pages), "updating the ledger" (editing), "the stacks" (space hierarchy),
  "cataloguing" (organizing), "cross-referencing" (linking)

## Capabilities
You manage ALL Confluence documentation operations: searching, reading, creating,
updating, moving pages, managing labels, navigating space hierarchy, and crafting
professional documentation from templates.

## Documentation Expertise

### Professional Templates
You have mastery of these document types:
- **Runbooks**: Operational procedures with prerequisites, steps, verification, rollback, escalation
- **ADRs**: Architecture Decision Records with context, decision, alternatives, consequences
- **Sprint Retrospectives**: Metrics, what went well, improvements, action items
- **API Documentation**: Endpoints, request/response examples, parameter tables
- **Onboarding Guides**: Setup steps, access requests, tool configuration

### Writing Standards
- Active voice: "Deploy the service" not "The service should be deployed"
- Imperative mood for procedures: "Run the command" not "You should run"
- Include code examples for every technical concept
- Add status macros for living documents (Draft, In Review, Approved, Deprecated)
- Always start pages with a 2-3 sentence overview
- Use Table of Contents macro for pages with 3+ headings
- End with "Related Pages" section

### Information Architecture
- Organize pages hierarchically: Getting Started → Architecture → Runbooks → API Reference → Team → Archive
- NEVER delete pages — label as "archived" and move to Archive section
- Use labels consistently: runbook, adr, api-docs, onboarding, sprint-{number}, archived, needs-review, amps

## CQL Search Mastery
- Text: `text ~ "deployment" AND space = "AHTW"`
- Label: `label = "runbook" AND space = "AHTW"`
- Recent: `lastModified > now("-7d") AND space = "AHTW"`
- Stale: `lastModified < now("-90d") AND label != "archived"`
- By author: `contributor = "F702937" AND lastModified > now("-30d")`
- Hierarchy: `ancestor = "PAGE_ID"` for all descendants

## Engineers Docs Integration
The team has an `engineers-docs` MCP server for internal JPMC documentation.
If Confluence doesn't have what's needed, suggest checking engineers-docs.

## AMPS Documentation Patterns
When documenting AMPS workflow changes:
- Include maintenance schedule (daily/weekly/none)
- Reference topic names from topics.xml
- Document action patterns from actions.xml
- Include repository and branch information
- Use code macros for XML snippets
- Add 'amps' label

## Safety Rules
- READ operations: proceed immediately
- WRITE operations: ALWAYS confirm with user first — show what will change
- DELETE: require DOUBLE confirmation — label as "archived" instead
- For updates: show a diff summary BEFORE confirming
"""

    def execute_tool(self, tool_name: str, tool_input: dict) -> str:
        """Execute a Confluence/Docs MCP tool."""
        confluence_path = MCP_BASE / "confluence-mcp-server-python"
        if str(confluence_path) not in sys.path:
            sys.path.insert(0, str(confluence_path))

        try:
            from source.confluence_client import get_confluence_client
            client = get_confluence_client()

            if tool_name == "search_pages":
                query = tool_input["query"]
                space = tool_input.get("space_key", "")
                limit = tool_input.get("limit", 10)
                label = tool_input.get("label", "")

                # Build CQL — if query already looks like CQL, use directly
                if any(kw in query.lower() for kw in ["text ~", "title ~", "label =", "space =", "type ="]):
                    cql = query
                else:
                    cql = f'text ~ "{query}"'
                    if space:
                        cql += f' AND space = "{space}"'
                    if label:
                        cql += f' AND label = "{label}"'

                pages = client.cql(cql, limit=limit)
                result = {
                    "query": cql,
                    "pages": [
                        {
                            "id": p.id,
                            "title": p.title,
                            "space": getattr(p.space, 'key', '') if hasattr(p, 'space') else '',
                            "url": getattr(p._links, 'webui', '') if hasattr(p, '_links') else '',
                            "lastModified": str(getattr(p, 'lastModified', '')),
                        }
                        for p in pages.get("results", [])
                    ],
                    "total": pages.get("totalSize", len(pages.get("results", [])))
                }

            elif tool_name == "get_page":
                page_id = tool_input["page_id"]
                expand = tool_input.get("expand", "body.storage,version,ancestors")
                page = client.get_page(page_id, expand=expand)
                content = ""
                if hasattr(page, 'body') and hasattr(page.body, 'storage'):
                    content = page.body.storage.value
                # Strip HTML for readability, truncate
                text = re.sub(r'<[^>]+>', '', content)[:3000]
                result = {
                    "id": page_id,
                    "title": page.title,
                    "version": getattr(page.version, 'number', None) if hasattr(page, 'version') else None,
                    "content": text,
                    "content_length": len(content),
                }

            elif tool_name == "get_page_by_title":
                space = tool_input["space_key"]
                title = tool_input["title"]
                page = client.get_page_by_title(space, title)
                if page:
                    result = {"id": page.id, "title": page.title, "space": space}
                else:
                    result = {"error": f"No page found with title '{title}' in space {space}"}

            elif tool_name == "get_page_children":
                page_id = tool_input["page_id"]
                limit = tool_input.get("limit", 25)
                expand = tool_input.get("expand", "version")
                children = client.get_child_pages(page_id, limit=limit, expand=expand)
                result = {
                    "parent_id": page_id,
                    "children": [
                        {"id": c.id, "title": c.title}
                        for c in children
                    ],
                    "total": len(children)
                }

            elif tool_name == "get_page_history":
                page_id = tool_input["page_id"]
                limit = tool_input.get("limit", 10)
                history = client.get_content_history(page_id)
                result = {
                    "page_id": page_id,
                    "latest_version": getattr(history, 'lastUpdated', {}).get('number', None) if isinstance(history, dict) else None,
                    "created_by": str(getattr(history, 'createdBy', '')),
                    "created_date": str(getattr(history, 'createdDate', '')),
                }

            elif tool_name == "create_page":
                space = tool_input["space_key"]
                title = tool_input["title"]
                content = tool_input["content"]
                parent = tool_input.get("parent_id")
                labels = tool_input.get("labels", [])

                page = client.create_page(space, title, content, parent_id=parent)

                # Add labels if provided
                if labels and hasattr(page, 'id'):
                    try:
                        label_data = [{"prefix": "global", "name": l} for l in labels]
                        client.set_page_label(page.id, label_data)
                    except Exception as le:
                        logger.warning(f"Created page but failed to add labels: {le}")

                result = {
                    "success": True,
                    "id": page.id,
                    "title": title,
                    "space": space,
                    "message": f"Page '{title}' created in {space}",
                    "labels": labels,
                }

            elif tool_name == "update_page":
                page_id = tool_input["page_id"]
                content = tool_input["content"]
                title = tool_input.get("title")
                version_comment = tool_input.get("version_comment", "")

                page = client.update_page(page_id, title=title, body=content)
                result = {
                    "success": True,
                    "id": page_id,
                    "message": f"Page updated successfully",
                    "version_comment": version_comment,
                }

            elif tool_name == "move_page":
                page_id = tool_input["page_id"]
                target_parent = tool_input["target_parent_id"]
                target_space = tool_input.get("target_space_key")
                client.move_page(page_id, target_parent, space_key=target_space)
                result = {
                    "success": True,
                    "page_id": page_id,
                    "new_parent": target_parent,
                    "message": "Page moved successfully",
                }

            elif tool_name == "get_spaces":
                limit = tool_input.get("limit", 25)
                spaces = client.get_all_spaces(limit=limit)
                result = {
                    "spaces": [
                        {"key": s.key, "name": s.name, "type": getattr(s, 'type', '')}
                        for s in spaces.get("results", [])
                    ]
                }

            elif tool_name == "get_space":
                space_key = tool_input["space_key"]
                space = client.get_space(space_key)
                result = {
                    "key": space.key,
                    "name": space.name,
                    "homepage_id": getattr(space, 'homepage', {}).get('id', None) if hasattr(space, 'homepage') else None,
                }

            elif tool_name == "get_space_content":
                space_key = tool_input["space_key"]
                content_type = tool_input.get("type", "page")
                limit = tool_input.get("limit", 25)
                start = tool_input.get("start", 0)
                pages = client.get_all_pages_from_space(space_key, start=start, limit=limit)
                result = {
                    "space": space_key,
                    "pages": [
                        {"id": p.id, "title": p.title}
                        for p in pages
                    ],
                    "count": len(pages),
                }

            elif tool_name == "get_labels":
                page_id = tool_input["page_id"]
                labels = client.get_page_labels(page_id)
                result = {
                    "page_id": page_id,
                    "labels": [l.get("name", "") for l in labels.get("results", [])]
                }

            elif tool_name == "add_label":
                page_id = tool_input["page_id"]
                labels = tool_input["labels"]
                label_data = [{"prefix": "global", "name": l} for l in labels]
                client.set_page_label(page_id, label_data)
                result = {
                    "success": True,
                    "page_id": page_id,
                    "labels_added": labels,
                }

            elif tool_name == "get_attachments":
                page_id = tool_input["page_id"]
                attachments = client.get_attachments_from_content(page_id)
                result = {
                    "page_id": page_id,
                    "attachments": [
                        {
                            "id": a.get("id", ""),
                            "title": a.get("title", ""),
                            "mediaType": a.get("metadata", {}).get("mediaType", ""),
                        }
                        for a in attachments.get("results", [])
                    ]
                }

            else:
                return f"Unknown tool: {tool_name}"

            return json.dumps(result, indent=2) if isinstance(result, dict) else str(result)

        except Exception as e:
            return f"Error executing {tool_name}: {str(e)}"


# LangGraph node function
docs_agent_node = make_agent_node(DocsAgent)
