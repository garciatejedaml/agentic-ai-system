"""
Comptroller Jira — Jira/Sprint operations agent.

Handles: issue lookup, sprint tracking, comments, status transitions.
Golden template reference — all other agents follow this pattern.
"""
import os
import sys
import json
import logging
from pathlib import Path
from typing import Dict, Any

from .base_agent import BaseAgent, make_agent_node
from ..agent_state import CarsonState

logger = logging.getLogger("carson.agents.jira")

MCP_BASE = Path(__file__).parent.parent.parent.parent / "mcp-servers"


JIRA_TOOLS = [
    # --- Core Issue Operations ---
    {
        "name": "get_issue",
        "description": "Get full details of a Jira issue: status, assignee, priority, story points, labels, components, linked issues",
        "input_schema": {
            "type": "object",
            "properties": {
                "issue_key": {"type": "string", "description": "Jira issue key (e.g., CREDITTECH-241445)"}
            },
            "required": ["issue_key"]
        }
    },
    {
        "name": "search_issues",
        "description": "Search Jira with JQL. Supports complex queries: sprint, status, assignee, labels, dates, components, priority",
        "input_schema": {
            "type": "object",
            "properties": {
                "jql": {"type": "string", "description": "JQL query (e.g., 'sprint in openSprints() AND assignee = \"F702937\"')"},
                "max_results": {"type": "number", "description": "Max results (default 10)"},
                "fields": {"type": "string", "description": "Comma-separated fields to return (e.g., 'summary,status,assignee')"}
            },
            "required": ["jql"]
        }
    },
    {
        "name": "create_jira_issue",
        "description": "Create a new Jira issue. WRITE OPERATION. Supports: Story, Bug, Task, Epic, Sub-task",
        "input_schema": {
            "type": "object",
            "properties": {
                "project_key": {"type": "string", "description": "Project key (e.g., CREDITTECH)"},
                "summary": {"type": "string", "description": "Issue title"},
                "description": {"type": "string", "description": "Full description"},
                "issue_type": {"type": "string", "description": "Story, Bug, Task, Epic, Sub-task"},
                "assignee": {"type": "string", "description": "Assignee SID (e.g., F702937)"},
                "priority": {"type": "string", "description": "Critical, High, Medium, Low"},
                "labels": {"type": "array", "items": {"type": "string"}, "description": "Labels to add"},
                "components": {"type": "array", "items": {"type": "string"}, "description": "Components"},
                "story_points": {"type": "number", "description": "Story point estimate"},
                "parent_key": {"type": "string", "description": "Parent issue key (for Sub-tasks)"},
                "epic_key": {"type": "string", "description": "Epic key to add this issue to"}
            },
            "required": ["project_key", "summary", "issue_type"]
        }
    },
    {
        "name": "update_issue",
        "description": "Update fields on an existing issue. WRITE OPERATION.",
        "input_schema": {
            "type": "object",
            "properties": {
                "issue_key": {"type": "string", "description": "Issue key"},
                "summary": {"type": "string", "description": "New summary"},
                "description": {"type": "string", "description": "New description"},
                "priority": {"type": "string", "description": "New priority"},
                "assignee": {"type": "string", "description": "New assignee SID"},
                "labels": {"type": "array", "items": {"type": "string"}, "description": "Replace labels"},
                "story_points": {"type": "number", "description": "Update story points"}
            },
            "required": ["issue_key"]
        }
    },
    {
        "name": "update_issue_status",
        "description": "Transition an issue through the workflow (To Do → In Progress → In Review → Done)",
        "input_schema": {
            "type": "object",
            "properties": {
                "issue_key": {"type": "string", "description": "Issue key"},
                "transition_name": {"type": "string", "description": "Target status: 'In Progress', 'In Review', 'Done', 'Blocked'"}
            },
            "required": ["issue_key", "transition_name"]
        }
    },
    {
        "name": "add_comment",
        "description": "Add a comment (supports Jira wiki markup: *bold*, _italic_, {code}...{code})",
        "input_schema": {
            "type": "object",
            "properties": {
                "issue_key": {"type": "string", "description": "Issue key"},
                "comment": {"type": "string", "description": "Comment text (Jira wiki markup)"}
            },
            "required": ["issue_key", "comment"]
        }
    },
    # --- Sprint & Board ---
    {
        "name": "get_sprints_for_board",
        "description": "List sprints (active, future, closed) for a board. Use to find sprint IDs.",
        "input_schema": {
            "type": "object",
            "properties": {
                "board_id": {"type": "number", "description": "Jira board ID"},
                "state": {"type": "string", "description": "Filter: active, future, closed (default: active)"}
            },
            "required": ["board_id"]
        }
    },
    {
        "name": "get_sprint_issues",
        "description": "Get all issues in a sprint. Call get_sprints_for_board first to get the sprint_id.",
        "input_schema": {
            "type": "object",
            "properties": {
                "sprint_id": {"type": "number", "description": "Sprint ID from get_sprints_for_board"}
            },
            "required": ["sprint_id"]
        }
    },
    {
        "name": "move_issue_to_sprint",
        "description": "Move an issue into a sprint. WRITE OPERATION (sprint planning).",
        "input_schema": {
            "type": "object",
            "properties": {
                "issue_key": {"type": "string", "description": "Issue key to move"},
                "sprint_id": {"type": "number", "description": "Target sprint ID"}
            },
            "required": ["issue_key", "sprint_id"]
        }
    },
    # --- Linking & Relations ---
    {
        "name": "create_issue_link",
        "description": "Link two issues together. WRITE OPERATION.",
        "input_schema": {
            "type": "object",
            "properties": {
                "inward_issue": {"type": "string", "description": "Issue that IS blocked/related"},
                "outward_issue": {"type": "string", "description": "Issue that BLOCKS/relates"},
                "link_type": {"type": "string", "description": "Blocks, Relates, Duplicates, Clones"}
            },
            "required": ["inward_issue", "outward_issue", "link_type"]
        }
    },
]


class JiraAgent(BaseAgent):
    AGENT_NAME = "jira"
    TOOLS = JIRA_TOOLS

    SYSTEM_PROMPT = """You are Comptroller Jira, a meticulous Scrum Master and Jira expert
within the Carson multi-agent system at JPMorgan Chase.

## Personality
- Precise, methodical, numbers-oriented — like a Victorian accountant who studied at the Scrum Alliance
- Address users formally: "Sir" or "Madam"
- Use ledger metaphors: "balancing the books" (grooming backlog), "the accounts" (sprint board),
  "tallying the figures" (velocity), "opening a new entry" (creating tickets),
  "the quarterly audit" (sprint retrospective)

## Capabilities
You manage ALL Jira operations: issue CRUD, sprint tracking, status transitions,
comments, issue linking, and sprint planning. You are also a Scrum methodology expert.

## JQL Mastery (CRITICAL)
JQL is your superpower. Common patterns:
- My open issues: `assignee = currentUser() AND status != Done`
- Current sprint: `sprint in openSprints() AND project = CREDITTECH`
- Open bugs: `issuetype = Bug AND status != Done AND project = CREDITTECH`
- Stale issues: `updated < -14d AND status != Done`
- Blocked: `status = "Blocked"`
- By label: `labels = "high-touch" AND project = CREDITTECH`

## Sprint Procedures
- When asked about sprint issues, ALWAYS:
  1. First call get_sprints_for_board with board_id to find the active sprint ID
  2. Then call get_sprint_issues with that sprint_id
- When asked about a specific ticket, use get_issue with the ticket key
- For searches, construct appropriate JQL queries

## Scrum Expertise
- Sprint Planning: find backlog items, estimate points, move to sprint
- Daily Standup: in-progress items per person, blockers, completed today
- Sprint Review: committed vs completed, velocity, carry-over
- Retrospective: velocity trends, blocked items, scope changes
- Estimation: 1=trivial, 2=small, 3=medium, 5=large, 8=very large (split it), 13+=epic-level

## Jira-Bitbucket Workflow Integration
1. Jira ticket MUST exist FIRST (create if needed)
2. Move ticket to "In Progress" via update_issue_status
3. THEN the Git agent creates branch (feature/CREDITTECH-<number>-description)
4. All commits reference the Jira ticket ID
5. PR titles include ticket: CREDITTECH-123: PR description

## Safety Rules
- READ operations: proceed immediately
- WRITE operations: ALWAYS confirm with user first
- For ticket transitions: show current status and target before confirming
- For bulk operations: list all affected tickets and get confirmation
- Always include ticket key (e.g., CREDITTECH-1234) in responses
"""

    def execute_tool(self, tool_name: str, tool_input: dict) -> str:
        """Execute a Jira MCP tool."""
        _load_env()
        jira_path = MCP_BASE / "jira-mcp-server-python"
        if str(jira_path) not in sys.path:
            sys.path.insert(0, str(jira_path))

        from source.jira_client import get_jira_client
        client = get_jira_client()

        try:
            if tool_name == "get_issue":
                issue = client.issue(tool_input["issue_key"])
                result = {
                    "key": issue.key,
                    "summary": issue.fields.summary,
                    "status": issue.fields.status.name,
                    "assignee": issue.fields.assignee.displayName if issue.fields.assignee else None,
                    "description": str(issue.fields.description)[:500] if issue.fields.description else None,
                    "issue_type": issue.fields.issuetype.name,
                    "priority": issue.fields.priority.name if issue.fields.priority else None,
                }

            elif tool_name == "search_issues":
                jql = tool_input["jql"]
                max_results = tool_input.get("max_results", 10)
                issues = client.search_issues(jql, maxResults=max_results)
                result = {
                    "issues": [
                        {
                            "key": i.key,
                            "summary": i.fields.summary,
                            "status": i.fields.status.name,
                            "assignee": i.fields.assignee.displayName if i.fields.assignee else None
                        }
                        for i in issues
                    ],
                    "total": len(issues)
                }

            elif tool_name == "get_sprints_for_board" or tool_name == "get_sprints":
                board_id = tool_input["board_id"]
                state = tool_input.get("state", "active")
                sprints = client.sprints(board_id, state=state)
                result = {
                    "sprints": [
                        {"id": s.id, "name": s.name, "state": s.state}
                        for s in sprints
                    ]
                }

            elif tool_name == "get_sprint_issues":
                sprint_id = tool_input["sprint_id"]
                issues = client.search_issues(f"sprint = {sprint_id}", maxResults=50)
                result = {
                    "sprint_id": sprint_id,
                    "issues": [
                        {
                            "key": i.key,
                            "summary": i.fields.summary,
                            "status": i.fields.status.name,
                            "assignee": i.fields.assignee.displayName if i.fields.assignee else None,
                            "issue_type": i.fields.issuetype.name
                        }
                        for i in issues
                    ],
                    "total": len(issues)
                }

            elif tool_name == "add_comment":
                client.add_comment(tool_input["issue_key"], tool_input["comment"])
                result = {"success": True, "message": f"Comment added to {tool_input['issue_key']}"}

            elif tool_name == "create_jira_issue":
                fields = {
                    "project": {"key": tool_input["project_key"]},
                    "summary": tool_input["summary"],
                    "issuetype": {"name": tool_input["issue_type"]},
                }
                if tool_input.get("description"):
                    fields["description"] = tool_input["description"]
                if tool_input.get("assignee"):
                    fields["assignee"] = {"name": tool_input["assignee"]}
                if tool_input.get("priority"):
                    fields["priority"] = {"name": tool_input["priority"]}
                issue = client.create_issue(fields=fields)
                result = {"key": issue.key, "summary": tool_input["summary"], "url": issue.permalink()}

            elif tool_name == "update_issue":
                issue_key = tool_input["issue_key"]
                fields = {}
                if tool_input.get("summary"):
                    fields["summary"] = tool_input["summary"]
                if tool_input.get("description"):
                    fields["description"] = tool_input["description"]
                if tool_input.get("priority"):
                    fields["priority"] = {"name": tool_input["priority"]}
                if tool_input.get("assignee"):
                    fields["assignee"] = {"name": tool_input["assignee"]}
                if tool_input.get("labels") is not None:
                    fields["labels"] = tool_input["labels"]
                if tool_input.get("story_points") is not None:
                    fields["story_points"] = tool_input["story_points"]
                issue = client.issue(issue_key)
                issue.update(fields=fields)
                result = {"success": True, "key": issue_key, "updated_fields": list(fields.keys())}

            elif tool_name == "update_issue_status":
                issue_key = tool_input["issue_key"]
                transition_name = tool_input["transition_name"]
                transitions = client.transitions(issue_key)
                target = next((t for t in transitions if t["name"].lower() == transition_name.lower()), None)
                if target:
                    client.transition_issue(issue_key, target["id"])
                    result = {"success": True, "message": f"{issue_key} transitioned to {transition_name}"}
                else:
                    available = [t["name"] for t in transitions]
                    result = {"success": False, "message": f"Transition '{transition_name}' not found. Available: {available}"}

            elif tool_name == "move_issue_to_sprint":
                issue_key = tool_input["issue_key"]
                sprint_id = tool_input["sprint_id"]
                client.add_issues_to_sprint(sprint_id, [issue_key])
                result = {"success": True, "message": f"{issue_key} moved to sprint {sprint_id}"}

            elif tool_name == "create_issue_link":
                inward = tool_input["inward_issue"]
                outward = tool_input["outward_issue"]
                link_type = tool_input["link_type"]
                client.create_issue_link(
                    type=link_type,
                    inwardIssue=inward,
                    outwardIssue=outward,
                )
                result = {"success": True, "message": f"Linked {inward} {link_type} {outward}"}

            else:
                return f"Unknown tool: {tool_name}"

            return json.dumps(result, indent=2) if isinstance(result, dict) else str(result)

        except Exception as e:
            return f"Error executing {tool_name}: {str(e)}"


def _load_env():
    """Load .env file for MCP server config."""
    import re
    env_file = MCP_BASE.parent / ".env"
    if env_file.exists():
        for line in open(env_file):
            m = re.match(r'^([^#][^=]+)=(.*)', line.strip())
            if m:
                os.environ.setdefault(m.group(1), m.group(2))
    os.environ.setdefault("PYNETA_PROFILE", "local")


# LangGraph node function
jira_agent_node = make_agent_node(JiraAgent)
