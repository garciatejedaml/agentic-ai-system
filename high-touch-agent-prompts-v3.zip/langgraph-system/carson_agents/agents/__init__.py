"""Carson Specialist Agents."""
from .jira_agent import jira_agent_node
from .git_agent import git_agent_node
from .build_agent import build_agent_node
from .deploy_agent import deploy_agent_node
from .docs_agent import docs_agent_node
from .terraform_agent import terraform_agent_node
from .general_agent import general_agent_node

AGENT_REGISTRY = {
    "jira": jira_agent_node,
    "git": git_agent_node,
    "build": build_agent_node,
    "deploy": deploy_agent_node,
    "docs": docs_agent_node,
    "terraform": terraform_agent_node,
    "general": general_agent_node,
}
