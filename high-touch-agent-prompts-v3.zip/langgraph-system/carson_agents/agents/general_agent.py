"""
Inspector Clouseau / General Agent — RAG-enhanced general knowledge agent.

Handles: general questions, AMPS config, AWS concepts, team knowledge.
Uses ChromaDB RAG for context-aware answers when available.
"""
import json
import logging
from typing import Dict, Any

from .base_agent import BaseAgent, make_agent_node
from ..agent_state import CarsonState

logger = logging.getLogger("carson.agents.general")


class GeneralAgent(BaseAgent):
    AGENT_NAME = "general"
    TOOLS = []  # No tools — uses LLM directly, optionally with RAG context

    SYSTEM_PROMPT = """You are Inspector Clouseau, the knowledgeable general specialist
within the Carson multi-agent system at JPMorgan Chase.

## Personality
- Erudite, thorough, occasionally dramatic — like the famous inspector
- Address users as "Sir" or "Madam"
- Use investigative metaphors: "let me examine the evidence" (researching),
  "the case is clear" (answering), "a most intriguing mystery" (complex questions)

## Capabilities
You handle general questions that don't fit a specific specialist agent:
- AMPS configuration and messaging patterns (topics.xml, actions.xml)
- AWS infrastructure concepts (ALB, NLB, ASG, ECS, EKS, RDS, etc.)
- High Touch workflow patterns and best practices
- Team processes and general guidance
- Code quality and SonarQube analysis concepts

## Knowledge Areas (AHTW Team Specific)
- AMPS: Advanced Message Processing System — pub/sub messaging
- High Touch Workflow: Order management system for institutional trading
- CDAO SDK: JPMorgan's internal SDK for AWS Bedrock access
- TFE: Terraform Enterprise for infrastructure management
- Spinnaker: Deployment pipeline tool
- Jenkins: CI/CD build system
- Bitbucket: Git repository hosting

## Response Style
- Provide clear, structured answers
- Use examples when explaining technical concepts
- If you don't know something, say so — don't make it up
- Reference relevant documentation when available
"""

    def run(self, state: CarsonState) -> CarsonState:
        """Run the general agent with optional RAG enhancement."""
        user_request = state.get("user_request", "")

        try:
            # Try to get RAG context if available
            rag_context = self._get_rag_context(user_request)

            llm = __import__('carson_agents.llm', fromlist=['get_llm_client']).get_llm_client()

            system_prompt = self.get_system_prompt()
            if rag_context:
                system_prompt += f"""

## Relevant Context from Knowledge Base
The following context was retrieved from the team's knowledge base.
Use it to inform your answer, but don't reference it as "the knowledge base" —
just use the information naturally.

{rag_context}
"""

            response = llm.converse(
                messages=[{"role": "user", "content": user_request}],
                system=[{"text": system_prompt}],
            )

            agent_response = ""
            for block in response.get("content", []):
                if block.get("type") == "text":
                    agent_response += block.get("text", "")

            if not agent_response:
                agent_response = "I'm afraid I couldn't formulate a response, Sir. Could you rephrase your question?"

        except Exception as e:
            err = str(e)
            logger.error(f"[general] Error: {err}")
            if "InvalidClientTokenId" in err or "ExpiredTokenException" in err:
                agent_response = (
                    "I'm afraid the AWS credentials have expired, Sir. "
                    "Please refresh them via DevShell and restart Carson."
                )
            else:
                agent_response = f"I'm afraid there was an issue, Sir: {err}"

        return {
            **state,
            "agent_response": agent_response,
            "current_agent": self.AGENT_NAME,
        }

    def _get_rag_context(self, query: str) -> str:
        """
        Try to get relevant context from ChromaDB across all collections.

        Queries multiple collections (repo_code, confluence_docs, engineers_docs)
        and merges results by relevance. Returns empty string if RAG is unavailable.
        """
        try:
            from ..rag.knowledge_base import CarsonKnowledgeBase
            from ..config import get_rag_config

            rag_config = get_rag_config()
            if not rag_config.get("enabled", False):
                return ""

            kb = CarsonKnowledgeBase(persist_dir=rag_config.get("persist_dir", "./carson_kb"))

            # Query all available collections
            available_collections = kb.list_collections()
            if not available_collections:
                return ""

            # Use multi-collection query for merged, ranked results
            results = kb.query_multiple(
                query,
                collection_names=available_collections,
                n_results=3,  # top 3 from each collection
            )

            if not results:
                return ""

            # Take top 5 overall results (across all collections)
            context_parts = []
            for item in results[:5]:
                source = item["metadata"].get("source", "unknown")
                coll = item["collection"]
                heading = item["metadata"].get("section_heading", "")
                page_title = item["metadata"].get("page_title", "")

                # Build a rich source label
                if page_title and heading:
                    label = f"{page_title} > {heading} ({coll})"
                elif page_title:
                    label = f"{page_title} ({coll})"
                else:
                    label = f"{source} ({coll})"

                context_parts.append(f"[Source: {label}]\n{item['text'][:500]}")

            return "\n\n---\n\n".join(context_parts)

        except Exception as e:
            logger.debug(f"RAG not available: {e}")

        return ""


general_agent_node = make_agent_node(GeneralAgent)
