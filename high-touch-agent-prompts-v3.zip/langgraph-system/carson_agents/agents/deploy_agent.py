"""
Madame Spinnaker — Deployment/Spinnaker operations agent.

Handles: deployment pipelines, releases, rollbacks, environment status.
"""
import os
import sys
import json
import logging
from pathlib import Path

from .base_agent import BaseAgent, make_agent_node

logger = logging.getLogger("carson.agents.deploy")

MCP_BASE = Path(__file__).parent.parent.parent.parent / "mcp-servers"


DEPLOY_TOOLS = [
    {
        "name": "get_pipelines",
        "description": "List Spinnaker pipelines for an application",
        "input_schema": {
            "type": "object",
            "properties": {
                "application": {
                    "type": "string",
                    "description": "Spinnaker application name"
                }
            },
            "required": ["application"]
        }
    },
    {
        "name": "get_pipeline_status",
        "description": "Get the status of a specific pipeline execution",
        "input_schema": {
            "type": "object",
            "properties": {
                "application": {"type": "string", "description": "Spinnaker application"},
                "pipeline_id": {"type": "string", "description": "Pipeline execution ID"}
            },
            "required": ["application", "pipeline_id"]
        }
    },
    {
        "name": "get_deployments",
        "description": "List recent deployments for an application/environment",
        "input_schema": {
            "type": "object",
            "properties": {
                "application": {"type": "string", "description": "Spinnaker application"},
                "environment": {"type": "string", "description": "Environment: dev, qa, staging, prod"},
                "limit": {"type": "number", "description": "Max results (default 5)"}
            },
            "required": ["application"]
        }
    },
    {
        "name": "trigger_pipeline",
        "description": "Trigger a Spinnaker pipeline. WRITE OPERATION - requires confirmation.",
        "input_schema": {
            "type": "object",
            "properties": {
                "application": {"type": "string", "description": "Spinnaker application"},
                "pipeline_name": {"type": "string", "description": "Pipeline name to trigger"},
                "parameters": {"type": "object", "description": "Optional pipeline parameters"}
            },
            "required": ["application", "pipeline_name"]
        }
    },
    {
        "name": "rollback",
        "description": "Rollback a deployment to a previous version. CRITICAL WRITE OPERATION.",
        "input_schema": {
            "type": "object",
            "properties": {
                "application": {"type": "string", "description": "Spinnaker application"},
                "environment": {"type": "string", "description": "Target environment"},
                "version": {"type": "string", "description": "Version to rollback to"}
            },
            "required": ["application", "environment", "version"]
        }
    }
]


class DeployAgent(BaseAgent):
    AGENT_NAME = "deploy"
    TOOLS = DEPLOY_TOOLS

    SYSTEM_PROMPT = """You are Madame Spinnaker, an elegant and commanding deployment specialist
within the Carson multi-agent system at JPMorgan Chase.

## Personality
- Authoritative yet graceful — like a distinguished diplomat managing deployments
- Address users as "Sir" or "Madam"
- Use diplomatic metaphors: "dispatching the envoy" (deploying), "recalling the ambassador"
  (rollback), "the diplomatic pouch" (release artifact)

## Capabilities
You manage all Spinnaker deployment operations: pipeline management, deployments,
releases, rollbacks, and environment status.

## Build Monitoring Integration
When the Build agent reports a completed build:
1. Identify the repository from the Jenkins job name
2. Check if the repo has a `spinnaker-trigger.yml` in its root
3. If it has a Spinnaker config, determine the pipeline mapping (branch → pipeline)
4. Report: "Build #N succeeded for repo X on branch Y. Spinnaker pipeline Z should trigger automatically."
5. If the user asks to verify, use get_pipeline_status to check execution

## Environment Mapping
- UAT branches (`feature/uat-*`) → deploy to UAT environment
- `develop` branch → deploy to PRE (pre-production)
- `main` branch → deploy to PRE first, then PROD (requires promotion)

## Deployment Safety (CRITICAL)
- NEVER trigger deployments without explicit user confirmation
- Always show: environment, version, and pipeline name before proceeding
- For rollbacks: confirm the target version and environment
- Prefer read-only status checks first
- For production deployments: require DOUBLE confirmation
  "This is a PRODUCTION deployment. Are you absolutely certain, Sir/Madam?"
- Always verify the current deployed version before any action
"""

    def _resolve_app_name(self, app_or_repo: str) -> str:
        """Resolve a repo name to Spinnaker app name using config mappings."""
        from ..config import get_deploy_config
        deploy_cfg = get_deploy_config()
        repo_map = deploy_cfg.get("repo_to_app_map", {})
        # If it's in the map, use the mapped name
        if app_or_repo in repo_map:
            return repo_map[app_or_repo]
        # Otherwise assume it's already a Spinnaker app name
        return app_or_repo

    def _get_pipeline_for_branch(self, branch: str) -> str:
        """Get the pipeline name for a branch using config mappings."""
        from ..config import get_deploy_config
        deploy_cfg = get_deploy_config()
        branch_map = deploy_cfg.get("branch_to_pipeline", {})
        for prefix, pipeline in branch_map.items():
            if branch.startswith(prefix) or branch == prefix:
                return pipeline
        return ""

    def execute_tool(self, tool_name: str, tool_input: dict) -> str:
        """Execute a Spinnaker/Deploy MCP tool."""
        spinnaker_path = MCP_BASE / "spinnaker-mcp-server-python"
        if str(spinnaker_path) not in sys.path:
            sys.path.insert(0, str(spinnaker_path))

        try:
            from source.spinnaker_client import get_spinnaker_client
            client = get_spinnaker_client()

            # Resolve app name — could be a repo name from context
            app = self._resolve_app_name(tool_input.get("application", ""))

            if tool_name == "get_pipelines":
                pipelines = client.get_pipelines(app)
                result = {"application": app, "pipelines": [
                    {"name": p.name, "id": p.id, "status": p.status} for p in pipelines
                ]}

            elif tool_name == "get_pipeline_status":
                pid = tool_input["pipeline_id"]
                status = client.get_execution(app, pid)
                result = {"pipeline_id": pid, "status": status.status, "stages": [
                    {"name": s.name, "status": s.status} for s in status.stages
                ]}

            elif tool_name == "get_deployments":
                env = tool_input.get("environment", "")
                limit = tool_input.get("limit", 5)
                deploys = client.get_deployments(app, environment=env, limit=limit)
                result = {"application": app, "deployments": [
                    {"version": d.version, "environment": d.environment, "status": d.status, "timestamp": str(d.timestamp)}
                    for d in deploys
                ]}

            elif tool_name == "trigger_pipeline":
                pipeline_name = tool_input["pipeline_name"]
                params = tool_input.get("parameters", {})
                execution = client.trigger_pipeline(app, pipeline_name, parameters=params)
                result = {"success": True, "execution_id": execution, "message": f"Pipeline '{pipeline_name}' triggered for {app}"}

            elif tool_name == "rollback":
                env = tool_input["environment"]
                version = tool_input["version"]
                rb = client.rollback(app, env, version)
                result = {"success": True, "message": f"Rollback to {version} initiated for {app}/{env}"}

            else:
                return f"Unknown tool: {tool_name}"

            return json.dumps(result, indent=2)

        except Exception as e:
            return f"Error executing {tool_name}: {str(e)}"


deploy_agent_node = make_agent_node(DeployAgent)
