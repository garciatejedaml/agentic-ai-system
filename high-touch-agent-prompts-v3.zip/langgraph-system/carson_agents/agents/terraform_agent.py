"""
M. Terraform Inspector — Infrastructure/AWS/Terraform operations agent.

Handles: Terraform state, AWS resources (ECS, EKS, RDS, ALB), infrastructure queries.
"""
import os
import sys
import json
import logging
from pathlib import Path

from .base_agent import BaseAgent, make_agent_node

logger = logging.getLogger("carson.agents.terraform")

MCP_BASE = Path(__file__).parent.parent.parent.parent / "mcp-servers"


TERRAFORM_TOOLS = [
    {
        "name": "get_plan_logs",
        "description": "Get Terraform plan logs for a specific plan ID in TFE (Terraform Enterprise)",
        "input_schema": {
            "type": "object",
            "properties": {
                "plan_id": {
                    "type": "string",
                    "description": "The TFE plan ID (e.g., plan-abc123)"
                }
            },
            "required": ["plan_id"]
        }
    },
    {
        "name": "get_apply_logs",
        "description": "Get Terraform apply logs for a specific apply ID in TFE",
        "input_schema": {
            "type": "object",
            "properties": {
                "apply_id": {
                    "type": "string",
                    "description": "The TFE apply ID (e.g., apply-abc123)"
                }
            },
            "required": ["apply_id"]
        }
    },
    {
        "name": "list_workspaces",
        "description": "List Terraform workspaces in an organization",
        "input_schema": {
            "type": "object",
            "properties": {
                "organization": {
                    "type": "string",
                    "description": "TFE organization name"
                },
                "search": {
                    "type": "string",
                    "description": "Optional search filter for workspace names"
                }
            },
            "required": ["organization"]
        }
    },
    {
        "name": "get_workspace_runs",
        "description": "Get recent runs for a Terraform workspace",
        "input_schema": {
            "type": "object",
            "properties": {
                "workspace_id": {
                    "type": "string",
                    "description": "TFE workspace ID"
                },
                "limit": {
                    "type": "number",
                    "description": "Max runs to return (default 5)"
                }
            },
            "required": ["workspace_id"]
        }
    },
    {
        "name": "get_state_resources",
        "description": "List resources in the current Terraform state for a workspace",
        "input_schema": {
            "type": "object",
            "properties": {
                "workspace_id": {
                    "type": "string",
                    "description": "TFE workspace ID"
                }
            },
            "required": ["workspace_id"]
        }
    }
]


class TerraformAgent(BaseAgent):
    AGENT_NAME = "terraform"
    TOOLS = TERRAFORM_TOOLS

    SYSTEM_PROMPT = """You are M. Terraform Inspector, a thorough and methodical infrastructure specialist
within the Carson multi-agent system at JPMorgan Chase.

## Personality
- Investigative, analytical, precise — like a detective examining infrastructure
- Address users as "Sir" or "Madam"
- Use detective metaphors: "examining the evidence" (reviewing state), "the case file"
  (workspace), "following the trail" (tracing dependencies), "the scene" (infrastructure)

## Capabilities
You manage all Terraform Enterprise (TFE) and AWS infrastructure operations:
workspace management, plan/apply logs, state inspection, and resource queries.

## TFE Organization
- The team's TFE org is in config.yaml -> team.tfe_organization
- Workspaces follow naming: {team}-{service}-{environment}

## Terraform Bundle Format
Terraform bundles follow naming: {terraform_version}-{YYYYMMDD}-JPMC
(e.g., 1.3.6-20250110-JPMC). Bundles are specified in repository jib.yml files.
Upgrade bundles when: provider version mismatch, new features needed, or security patches.

## Plan Review Checklist
When reviewing Terraform plans:
- Count: additions, changes, destructions
- Flag any resource destructions prominently
- Check for: security group changes, IAM policy changes, database modifications
- Warn about cost implications of new resources

## Infrastructure Safety
- NEVER trigger applies without explicit user confirmation
- For plan reviews: summarize additions, changes, and destructions clearly
- Always show resource counts before any destructive operation
- When examining state, highlight any resources in an error or tainted state
- For AWS resource queries, prefer read-only operations
- Warn about any resources that might incur costs if created
- Database changes require extra caution (potential data loss)
"""

    def execute_tool(self, tool_name: str, tool_input: dict) -> str:
        """Execute a TFE/Terraform MCP tool."""
        tfe_path = MCP_BASE / "tfe-mcp-server-python"
        if str(tfe_path) not in sys.path:
            sys.path.insert(0, str(tfe_path))

        try:
            from source.tfe_client import get_tfe_client
            client = get_tfe_client()

            if tool_name == "get_plan_logs":
                plan_id = tool_input["plan_id"]
                logs = client.get_plan_logs(plan_id)
                result = {"plan_id": plan_id, "logs": logs[:3000]}

            elif tool_name == "get_apply_logs":
                apply_id = tool_input["apply_id"]
                logs = client.get_apply_logs(apply_id)
                result = {"apply_id": apply_id, "logs": logs[:3000]}

            elif tool_name == "list_workspaces":
                org = tool_input["organization"]
                search = tool_input.get("search", "")
                workspaces = client.list_workspaces(org, search=search)
                result = {"organization": org, "workspaces": [
                    {"id": w.id, "name": w.name, "terraform_version": w.terraform_version}
                    for w in workspaces
                ]}

            elif tool_name == "get_workspace_runs":
                ws_id = tool_input["workspace_id"]
                limit = tool_input.get("limit", 5)
                runs = client.get_workspace_runs(ws_id, limit=limit)
                result = {"workspace_id": ws_id, "runs": [
                    {"id": r.id, "status": r.status, "created_at": str(r.created_at), "message": r.message[:100]}
                    for r in runs
                ]}

            elif tool_name == "get_state_resources":
                ws_id = tool_input["workspace_id"]
                resources = client.get_state_resources(ws_id)
                result = {"workspace_id": ws_id, "resources": [
                    {"type": r.type, "name": r.name, "provider": r.provider}
                    for r in resources
                ]}

            else:
                return f"Unknown tool: {tool_name}"

            return json.dumps(result, indent=2)

        except Exception as e:
            return f"Error executing {tool_name}: {str(e)}"


terraform_agent_node = make_agent_node(TerraformAgent)
