"""
Mr. Brandson — Git/Bitbucket operations agent.

Handles: repository info, branches, commits, pull requests, code review.

MCP Tool names use camelCase to match the Bitbucket MCP server:
  listRepositories, getBranches, getCommits, getPullRequests,
  createPullRequest, createBranch, getFileContent, commitFile
"""
import os
import sys
import json
import logging
from pathlib import Path

from .base_agent import BaseAgent, make_agent_node

logger = logging.getLogger("carson.agents.git")

MCP_BASE = Path(__file__).parent.parent.parent.parent / "mcp-servers"


GIT_TOOLS = [
    {
        "name": "listRepositories",
        "description": "List all repositories in a Bitbucket project",
        "input_schema": {
            "type": "object",
            "properties": {
                "projectKey": {
                    "type": "string",
                    "description": "Bitbucket project key (e.g. CREDITTECH, ACAMPS)"
                }
            },
            "required": ["projectKey"]
        }
    },
    {
        "name": "getBranches",
        "description": "List branches in a repository. Use to identify feature/uat-* branches for AMPS workflows.",
        "input_schema": {
            "type": "object",
            "properties": {
                "projectKey": {"type": "string", "description": "Bitbucket project key"},
                "repositorySlug": {"type": "string", "description": "Repository slug name"},
                "filterText": {"type": "string", "description": "Optional filter text (e.g. 'feature/uat' to find workflow branches)"}
            },
            "required": ["projectKey", "repositorySlug"]
        }
    },
    {
        "name": "getCommits",
        "description": "Get recent commits for a repository branch",
        "input_schema": {
            "type": "object",
            "properties": {
                "projectKey": {"type": "string", "description": "Bitbucket project key"},
                "repositorySlug": {"type": "string", "description": "Repository slug"},
                "branch": {"type": "string", "description": "Branch name (default: main)"},
                "limit": {"type": "number", "description": "Max commits to return (default 10)"}
            },
            "required": ["projectKey", "repositorySlug"]
        }
    },
    {
        "name": "getPullRequests",
        "description": "List pull requests for a repository",
        "input_schema": {
            "type": "object",
            "properties": {
                "projectKey": {"type": "string", "description": "Bitbucket project key"},
                "repositorySlug": {"type": "string", "description": "Repository slug"},
                "state": {"type": "string", "description": "PR state: OPEN, MERGED, DECLINED, ALL (default: OPEN)"}
            },
            "required": ["projectKey", "repositorySlug"]
        }
    },
    {
        "name": "createPullRequest",
        "description": "Create a new pull request. WRITE OPERATION - requires user confirmation.",
        "input_schema": {
            "type": "object",
            "properties": {
                "projectKey": {"type": "string", "description": "Bitbucket project key"},
                "repositorySlug": {"type": "string", "description": "Repository slug"},
                "title": {"type": "string", "description": "PR title (include Jira ticket ID)"},
                "description": {"type": "string", "description": "PR description with change summary"},
                "fromBranch": {"type": "string", "description": "Source branch"},
                "toBranch": {"type": "string", "description": "Target branch (e.g. develop)"},
                "reviewers": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of reviewer usernames"
                }
            },
            "required": ["projectKey", "repositorySlug", "title", "fromBranch", "toBranch"]
        }
    },
    {
        "name": "createBranch",
        "description": "Create a new branch from an existing ref. WRITE OPERATION - requires user confirmation.",
        "input_schema": {
            "type": "object",
            "properties": {
                "projectKey": {"type": "string", "description": "Bitbucket project key"},
                "repositorySlug": {"type": "string", "description": "Repository slug"},
                "branchName": {"type": "string", "description": "New branch name (e.g. feature/CREDITTECH-123-add-topic)"},
                "startPoint": {"type": "string", "description": "Starting ref (branch or commit hash)"}
            },
            "required": ["projectKey", "repositorySlug", "branchName", "startPoint"]
        }
    },
    {
        "name": "getFileContent",
        "description": "Read the content of a file from a repository at a specific branch/commit",
        "input_schema": {
            "type": "object",
            "properties": {
                "projectKey": {"type": "string", "description": "Bitbucket project key"},
                "repositorySlug": {"type": "string", "description": "Repository slug"},
                "filePath": {"type": "string", "description": "Path to file in repo"},
                "ref": {"type": "string", "description": "Branch or commit ref (default: main)"}
            },
            "required": ["projectKey", "repositorySlug", "filePath"]
        }
    },
    {
        "name": "commitFile",
        "description": "Commit a file change to a branch. WRITE OPERATION - requires user confirmation. NEVER use for protected branches (main/develop).",
        "input_schema": {
            "type": "object",
            "properties": {
                "projectKey": {"type": "string", "description": "Bitbucket project key"},
                "repositorySlug": {"type": "string", "description": "Repository slug"},
                "filePath": {"type": "string", "description": "Path to file in repo"},
                "content": {"type": "string", "description": "New file content"},
                "commitMessage": {"type": "string", "description": "Commit message (must include Jira ticket ID)"},
                "branch": {"type": "string", "description": "Target branch (must NOT be main or develop)"}
            },
            "required": ["projectKey", "repositorySlug", "filePath", "content", "commitMessage", "branch"]
        }
    }
]


class GitAgent(BaseAgent):
    AGENT_NAME = "git"
    TOOLS = GIT_TOOLS

    def _get_project_context(self) -> str:
        """Build project context string for the system prompt."""
        from ..config import get_bitbucket_projects, get_default_bitbucket_project
        projects = get_bitbucket_projects()
        default = get_default_bitbucket_project()
        if not projects:
            return "\nNo Bitbucket projects configured for this team."
        lines = ["\n## Team Bitbucket Projects"]
        for p in projects:
            marker = " (DEFAULT)" if p.get("key") == default else ""
            desc = p.get("description", "")
            repos = p.get("repositories", [])
            lines.append(f"- **{p['key']}**{marker}: {desc}")
            if repos:
                for r in repos[:10]:
                    lines.append(f"  - {r}")
        lines.append(f"\nWhen the user doesn't specify a project, use: {default}")
        return "\n".join(lines)

    def get_system_prompt(self) -> str:
        base = self.SYSTEM_PROMPT + self._get_project_context()
        return base + "\n" + self.STANDARD_RULES

    SYSTEM_PROMPT = """You are Mr. Brandson, a distinguished and reliable Git/Bitbucket specialist
within the Carson multi-agent system at JPMorgan Chase.

## Personality
- Steady, dependable, meticulous — like a trusted valet with source code
- Address users as "Sir" or "Madam"
- Use butler metaphors: "maintaining the estate" (repo), "the ledger of changes" (git log),
  "preparing the parcel" (PR)

## Capabilities
You manage all Git and Bitbucket operations: repository browsing, branch management,
commit history, pull request management, and code review.
You can work across MULTIPLE Bitbucket projects — always check which project the user means.

## Branching Strategy
| Branch Pattern | Purpose | Deploys To |
|---|---|---|
| `feature/uat-<workflow>` | UAT environment | UAT |
| `develop` | Pre-production | PRE |
| `main` | Release branch | PRE -> PROD |

### AMPS Workflow Branches
- Repos named `high-touch-<product>-amps` contain workflow folders (e.g. `rfq-feed/`, `bond/`, `ptf/`)
- `feature/uat-<workflow>` branches contain ONLY that workflow's folder
- `develop` and `main` branches contain ALL workflow folders

### Finding the Right Branch
1. Identify the workflow name from the folder the user wants to modify
2. Use branch `feature/uat-<workflow>` for UAT changes
3. Create feature branches FROM `feature/uat-<workflow>`, not from `develop`

## Branch Safety - CRITICAL
- NEVER push directly to main/master or develop
- ALWAYS use createPullRequest MCP tool instead of git CLI push
- For destructive operations (force push, branch delete): ALWAYS confirm
- When reviewing PRs, provide constructive feedback on code quality

## Jira Ticket Requirement - CRITICAL
Bitbucket requires a valid Jira ticket ID in all commits. Workflow:
1. Jira ticket MUST exist FIRST
2. Move ticket to "In Progress" when starting work
3. THEN create branch with ticket ID (e.g. feature/CREDITTECH-123-description)
4. THEN commit and push

## PR Confirmation
Before creating any PR, always summarize:
- Repository and branch info
- Jira ticket reference
- Modified files list
- Deploy target (UAT/PRE/PROD)
Then ask: "Should I proceed with the commit and PR, Sir/Madam?"
"""

    def execute_tool(self, tool_name: str, tool_input: dict) -> str:
        """Execute a Git/Bitbucket MCP tool."""
        git_path = MCP_BASE / "bitbucket-mcp-server-python"
        if str(git_path) not in sys.path:
            sys.path.insert(0, str(git_path))

        try:
            from source.bitbucket_client import get_bitbucket_client
            client = get_bitbucket_client()

            project = tool_input.get("projectKey", "")
            repo = tool_input.get("repositorySlug", "")

            if tool_name == "listRepositories":
                repos = client.get_repos(project)
                result = {"repositories": [{"slug": r.slug, "name": r.name} for r in repos]}

            elif tool_name == "getBranches":
                filter_text = tool_input.get("filterText")
                branches = client.get_branches(project, repo, filter_text=filter_text)
                result = {"branches": [{"name": b.name, "latestCommit": b.latestCommit} for b in branches]}

            elif tool_name == "getCommits":
                branch = tool_input.get("branch", "main")
                limit = tool_input.get("limit", 10)
                commits = client.get_commits(project, repo, branch=branch, limit=limit)
                result = {
                    "commits": [
                        {"hash": c.hash[:8], "message": c.message[:100], "author": c.author.name, "date": str(c.authorTimestamp)}
                        for c in commits
                    ]
                }

            elif tool_name == "getPullRequests":
                state = tool_input.get("state", "OPEN")
                prs = client.get_pull_requests(project, repo, state=state)
                result = {
                    "pull_requests": [
                        {"id": pr.id, "title": pr.title, "author": pr.author.user.displayName, "state": pr.state}
                        for pr in prs
                    ]
                }

            elif tool_name == "createPullRequest":
                title = tool_input["title"]
                description = tool_input.get("description", "")
                from_branch = tool_input["fromBranch"]
                to_branch = tool_input["toBranch"]
                reviewers = tool_input.get("reviewers", [])
                pr = client.create_pull_request(
                    project, repo, title=title, description=description,
                    from_branch=from_branch, to_branch=to_branch, reviewers=reviewers
                )
                result = {"id": pr.id, "title": pr.title, "state": pr.state, "url": getattr(pr, 'url', '')}

            elif tool_name == "createBranch":
                branch_name = tool_input["branchName"]
                start_point = tool_input["startPoint"]
                branch = client.create_branch(project, repo, branch_name=branch_name, start_point=start_point)
                result = {"name": branch.name, "latestCommit": branch.latestCommit}

            elif tool_name == "getFileContent":
                file_path = tool_input["filePath"]
                ref = tool_input.get("ref", "main")
                content = client.get_file_content(project, repo, file_path, at=ref)
                result = {"file": file_path, "ref": ref, "content": content[:2000]}

            elif tool_name == "commitFile":
                file_path = tool_input["filePath"]
                content = tool_input["content"]
                commit_msg = tool_input["commitMessage"]
                branch = tool_input["branch"]
                # Safety: block commits to protected branches
                if branch in ("main", "master", "develop"):
                    return json.dumps({"error": f"Cannot commit directly to protected branch '{branch}'. Use a feature branch and create a PR."})
                commit = client.commit_file(project, repo, file_path=file_path, content=content, message=commit_msg, branch=branch)
                result = {"commit": commit.hash[:8] if hasattr(commit, 'hash') else str(commit), "branch": branch}

            else:
                return f"Unknown tool: {tool_name}"

            return json.dumps(result, indent=2)

        except Exception as e:
            return f"Error executing {tool_name}: {str(e)}"


git_agent_node = make_agent_node(GitAgent)
