"""
Base Agent — Golden template pattern for all Carson specialist agents.

Every agent follows this exact pattern:
1. Get user request from state
2. Build system prompt + messages
3. Loop: send to LLM → if tool_use, execute tool → append result → repeat
4. Return agent_response as string

Subclasses only need to define:
  - AGENT_NAME: str
  - TOOLS: list of tool definitions
  - SYSTEM_PROMPT: str
  - execute_tool(tool_name, tool_input) -> str
"""
import json
import logging
from typing import Dict, Any, List, Optional
from abc import ABC, abstractmethod

from ..agent_state import CarsonState
from ..llm import get_llm_client

logger = logging.getLogger("carson.agents")

MAX_TOOL_ITERATIONS = 5


class BaseAgent(ABC):
    """Abstract base class for all Carson specialist agents."""

    AGENT_NAME: str = "base"
    TOOLS: List[Dict[str, Any]] = []
    SYSTEM_PROMPT: str = ""

    # Standard safety & format rules appended to ALL agent prompts
    STANDARD_RULES = """
## Safety Rules
- For READ operations (search, get, list, status): proceed immediately
- For WRITE operations (create, update, delete, comment, transition):
  ALWAYS confirm with the user before executing:
  "I am about to [specific action]. Shall I proceed, Sir/Madam?"
- Never execute destructive operations without explicit confirmation

## Output Format
Always end your response with one of:
- A brief success summary for successful operations
- A warning for partial results
- An error summary with a suggested next step

Keep responses concise — max 3-4 sentences unless detail was explicitly requested.

## Error Handling
If you encounter an error:
1. Do NOT expose raw stack traces to the user
2. Summarize the issue in plain language
3. Suggest a remediation step
"""

    @abstractmethod
    def execute_tool(self, tool_name: str, tool_input: dict) -> str:
        """Execute a tool call and return the result as a string."""
        pass

    def get_system_prompt(self) -> str:
        """Get the full system prompt with standard rules appended."""
        return self.SYSTEM_PROMPT + "\n" + self.STANDARD_RULES

    def run(self, state: CarsonState) -> CarsonState:
        """
        Execute the agent — golden template pattern.

        This is the main entry point called by the LangGraph workflow.
        """
        user_request = state.get("user_request", "")
        tool_results_collected = []

        try:
            llm = get_llm_client()

            messages = [{"role": "user", "content": user_request}]
            system = [{"text": self.get_system_prompt()}]

            agent_response = ""
            iteration = 0

            while iteration < MAX_TOOL_ITERATIONS:
                iteration += 1

                response = llm.converse(
                    messages=messages,
                    system=system,
                    tools=self.TOOLS if self.TOOLS else None,
                )

                stop_reason = response.get("stop_reason", "end_turn")
                content_blocks = response.get("content", [])

                # Build assistant message for conversation history
                assistant_message = {"role": "assistant", "content": content_blocks}
                messages.append(assistant_message)

                if stop_reason == "end_turn":
                    # Extract text response
                    for block in content_blocks:
                        if block.get("type") == "text":
                            agent_response += block.get("text", "")
                    break

                elif stop_reason == "tool_use":
                    tool_results = []

                    for block in content_blocks:
                        if block.get("type") == "tool_use":
                            tool_name = block.get("name", "")
                            tool_input = block.get("input", {})
                            tool_use_id = block.get("id", "")

                            logger.info(f"[{self.AGENT_NAME}] Tool call: {tool_name}({json.dumps(tool_input)[:200]})")

                            try:
                                tool_result = self.execute_tool(tool_name, tool_input)
                            except Exception as e:
                                tool_result = f"Error executing {tool_name}: {str(e)}"
                                logger.error(f"[{self.AGENT_NAME}] {tool_result}")

                            tool_results_collected.append({
                                "tool": tool_name,
                                "input": tool_input,
                                "result": tool_result
                            })

                            tool_results.append({
                                "type": "tool_result",
                                "tool_use_id": tool_use_id,
                                "content": tool_result
                            })

                    messages.append({
                        "role": "user",
                        "content": tool_results
                    })
                else:
                    # Unknown stop reason
                    break

            if not agent_response:
                agent_response = "I completed the operation but have no additional details to report."

        except Exception as e:
            err = str(e)
            logger.error(f"[{self.AGENT_NAME}] Agent error: {err}")

            if "InvalidClientTokenId" in err or "ExpiredTokenException" in err:
                agent_response = (
                    "I'm afraid the AWS credentials have expired, Sir. "
                    "Please refresh them via DevShell and restart Carson."
                )
            else:
                agent_response = f"I'm afraid there was an issue, Sir: {err}"

        return {
            **state,
            "agent_response": agent_response,
            "tool_results_collected": tool_results_collected,
            "current_agent": self.AGENT_NAME,
        }


def make_agent_node(agent_class):
    """Create a LangGraph node function from an agent class."""
    agent = agent_class()

    def node_fn(state: CarsonState) -> CarsonState:
        return agent.run(state)

    node_fn.__name__ = f"{agent_class.AGENT_NAME}_agent_node"
    return node_fn
