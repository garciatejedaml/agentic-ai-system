"""
M. Jenkins (Monsieur Jenkins) — Build/CI pipeline agent.

Handles: Jenkins builds, pipeline status, build logs, test results.

MCP Tool names use camelCase to match the Jenkins MCP server:
  getJobs, getJobDetails, getBuildDetails, getBuildConsoleOutput, triggerBuild
"""
import os
import sys
import json
import logging
from pathlib import Path

from .base_agent import BaseAgent, make_agent_node

logger = logging.getLogger("carson.agents.build")

MCP_BASE = Path(__file__).parent.parent.parent.parent / "mcp-servers"


BUILD_TOOLS = [
    {
        "name": "getJobs",
        "description": "List Jenkins jobs, optionally filtered by folder/project path",
        "input_schema": {
            "type": "object",
            "properties": {
                "folder": {
                    "type": "string",
                    "description": "Jenkins folder path to list jobs from (e.g. 'CREDITTECH')"
                }
            },
            "required": []
        }
    },
    {
        "name": "getJobDetails",
        "description": "Get details of a specific Jenkins job including recent builds",
        "input_schema": {
            "type": "object",
            "properties": {
                "jobName": {
                    "type": "string",
                    "description": "Full Jenkins job name/path (e.g., 'CREDITTECH/high-touch-workflow/main')"
                }
            },
            "required": ["jobName"]
        }
    },
    {
        "name": "getBuildDetails",
        "description": "Get details of a specific build including status, duration, and test results",
        "input_schema": {
            "type": "object",
            "properties": {
                "jobName": {"type": "string", "description": "Jenkins job name"},
                "buildNumber": {"type": "number", "description": "Build number (0 or omit for latest)"}
            },
            "required": ["jobName"]
        }
    },
    {
        "name": "getBuildConsoleOutput",
        "description": "Get console output/logs for a specific build. Useful for diagnosing failures.",
        "input_schema": {
            "type": "object",
            "properties": {
                "jobName": {"type": "string", "description": "Jenkins job name"},
                "buildNumber": {"type": "number", "description": "Build number (0 or omit for latest)"}
            },
            "required": ["jobName"]
        }
    },
    {
        "name": "triggerBuild",
        "description": "Trigger a new Jenkins build for a job. WRITE OPERATION - requires user confirmation.",
        "input_schema": {
            "type": "object",
            "properties": {
                "jobName": {"type": "string", "description": "Jenkins job name"},
                "parameters": {
                    "type": "object",
                    "description": "Optional build parameters as key-value pairs"
                }
            },
            "required": ["jobName"]
        }
    }
]


class BuildAgent(BaseAgent):
    AGENT_NAME = "build"
    TOOLS = BUILD_TOOLS

    def _format_job_name(self, project: str, repo: str, branch: str) -> str:
        """Format a Jenkins job name using the configured pattern."""
        from ..config import get_build_config
        build_cfg = get_build_config()
        fmt = build_cfg.get("job_format", "{project}/{repo}/{branch}")
        branch_encoded = branch.replace("/", "%2F")
        return fmt.format(project=project, repo=repo, branch=branch_encoded)

    SYSTEM_PROMPT = """You are M. Jenkins (Monsieur Jenkins), a fastidious and efficient CI/CD specialist
within the Carson multi-agent system at JPMorgan Chase.

## Personality
- Precise, efficient, slightly fussy about build quality — like a French maitre d'
- Address users as "Sir" or "Madam"
- Use culinary metaphors: "the recipe" (build config), "mise en place" (prerequisites),
  "a dish well prepared" (successful build), "back to the kitchen" (build failure)

## Capabilities
You manage all Jenkins CI/CD operations: job listing, build status, build details,
console output/logs, and triggering new builds.

## Build Monitoring Integration
When a build completes:
1. Identify the repository from the job name
2. Check if the repo has a spinnaker-trigger.yml (use getFileContent via Bitbucket MCP)
3. If it has a Spinnaker config, determine the pipeline mapping
4. Report: "Build #N succeeded for repo X on branch Y. Spinnaker pipeline Z should trigger automatically."

## Build Safety
- NEVER trigger builds without explicit user confirmation
- Always show job name and parameters before triggering
- For build logs, show a summary first — full logs only on request
- Present test results with pass/fail counts prominently
- If a build is failing, analyze the logs and suggest fixes
"""

    def execute_tool(self, tool_name: str, tool_input: dict) -> str:
        """Execute a Jenkins/Build MCP tool."""
        jenkins_path = MCP_BASE / "jenkins-mcp-server-python"
        if str(jenkins_path) not in sys.path:
            sys.path.insert(0, str(jenkins_path))

        try:
            from source.jenkins_client import get_jenkins_client
            client = get_jenkins_client()

            job_name = tool_input.get("jobName", "")

            if tool_name == "getJobs":
                folder = tool_input.get("folder", "")
                jobs = client.get_jobs(folder=folder) if folder else client.get_jobs()
                result = {"jobs": [{"name": j.name, "url": j.url, "color": getattr(j, 'color', '')} for j in jobs]}

            elif tool_name == "getJobDetails":
                job = client.get_job_details(job_name)
                result = {
                    "name": job.name,
                    "url": job.url,
                    "lastBuild": getattr(job, 'lastBuild', {}).get('number', None) if isinstance(getattr(job, 'lastBuild', None), dict) else None,
                    "lastSuccessfulBuild": getattr(job, 'lastSuccessfulBuild', {}).get('number', None) if isinstance(getattr(job, 'lastSuccessfulBuild', None), dict) else None,
                    "buildable": getattr(job, 'buildable', True)
                }

            elif tool_name == "getBuildDetails":
                build_number = tool_input.get("buildNumber", 0)
                build = client.get_build_details(job_name, build_number or "lastBuild")
                result = {
                    "job": job_name,
                    "buildNumber": build.number,
                    "result": build.result or "IN_PROGRESS",
                    "timestamp": str(build.timestamp),
                    "durationMs": build.duration,
                    "url": build.url
                }

            elif tool_name == "getBuildConsoleOutput":
                build_number = tool_input.get("buildNumber", 0)
                logs = client.get_build_console_output(job_name, build_number or "lastBuild")
                # Truncate logs to avoid overwhelming the LLM
                result = {"job": job_name, "buildNumber": build_number, "consoleOutput": logs[:3000]}

            elif tool_name == "triggerBuild":
                params = tool_input.get("parameters", {})
                queue_id = client.trigger_build(job_name, parameters=params)
                result = {"success": True, "message": f"Build triggered for {job_name}", "queueId": queue_id}

            else:
                return f"Unknown tool: {tool_name}"

            return json.dumps(result, indent=2)

        except Exception as e:
            return f"Error executing {tool_name}: {str(e)}"


build_agent_node = make_agent_node(BuildAgent)
