"""
Carson Agent State — Shared state for LangGraph workflow.

All agents read from and write to this state dict.
"""
from typing import TypedDict, Optional, List


class CarsonState(TypedDict, total=False):
    # Input
    user_request: str
    context: dict

    # Router output
    intent: Optional[str]
    current_agent: Optional[str]

    # Agent output
    agent_response: Optional[str]          # MUST be a string, never a dict
    tool_results_collected: Optional[list]  # [{tool, input, result}, ...]

    # Confirmation flow (write operations)
    confirmation_required: Optional[str]    # Description of pending action
    confirmed: Optional[bool]              # True after user confirms

    # Conversation
    messages: List[dict]

    # Final
    final_response: Optional[str]
