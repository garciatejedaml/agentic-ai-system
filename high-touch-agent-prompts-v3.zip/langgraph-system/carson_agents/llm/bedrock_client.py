"""
Bedrock LLM Client — CDAO SDK implementation for JPMC.

Uses cdao.bedrock_byoa_invoke_model() for all Bedrock calls.
NEVER uses boto3 directly.
"""
import json
import logging
from typing import List, Dict, Any, Optional

from .base import BaseLLMClient, retry_on_throttle

logger = logging.getLogger("carson.llm.bedrock")


class BedrockLLMClient(BaseLLMClient):
    """LLM client using JPMC CDAO SDK for AWS Bedrock."""

    def __init__(self, config: Dict[str, Any]):
        """
        Args:
            config: LLM config from config.yaml, e.g.:
                {
                    "provider": "bedrock",
                    "model_id": "anthropic.claude-3-5-sonnet-20241022-v2:0",
                    "aws_account": "043309362186",
                    "aws_region": "us-east-1",
                    "workspace_id": "905183",
                    "model_arn": "arn:aws:bedrock:..."
                }
        """
        self.model_id = config.get(
            "model_id",
            "anthropic.claude-3-5-sonnet-20241022-v2:0"
        )
        self.model_arn = config.get("model_arn", "")

        # CDAO SDK connection data
        self._cdao_data = {
            "AWSAccountNumber": config.get("aws_account", "043309362186"),
            "AWSRegion": config.get("aws_region", "us-east-1"),
            "WorkspaceID": config.get("workspace_id", "905183"),
            "isExecutionRole": config.get("is_execution_role", False)
        }

        # Import cdao lazily to allow non-Bedrock usage
        self._cdao = None

    def _get_cdao(self):
        if self._cdao is None:
            try:
                import cdao
                self._cdao = cdao
            except ImportError:
                raise ImportError(
                    "CDAO SDK not installed. Install it from the JPMC artifact repo, "
                    "or switch to a non-Bedrock provider in config.yaml"
                )
        return self._cdao

    def _convert_tools_to_anthropic(self, tools: List[Dict]) -> List[Dict]:
        """Ensure tools are in Anthropic Messages API format."""
        converted = []
        for tool in tools:
            # Already in Anthropic format
            if "input_schema" in tool and "name" in tool:
                converted.append(tool)
            # Converse format — convert
            elif "toolSpec" in tool:
                spec = tool["toolSpec"]
                converted.append({
                    "name": spec.get("name", ""),
                    "description": spec.get("description", ""),
                    "input_schema": spec.get("inputSchema", {}).get("json", {})
                })
            # inputSchema (camelCase) — convert to snake_case
            elif "inputSchema" in tool:
                converted.append({
                    "name": tool.get("name", ""),
                    "description": tool.get("description", ""),
                    "input_schema": tool["inputSchema"]
                })
            else:
                converted.append(tool)
        return converted

    @retry_on_throttle(max_retries=3)
    def converse(
        self,
        messages: List[Dict[str, Any]],
        system: Optional[List[Dict[str, str]]] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
        model_id: Optional[str] = None,
        max_tokens: int = 4096,
    ) -> Dict[str, Any]:
        """Send conversation to Bedrock via CDAO SDK."""
        cdao = self._get_cdao()

        # Build Anthropic Messages API body
        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": max_tokens,
            "messages": messages,
        }

        if system:
            # system can be [{"text": "..."}] or just a string
            if isinstance(system, list) and system:
                body["system"] = system[0].get("text", "") if len(system) == 1 else "\n".join(s.get("text", "") for s in system)
            elif isinstance(system, str):
                body["system"] = system

        if tools:
            body["tools"] = self._convert_tools_to_anthropic(tools)

        use_model = model_id or self.model_arn or self.model_id
        payload = {
            "modelId": use_model,
            "body": json.dumps(body)
        }

        logger.debug(f"Bedrock request: model={use_model}, messages={len(messages)}")

        response = cdao.bedrock_byoa_invoke_model(self._cdao_data, payload)

        # Parse response
        resp_body = response.get("body")
        if not resp_body:
            raise Exception("Empty response from Bedrock. Check AWS credentials.")

        raw = resp_body.read() if hasattr(resp_body, "read") else resp_body
        if not raw:
            raise Exception("Empty response body from Bedrock.")

        result = json.loads(raw) if isinstance(raw, (str, bytes)) else raw

        # Normalize to our standard format
        return self._normalize_response(result)

    def _normalize_response(self, result: Dict) -> Dict[str, Any]:
        """
        Normalize Anthropic Messages API response to standard format.

        Handles both snake_case (Anthropic) and camelCase (Converse) formats.
        """
        # Determine stop reason
        stop_reason = (
            result.get("stop_reason")
            or result.get("stopReason")
            or "end_turn"
        )

        # Normalize content blocks
        content = result.get("content", [])
        # If response came from Converse API wrapper
        if "output" in result and "message" in result.get("output", {}):
            content = result["output"]["message"].get("content", [])
            stop_reason = result.get("stopReason", stop_reason)

        normalized_content = []
        for block in content:
            if isinstance(block, dict):
                # Text block
                if block.get("type") == "text" or "text" in block and "type" not in block:
                    normalized_content.append({
                        "type": "text",
                        "text": block.get("text", "")
                    })
                # Tool use block (Anthropic format)
                elif block.get("type") == "tool_use":
                    normalized_content.append({
                        "type": "tool_use",
                        "id": block.get("id", ""),
                        "name": block.get("name", ""),
                        "input": block.get("input", {})
                    })
                # Tool use block (Converse format)
                elif block.get("type") == "toolUse" or "toolUse" in block:
                    tu = block if "name" in block else block.get("toolUse", {})
                    normalized_content.append({
                        "type": "tool_use",
                        "id": tu.get("toolUseId", "") or tu.get("id", ""),
                        "name": tu.get("name", ""),
                        "input": tu.get("input", {})
                    })

        # Normalize stop_reason
        if stop_reason in ("tool_use", "tool_calls"):
            stop_reason = "tool_use"
        elif stop_reason in ("end_turn", "stop", "max_tokens"):
            stop_reason = stop_reason
        else:
            stop_reason = "end_turn"

        return {
            "stop_reason": stop_reason,
            "content": normalized_content
        }

    def check_credentials(self) -> bool:
        """Check if AWS/CDAO credentials are valid."""
        try:
            self.converse(
                messages=[{"role": "user", "content": "Say OK"}],
                max_tokens=10
            )
            return True
        except Exception as e:
            err = str(e)
            if "InvalidClientTokenId" in err or "ExpiredTokenException" in err:
                logger.error("AWS credentials expired. Run: DevShell → pci aws login")
            elif "Expecting value" in err:
                logger.error("Empty Bedrock response — likely expired token.")
            else:
                logger.error(f"Bedrock credential check failed: {err}")
            return False
