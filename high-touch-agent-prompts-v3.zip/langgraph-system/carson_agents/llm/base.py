"""
Base LLM Client — Abstract interface for all LLM providers.

All providers (Bedrock/CDAO, Anthropic direct, local) implement this interface.
"""
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional
import logging
import time
from functools import wraps

logger = logging.getLogger("carson.llm")


def retry_on_throttle(max_retries: int = 3, backoff: float = 2.0):
    """Retry decorator for transient LLM errors (throttling, timeouts)."""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    err = str(e)
                    retriable = any(k in err for k in [
                        "ThrottlingException", "TooManyRequestsException",
                        "ServiceUnavailable", "overloaded", "rate_limit"
                    ])
                    if retriable and attempt < max_retries - 1:
                        wait = backoff ** attempt
                        logger.warning(f"Retriable error (attempt {attempt+1}): {err}. Waiting {wait}s...")
                        time.sleep(wait)
                        continue
                    raise
        return wrapper
    return decorator


class BaseLLMClient(ABC):
    """Abstract base class for LLM clients."""

    @abstractmethod
    def converse(
        self,
        messages: List[Dict[str, Any]],
        system: Optional[List[Dict[str, str]]] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
        model_id: Optional[str] = None,
        max_tokens: int = 4096,
    ) -> Dict[str, Any]:
        """
        Send a conversation to the LLM and get a response.

        Args:
            messages: List of message dicts [{"role": "user", "content": "..."}]
            system: Optional system prompts [{"text": "..."}]
            tools: Optional tool definitions (Anthropic format)
            model_id: Override the default model
            max_tokens: Max tokens in response

        Returns:
            Dict with normalized response:
            {
                "stop_reason": "end_turn" | "tool_use",
                "content": [
                    {"type": "text", "text": "..."} |
                    {"type": "tool_use", "id": "...", "name": "...", "input": {...}}
                ]
            }

        All providers MUST normalize their response to this format.
        """
        pass

    def check_credentials(self) -> bool:
        """Test if credentials are valid. Returns True if OK."""
        try:
            self.converse(
                messages=[{"role": "user", "content": "ping"}],
                max_tokens=10
            )
            return True
        except Exception as e:
            logger.error(f"Credential check failed: {e}")
            return False
