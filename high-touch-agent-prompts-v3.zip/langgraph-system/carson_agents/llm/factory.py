"""
LLM Client Factory — Creates the right client based on config.

Supports:
  - "bedrock": JPMC CDAO SDK (AWS Bedrock)
  - "anthropic": Direct Anthropic API (no AWS needed)
  - "mock": For testing without any LLM
"""
import logging
from typing import Dict, Any, Optional

from .base import BaseLLMClient

logger = logging.getLogger("carson.llm")

# Singleton instance
_client: Optional[BaseLLMClient] = None


def create_llm_client(config: Optional[Dict[str, Any]] = None) -> BaseLLMClient:
    """
    Create an LLM client based on configuration.

    Args:
        config: LLM config dict. If None, loads from config.yaml.

    Returns:
        BaseLLMClient instance
    """
    global _client
    if _client is not None and config is None:
        return _client

    if config is None:
        from ..config import get_llm_config
        config = get_llm_config()

    provider = config.get("provider", "bedrock")
    logger.info(f"Creating LLM client: provider={provider}")

    if provider == "bedrock":
        from .bedrock_client import BedrockLLMClient
        _client = BedrockLLMClient(config)

    elif provider == "anthropic":
        from .anthropic_client import AnthropicLLMClient
        _client = AnthropicLLMClient(config)

    elif provider == "mock":
        _client = MockLLMClient(config)

    else:
        raise ValueError(
            f"Unknown LLM provider: '{provider}'. "
            f"Supported: bedrock, anthropic, mock"
        )

    return _client


def get_llm_client() -> BaseLLMClient:
    """Get the singleton LLM client (creates if needed)."""
    if _client is None:
        return create_llm_client()
    return _client


class MockLLMClient(BaseLLMClient):
    """Mock LLM client for testing without any provider."""

    def __init__(self, config: Dict[str, Any] = None):
        self.responses = (config or {}).get("mock_responses", [])
        self._call_count = 0

    def converse(self, messages=None, system=None, tools=None,
                 model_id=None, max_tokens=4096):
        self._call_count += 1

        if self.responses and self._call_count <= len(self.responses):
            return self.responses[self._call_count - 1]

        return {
            "stop_reason": "end_turn",
            "content": [{"type": "text", "text": "Mock response from Carson."}]
        }
