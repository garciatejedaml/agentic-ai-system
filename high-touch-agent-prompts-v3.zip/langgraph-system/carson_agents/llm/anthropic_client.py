"""
Anthropic Direct Client — For teams WITHOUT Bedrock access.

Uses the Anthropic Python SDK directly (anthropic.Anthropic).
Requires ANTHROPIC_API_KEY environment variable.
"""
import os
import logging
from typing import List, Dict, Any, Optional

from .base import BaseLLMClient, retry_on_throttle

logger = logging.getLogger("carson.llm.anthropic")


class AnthropicLLMClient(BaseLLMClient):
    """LLM client using Anthropic API directly (no AWS/Bedrock)."""

    def __init__(self, config: Dict[str, Any]):
        """
        Args:
            config: LLM config from config.yaml, e.g.:
                {
                    "provider": "anthropic",
                    "model_id": "claude-sonnet-4-20250514",
                    "api_key_env": "ANTHROPIC_API_KEY"
                }
        """
        self.model_id = config.get("model_id", "claude-sonnet-4-20250514")
        api_key_env = config.get("api_key_env", "ANTHROPIC_API_KEY")
        api_key = config.get("api_key") or os.environ.get(api_key_env)

        if not api_key:
            raise ValueError(
                f"Anthropic API key not found. Set {api_key_env} env var "
                f"or add 'api_key' to config.yaml llm section."
            )

        self._client = None
        self._api_key = api_key

    def _get_client(self):
        if self._client is None:
            try:
                import anthropic
                self._client = anthropic.Anthropic(api_key=self._api_key)
            except ImportError:
                raise ImportError(
                    "anthropic package not installed. Run: pip install anthropic"
                )
        return self._client

    @retry_on_throttle(max_retries=3)
    def converse(
        self,
        messages: List[Dict[str, Any]],
        system: Optional[List[Dict[str, str]]] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
        model_id: Optional[str] = None,
        max_tokens: int = 4096,
    ) -> Dict[str, Any]:
        """Send conversation to Anthropic API directly."""
        client = self._get_client()

        kwargs = {
            "model": model_id or self.model_id,
            "max_tokens": max_tokens,
            "messages": messages,
        }

        if system:
            if isinstance(system, list):
                kwargs["system"] = "\n".join(s.get("text", "") for s in system)
            else:
                kwargs["system"] = system

        if tools:
            kwargs["tools"] = tools

        logger.debug(f"Anthropic request: model={kwargs['model']}, messages={len(messages)}")

        response = client.messages.create(**kwargs)

        # Anthropic SDK returns objects, convert to dict
        content = []
        for block in response.content:
            if block.type == "text":
                content.append({"type": "text", "text": block.text})
            elif block.type == "tool_use":
                content.append({
                    "type": "tool_use",
                    "id": block.id,
                    "name": block.name,
                    "input": block.input
                })

        return {
            "stop_reason": response.stop_reason,
            "content": content
        }
