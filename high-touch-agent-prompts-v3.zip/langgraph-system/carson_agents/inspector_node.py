"""
Inspector Node — Optional quality review for agent responses.

Can be added to the workflow to review agent responses before
sending to the user. Useful for safety checks on write operations.
"""
import logging
from .agent_state import CarsonState

logger = logging.getLogger("carson.inspector")


def inspector_node(state: CarsonState) -> CarsonState:
    """
    Review agent response for quality and safety.

    Currently a passthrough — extend with actual review logic as needed.
    """
    agent_response = state.get("agent_response", "")
    current_agent = state.get("current_agent", "")

    if not agent_response:
        logger.warning(f"[inspector] Empty response from {current_agent}")

    # Future: Add actual inspection logic here
    # - Check for PII in responses
    # - Validate tool results
    # - Ensure write operations have confirmation

    return state
