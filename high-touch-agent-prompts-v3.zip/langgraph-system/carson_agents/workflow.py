"""
Carson LangGraph Workflow — Orchestrates routing and agent execution.

Two flows:
  Simple:  planner → router → agent → confirmation → synthesizer → END
  Multi:   planner → plan_executor → agent → plan_step_complete
           → (more steps?) → plan_executor → ... → plan_synthesizer → END

The planner (Monsieur Planchet) decides which flow to use.
"""
import logging
from typing import Dict, Any

from langgraph.graph import StateGraph, END

from .agent_state import CarsonState
from .router.router_node import router_node, AGENT_NAMES
from .agents import AGENT_REGISTRY
from .planner_node import (
    planner_node,
    plan_executor_node,
    plan_step_complete_node,
    plan_synthesizer_node,
    should_plan,
    check_plan_done,
)

logger = logging.getLogger("carson.workflow")


def response_synthesizer(state: CarsonState) -> CarsonState:
    """
    Synthesize the final response from the agent's output.
    Wraps the agent response in Carson's butler persona.
    """
    agent_response = state.get("agent_response", "")
    current_agent = state.get("current_agent", "general")
    agent_name = AGENT_NAMES.get(current_agent, "the specialist")

    if not agent_response:
        final = (
            "I beg your pardon, Sir/Madam. It appears the specialist was unable "
            "to formulate a response. Might I suggest rephrasing the request?"
        )
    else:
        final = agent_response

    return {
        **state,
        "final_response": final,
    }


def confirmation_node(state: CarsonState) -> CarsonState:
    """
    Check if the agent requires confirmation for a write operation.
    If confirmation_required is set, the workflow pauses here.
    """
    if state.get("confirmation_required") and not state.get("confirmed"):
        logger.info(f"[confirmation] Awaiting confirmation: {state['confirmation_required']}")
        return state
    return state


def route_to_agent(state: CarsonState) -> str:
    """Conditional edge: route to the appropriate agent node."""
    intent = state.get("intent", "general")
    if intent in AGENT_REGISTRY:
        return intent
    logger.warning(f"[workflow] Unknown intent '{intent}', routing to general")
    return "general"


def check_confirmation(state: CarsonState) -> str:
    """Conditional edge: check if confirmation is needed."""
    if state.get("confirmation_required") and not state.get("confirmed"):
        return "needs_confirmation"
    return "proceed"


def after_confirmation_in_plan(state: CarsonState) -> str:
    """
    After confirmation check in a multi-step plan:
    - If needs confirmation → pause (END)
    - If in a plan → go to plan_step_complete
    - Otherwise → go to synthesizer (simple flow)
    """
    if state.get("confirmation_required") and not state.get("confirmed"):
        return "needs_confirmation"
    if state.get("needs_planning"):
        return "plan_step_complete"
    return "synthesize"


def build_workflow() -> StateGraph:
    """
    Build the Carson LangGraph workflow with Planner support.

    Graph:
        START → planner → (single?) → router → agent → confirmation → synthesizer → END
                        → (multi?)  → plan_executor → agent → confirmation
                                      → plan_step_complete → (more?) → plan_executor
                                                            → (done?) → plan_synthesizer → END
    """
    workflow = StateGraph(CarsonState)

    # --- Core Nodes ---
    workflow.add_node("planner", planner_node)
    workflow.add_node("router", router_node)
    workflow.add_node("synthesizer", response_synthesizer)
    workflow.add_node("confirmation", confirmation_node)

    # --- Plan Execution Nodes ---
    workflow.add_node("plan_executor", plan_executor_node)
    workflow.add_node("plan_step_complete", plan_step_complete_node)
    workflow.add_node("plan_synthesizer", plan_synthesizer_node)

    # --- Agent Nodes ---
    for agent_id, agent_fn in AGENT_REGISTRY.items():
        workflow.add_node(agent_id, agent_fn)

    # === ENTRY POINT ===
    workflow.set_entry_point("planner")

    # === PLANNER → conditional ===
    # Single-step queries go to router, multi-step go to plan_executor
    workflow.add_conditional_edges(
        "planner",
        should_plan,
        {
            "route": "router",       # Simple query → normal routing
            "plan": "plan_executor",  # Complex query → multi-step plan
        }
    )

    # === ROUTER → agent (simple flow) ===
    workflow.add_conditional_edges(
        "router",
        route_to_agent,
        {agent_id: agent_id for agent_id in AGENT_REGISTRY}
    )

    # === PLAN EXECUTOR → agent (multi-step flow) ===
    workflow.add_conditional_edges(
        "plan_executor",
        route_to_agent,  # Reuse: plan_executor sets intent, route_to_agent reads it
        {agent_id: agent_id for agent_id in AGENT_REGISTRY}
    )

    # === AGENT → confirmation ===
    for agent_id in AGENT_REGISTRY:
        workflow.add_edge(agent_id, "confirmation")

    # === CONFIRMATION → conditional ===
    workflow.add_conditional_edges(
        "confirmation",
        after_confirmation_in_plan,
        {
            "needs_confirmation": END,       # Pause for user confirmation
            "plan_step_complete": "plan_step_complete",  # Multi-step: record and continue
            "synthesize": "synthesizer",     # Simple: go to final synthesis
        }
    )

    # === PLAN STEP COMPLETE → conditional ===
    workflow.add_conditional_edges(
        "plan_step_complete",
        check_plan_done,
        {
            "next_step": "plan_executor",      # More steps → execute next
            "synthesize": "plan_synthesizer",  # All done → synthesize results
        }
    )

    # === TERMINALS → END ===
    workflow.add_edge("synthesizer", END)
    workflow.add_edge("plan_synthesizer", END)

    return workflow


def get_compiled_workflow():
    """Build and compile the workflow. Returns a runnable graph."""
    workflow = build_workflow()
    return workflow.compile()


# Pre-compiled workflow for import
compiled_workflow = None


def get_workflow():
    """Get or create the compiled workflow (lazy singleton)."""
    global compiled_workflow
    if compiled_workflow is None:
        compiled_workflow = get_compiled_workflow()
    return compiled_workflow
