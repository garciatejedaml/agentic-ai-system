"""Carson RAG — ChromaDB knowledge base integration."""
