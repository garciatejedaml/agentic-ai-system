"""
Carson Knowledge Base — ChromaDB-backed RAG for context-aware answers.

Supports:
  - Ingesting Python code files (chunked by function/class)
  - Ingesting Markdown documentation
  - Ingesting Confluence HTML pages (chunked by heading sections)
  - Querying with natural language
  - Multiple collections (repo_code, confluence_docs, runbooks, etc.)
"""
import os
import re
import glob
import html
import logging
from typing import List, Dict, Any, Optional

logger = logging.getLogger("carson.rag")


class CarsonKnowledgeBase:
    """ChromaDB-backed knowledge base for Carson."""

    def __init__(self, persist_dir: str = "./carson_kb"):
        self.persist_dir = persist_dir
        self._client = None

    def _get_client(self):
        if self._client is None:
            try:
                import chromadb
                self._client = chromadb.PersistentClient(path=self.persist_dir)
                logger.info(f"ChromaDB initialized at {self.persist_dir}")
            except ImportError:
                raise ImportError(
                    "chromadb not installed. Run: pip install chromadb"
                )
        return self._client

    def get_or_create_collection(self, name: str = "repo_code"):
        """Get or create a ChromaDB collection."""
        client = self._get_client()
        return client.get_or_create_collection(
            name=name,
            metadata={"hnsw:space": "cosine"}
        )

    def ingest_repo(self, repo_path: str, collection_name: str = "repo_code",
                    extensions: tuple = (".py", ".md", ".yaml", ".yml")):
        """
        Ingest code and doc files from a repository into ChromaDB.

        Args:
            repo_path: Path to repository root
            collection_name: ChromaDB collection name
            extensions: File extensions to ingest
        """
        collection = self.get_or_create_collection(collection_name)

        files = []
        for ext in extensions:
            files.extend(glob.glob(f"{repo_path}/**/*{ext}", recursive=True))

        ingested = 0
        for filepath in files:
            if "__pycache__" in filepath or ".git/" in filepath:
                continue

            try:
                content = open(filepath, encoding="utf-8", errors="replace").read()
                if not content.strip():
                    continue

                chunks = self._chunk_file(content, filepath)

                for i, chunk in enumerate(chunks):
                    doc_id = f"{filepath}::{i}"
                    collection.upsert(
                        documents=[chunk["text"]],
                        metadatas=[{
                            "source": filepath,
                            "type": chunk["type"],
                            "chunk_index": i
                        }],
                        ids=[doc_id]
                    )
                    ingested += 1

            except Exception as e:
                logger.warning(f"Failed to ingest {filepath}: {e}")

        logger.info(f"Ingested {ingested} chunks from {len(files)} files into '{collection_name}'")
        return ingested

    def query(self, question: str, collection_name: str = "repo_code",
              n_results: int = 5) -> Dict[str, Any]:
        """
        Query the knowledge base with a natural language question.

        Returns ChromaDB query results with documents and metadata.
        """
        try:
            collection = self.get_or_create_collection(collection_name)
            results = collection.query(
                query_texts=[question],
                n_results=n_results
            )
            return results
        except Exception as e:
            logger.error(f"RAG query failed: {e}")
            return {"documents": [[]], "metadatas": [[]], "distances": [[]]}

    def list_collections(self) -> List[str]:
        """List all available collections."""
        client = self._get_client()
        return [c.name for c in client.list_collections()]

    def get_collection_count(self, collection_name: str) -> int:
        """Get the number of documents in a collection."""
        collection = self.get_or_create_collection(collection_name)
        return collection.count()

    def delete_collection(self, collection_name: str) -> bool:
        """Delete a collection entirely (useful for re-ingestion)."""
        try:
            client = self._get_client()
            client.delete_collection(collection_name)
            logger.info(f"Deleted collection '{collection_name}'")
            return True
        except Exception as e:
            logger.warning(f"Could not delete collection '{collection_name}': {e}")
            return False

    # ------------------------------------------------------------------
    # Confluence HTML Ingestion
    # ------------------------------------------------------------------

    def ingest_confluence_pages(
        self,
        pages: List[Dict[str, Any]],
        collection_name: str = "confluence_docs",
    ) -> int:
        """
        Ingest a list of Confluence pages into ChromaDB.

        Each page dict should have:
          - "id": Confluence page ID
          - "title": page title
          - "space_key": Confluence space key
          - "html_content": raw Confluence storage-format HTML
          - "url": (optional) web URL for the page

        Returns the number of chunks ingested.
        """
        collection = self.get_or_create_collection(collection_name)
        ingested = 0

        for page in pages:
            page_id = page.get("id", "unknown")
            title = page.get("title", "Untitled")
            space = page.get("space_key", "")
            html_content = page.get("html_content", "")
            url = page.get("url", "")

            if not html_content.strip():
                continue

            try:
                chunks = self._chunk_confluence_html(html_content, title)

                for i, chunk in enumerate(chunks):
                    doc_id = f"confluence::{space}::{page_id}::{i}"
                    metadata = {
                        "source": f"confluence/{space}/{title}",
                        "type": chunk["type"],
                        "chunk_index": i,
                        "page_id": page_id,
                        "page_title": title,
                        "space_key": space,
                        "section_heading": chunk.get("heading", ""),
                    }
                    if url:
                        metadata["url"] = url

                    collection.upsert(
                        documents=[chunk["text"]],
                        metadatas=[metadata],
                        ids=[doc_id],
                    )
                    ingested += 1

            except Exception as e:
                logger.warning(f"Failed to ingest Confluence page '{title}' ({page_id}): {e}")

        logger.info(
            f"Ingested {ingested} chunks from {len(pages)} Confluence pages "
            f"into '{collection_name}'"
        )
        return ingested

    def _chunk_confluence_html(
        self, html_content: str, page_title: str
    ) -> List[Dict[str, str]]:
        """
        Chunk Confluence storage-format HTML into semantically meaningful pieces.

        Strategy:
        1. Extract and separate <ac:structured-macro> code blocks as their own chunks
        2. Split remaining content by heading tags (h1-h6)
        3. Convert HTML tables to readable text-table format
        4. Strip all remaining HTML tags, preserving text content
        5. Each chunk includes the page title and section heading as context

        This produces chunks that are:
        - Semantically coherent (one topic per chunk)
        - Searchable (headings + page title in text)
        - Not too big (max ~1500 chars, split further if needed)
        """
        chunks = []

        # --- Step 1: Extract code blocks as separate chunks ---
        code_pattern = re.compile(
            r'<ac:structured-macro[^>]*ac:name="code"[^>]*>'
            r'.*?<ac:plain-text-body><!\[CDATA\[(.*?)\]\]>'
            r'</ac:plain-text-body>.*?</ac:structured-macro>',
            re.DOTALL,
        )
        code_blocks = []
        for match in code_pattern.finditer(html_content):
            code_text = match.group(1).strip()
            if code_text and len(code_text) > 20:
                code_blocks.append(code_text)

        # Remove code blocks from HTML so they don't appear twice
        cleaned_html = code_pattern.sub("", html_content)

        # Add code chunks
        for idx, code in enumerate(code_blocks):
            chunks.append({
                "text": f"[Page: {page_title}] [Code Block {idx + 1}]\n{code[:1500]}",
                "type": "code_block",
                "heading": f"Code Block {idx + 1}",
            })

        # --- Step 2: Convert tables to text ---
        cleaned_html = self._html_tables_to_text(cleaned_html)

        # --- Step 3: Split by headings ---
        # Insert markers before heading tags for splitting
        heading_pattern = re.compile(r'<(h[1-6])[^>]*>(.*?)</\1>', re.DOTALL | re.IGNORECASE)
        sections = []
        last_end = 0
        current_heading = "Introduction"

        for match in heading_pattern.finditer(cleaned_html):
            # Grab content before this heading
            before = cleaned_html[last_end:match.start()]
            before_text = self._strip_html(before).strip()
            if before_text and len(before_text) > 30:
                sections.append((current_heading, before_text))

            current_heading = self._strip_html(match.group(2)).strip() or "Section"
            last_end = match.end()

        # Grab remaining content after last heading
        remaining = cleaned_html[last_end:]
        remaining_text = self._strip_html(remaining).strip()
        if remaining_text and len(remaining_text) > 30:
            sections.append((current_heading, remaining_text))

        # --- Step 4: Build chunks from sections ---
        MAX_CHUNK_SIZE = 1500

        for heading, text in sections:
            full_text = f"[Page: {page_title}] [{heading}]\n{text}"

            if len(full_text) <= MAX_CHUNK_SIZE:
                chunks.append({
                    "text": full_text,
                    "type": "documentation",
                    "heading": heading,
                })
            else:
                # Split large sections by paragraph (double newline)
                paragraphs = re.split(r'\n\n+', text)
                current_part = ""
                part_num = 1

                for para in paragraphs:
                    if len(current_part) + len(para) + 2 > MAX_CHUNK_SIZE and current_part:
                        chunks.append({
                            "text": f"[Page: {page_title}] [{heading} (part {part_num})]\n{current_part.strip()}",
                            "type": "documentation",
                            "heading": f"{heading} (part {part_num})",
                        })
                        current_part = para + "\n\n"
                        part_num += 1
                    else:
                        current_part += para + "\n\n"

                if current_part.strip():
                    chunks.append({
                        "text": f"[Page: {page_title}] [{heading} (part {part_num})]\n{current_part.strip()}",
                        "type": "documentation",
                        "heading": f"{heading} (part {part_num})" if part_num > 1 else heading,
                    })

        # Fallback: if no chunks were created, treat whole page as one chunk
        if not chunks:
            plain = self._strip_html(html_content).strip()
            if plain:
                chunks.append({
                    "text": f"[Page: {page_title}]\n{plain[:2000]}",
                    "type": "documentation",
                    "heading": "",
                })

        return chunks

    def _html_tables_to_text(self, html_content: str) -> str:
        """
        Convert HTML tables to a readable text format.

        <table><tr><th>Name</th><th>Age</th></tr><tr><td>Alice</td><td>30</td></tr></table>
        becomes:
        Name | Age
        Alice | 30
        """
        table_pattern = re.compile(r'<table[^>]*>(.*?)</table>', re.DOTALL | re.IGNORECASE)

        def table_to_text(match):
            table_html = match.group(1)
            rows = re.findall(r'<tr[^>]*>(.*?)</tr>', table_html, re.DOTALL | re.IGNORECASE)
            text_rows = []
            for row in rows:
                cells = re.findall(
                    r'<(?:td|th)[^>]*>(.*?)</(?:td|th)>',
                    row, re.DOTALL | re.IGNORECASE
                )
                clean_cells = [self._strip_html(c).strip() for c in cells]
                if any(clean_cells):
                    text_rows.append(" | ".join(clean_cells))
            return "\n".join(text_rows) + "\n"

        return table_pattern.sub(table_to_text, html_content)

    def _strip_html(self, text: str) -> str:
        """Strip HTML tags and decode entities, preserving meaningful whitespace."""
        # Remove Confluence macros
        text = re.sub(r'<ac:[^>]*/?>', '', text)
        text = re.sub(r'</ac:[^>]*>', '', text)
        # Convert <br> and <p> to newlines
        text = re.sub(r'<br\s*/?>', '\n', text, flags=re.IGNORECASE)
        text = re.sub(r'</p>', '\n', text, flags=re.IGNORECASE)
        text = re.sub(r'<li[^>]*>', '- ', text, flags=re.IGNORECASE)
        text = re.sub(r'</li>', '\n', text, flags=re.IGNORECASE)
        # Strip all remaining tags
        text = re.sub(r'<[^>]+>', '', text)
        # Decode HTML entities
        text = html.unescape(text)
        # Collapse excessive whitespace but keep paragraph breaks
        text = re.sub(r'[ \t]+', ' ', text)
        text = re.sub(r'\n{3,}', '\n\n', text)
        return text.strip()

    def query_multiple(
        self,
        question: str,
        collection_names: List[str],
        n_results: int = 3,
    ) -> List[Dict[str, Any]]:
        """
        Query multiple collections and merge results by relevance (distance).

        Returns a flat list of {"text": ..., "metadata": ..., "distance": ..., "collection": ...}
        sorted by distance (best match first).
        """
        all_results = []

        for coll_name in collection_names:
            try:
                results = self.query(question, collection_name=coll_name, n_results=n_results)
                docs = results.get("documents", [[]])[0]
                metas = results.get("metadatas", [[]])[0]
                dists = results.get("distances", [[]])[0]

                for doc, meta, dist in zip(docs, metas, dists):
                    all_results.append({
                        "text": doc,
                        "metadata": meta,
                        "distance": dist,
                        "collection": coll_name,
                    })
            except Exception as e:
                logger.debug(f"Query failed for collection '{coll_name}': {e}")

        # Sort by distance (lower = more similar in cosine space)
        all_results.sort(key=lambda x: x["distance"])
        return all_results

    def _chunk_file(self, content: str, filepath: str) -> List[Dict[str, str]]:
        """
        Split file content into meaningful chunks.

        For Python: chunks by function/class definitions
        For Markdown: chunks by headers
        For other files: chunks by paragraph
        """
        if filepath.endswith(".py"):
            return self._chunk_python(content, filepath)
        elif filepath.endswith(".md"):
            return self._chunk_markdown(content, filepath)
        else:
            return self._chunk_generic(content, filepath)

    def _chunk_python(self, content: str, filepath: str) -> List[Dict]:
        """Chunk Python code by function and class definitions."""
        chunks = []
        lines = content.split("\n")
        current_chunk = []
        current_type = "module_header"

        for line in lines:
            stripped = line.lstrip()
            if stripped.startswith("class ") or stripped.startswith("def "):
                if current_chunk:
                    text = "\n".join(current_chunk)
                    if text.strip():
                        chunks.append({"text": text, "type": current_type})
                current_chunk = [f"# File: {filepath}", line]
                current_type = "class" if stripped.startswith("class") else "function"
            else:
                current_chunk.append(line)

        if current_chunk:
            text = "\n".join(current_chunk)
            if text.strip():
                chunks.append({"text": text, "type": current_type})

        # If no chunks were created, treat whole file as one chunk
        if not chunks and content.strip():
            chunks.append({"text": f"# File: {filepath}\n{content}", "type": "module"})

        return chunks

    def _chunk_markdown(self, content: str, filepath: str) -> List[Dict]:
        """Chunk Markdown by headers."""
        chunks = []
        sections = re.split(r'\n(?=#{1,3}\s)', content)

        for section in sections:
            if section.strip():
                chunks.append({
                    "text": f"Source: {filepath}\n{section.strip()}",
                    "type": "documentation"
                })

        if not chunks and content.strip():
            chunks.append({"text": content, "type": "documentation"})

        return chunks

    def _chunk_generic(self, content: str, filepath: str) -> List[Dict]:
        """Chunk generic files by paragraphs (double newlines)."""
        paragraphs = re.split(r'\n\n+', content)
        chunks = []

        for para in paragraphs:
            if para.strip() and len(para.strip()) > 20:
                chunks.append({
                    "text": f"Source: {filepath}\n{para.strip()}",
                    "type": "text"
                })

        if not chunks and content.strip():
            chunks.append({"text": content[:2000], "type": "text"})

        return chunks
