# Spinnaker Deployment Patterns

## Repo-to-App Mapping
- Repository names map to Spinnaker application names via `config.yaml → agents.deploy.repo_to_app_map`
- Terraform repos get a suffix (e.g., "-global") via `terraform_app_suffix`
- If a repo isn't in the map, assume the Spinnaker app name matches the repo

## Branch-to-Pipeline Mapping
- Branches map to pipeline environments via `config.yaml → agents.deploy.branch_to_pipeline`
- AHTW-specific mapping:
  - `feature/uat-*` → deploy to UAT environment
  - `develop` → deploy to PRE (pre-production)
  - `main` → deploy to PRE first, then PROD (requires promotion)
  - Production deploys require manual approval

## Build Monitoring Integration
After Jenkins build success:
1. Check for `spinnaker-trigger.yml` in the repo root
2. If present, the Spinnaker pipeline triggers automatically
3. Use `get_pipeline_status` to verify the triggered execution
4. Report status to user: pipeline name, execution ID, current stage

## Deployment Safety Protocol
1. Always check current deployed version first (get_deployments)
2. Show user: app name, environment, version, pipeline
3. Require explicit confirmation for any trigger
4. For PRODUCTION: require DOUBLE confirmation
5. For rollbacks: confirm target version exists and is stable

## Environment Hierarchy
- dev → uat → pre → prod
- Never skip environments unless explicitly authorized
- Rollbacks should target the last known stable version
