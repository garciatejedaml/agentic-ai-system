# Git & PR Conventions

## Branching Strategy
| Branch Pattern | Purpose | Deploys To |
|---|---|---|
| `feature/uat-<workflow>` | UAT environment per workflow | UAT |
| `feature/CREDITTECH-<number>-<desc>` | Feature development | UAT (via parent) |
| `develop` | Pre-production integration | PRE |
| `main` | Release branch | PRE -> PROD |

## AMPS Workflow Repository Structure
Repos named `high-touch-<product>-amps` contain AMPS workflow folders:
```
<repo-root>/
  workflow-1/          (e.g. rfq-feed/)
    topics.xml
    actions.xml
    ...
  workflow-2/          (e.g. bond/)
    topics.xml
    actions.xml
```

### Branch-to-Workflow Mapping
- `feature/uat-<workflow>`: Contains ONLY that workflow's folder (e.g. `feature/uat-rfq-feed` -> `rfq-feed/`)
- `develop`: Contains ALL workflow folders
- `main`: Contains ALL workflow folders (same as develop)

### Finding the Right Branch
1. Identify the workflow name from the folder the user wants to modify
2. Use branch `feature/uat-<workflow>` for UAT changes
3. Create feature branches FROM `feature/uat-<workflow>`, NOT from `develop`

## Jira Ticket Requirement (CRITICAL)
Bitbucket requires a valid Jira ticket ID in all commits. Workflow:
1. Jira ticket MUST exist FIRST
2. Move ticket to "In Progress" when starting work
3. THEN create branch with ticket ID (e.g. `feature/CREDITTECH-123-add-rfq-topic`)
4. THEN commit and push (commit message must include ticket ID)

## Multiple Bitbucket Projects
- Check `config.yaml -> team.bitbucket_projects` for the project list
- Use `default_bitbucket_project` when user doesn't specify
- Common projects: CREDITTECH, ACAMPS

## Protected Branches (CRITICAL)
- NEVER use git CLI push to main, master, or develop
- ALWAYS use `createPullRequest` MCP tool instead
- Direct commits only to feature branches

## PR Creation - Confirmation Required
Before creating any PR, summarize:
- **Repository:** `high-touch-<product>-amps`
- **Branch:** `feature/CREDITTECH-<ticket>` -> `<target-branch>`
- **Jira Ticket:** CREDITTECH-<ticket>
- **Modified files** list
- **Deploy target:** UAT/PRE/PROD
Then ask: "Should I proceed with the commit and PR, Sir/Madam?"

## PR Best Practices
- Title format: `[CREDITTECH-NNN] Short description`
- PR should have at least 1 reviewer
- All PRs must pass CI before merge
- For AMPS repos: always include maintenance schedule in the PR description

## Code Review Guidelines
- Check for: security issues, error handling, test coverage
- Look at diff size - large PRs should be flagged
- Verify branch target (feature -> develop, hotfix -> main)
