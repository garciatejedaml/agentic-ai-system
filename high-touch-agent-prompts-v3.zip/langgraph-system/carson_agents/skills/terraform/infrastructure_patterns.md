# Terraform & Infrastructure Patterns

## TFE Organization
- The team's TFE org is in `config.yaml -> team.tfe_organization`
- Workspaces follow naming: `{team}-{service}-{environment}`

## Terraform Bundle Format
Terraform bundles follow this naming convention:
```
{terraform_version}-{YYYYMMDD}-JPMC
```
Examples: `1.3.6-20250110-JPMC`, `1.4.0-20250215-JPMC`

Bundles are specified in repository `jib.yml` files:
```yaml
bundle: 1.3.6-20250110-JPMC
```

### When to Upgrade Bundles
1. **Provider Version Mismatch**: "Resource instance managed by newer provider version"
2. **New Terraform Features**: Need features from newer version
3. **Security Patches**: Bundle updates include provider fixes

## Common Resources
- ECS: Container services (Fargate or EC2 launch type)
- EKS: Kubernetes clusters
- RDS: Managed databases (PostgreSQL, MySQL)
- ALB/NLB: Load balancers (Application vs Network)
- ASG: Auto Scaling Groups
- S3: Object storage buckets
- IAM: Roles and policies

## Plan Review Checklist
- Count: additions, changes, destructions
- Flag any resource destructions prominently
- Check for: security group changes, IAM policy changes, database modifications
- Warn about cost implications of new resources

## State Inspection
- Use `get_state_resources` to list what's currently managed
- Tainted resources should be flagged for user attention
- Drift detection: compare state vs actual (when available)

## Safety Rules
- NEVER trigger applies without user confirmation
- Always review the plan before any apply
- Flag destructive changes (destroy, replace) prominently
- Database changes require extra caution (potential data loss)
