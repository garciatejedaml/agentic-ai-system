# Confluence Documentation Patterns

## Space Structure
- The team's Confluence space is in `config.yaml → team.confluence_space`
- Common page hierarchy: Space Home → Project → Component → Page

## Search Tips
- CQL (Confluence Query Language) for precise searches
- `text ~ "keyword"` for full-text search
- `space = "KEY" AND title = "exact title"` for specific pages
- Always try multiple query variations if first search returns nothing

## Content Formatting
- Confluence uses "storage format" (XHTML)
- Headings: `<h1>`, `<h2>`, etc.
- Tables: `<table><tr><td>...</td></tr></table>`
- Code blocks: `<ac:structured-macro ac:name="code"><ac:plain-text-body>...</ac:plain-text-body></ac:structured-macro>`
- When creating pages, always use proper structure with headings

## Common Operations
- "Find docs about X" → search_pages with query
- "What does page Y say?" → get_page or get_page_by_title
- "Create a runbook for Z" → create_page with structured template
- "Update the deployment guide" → get_page first, then update_page
