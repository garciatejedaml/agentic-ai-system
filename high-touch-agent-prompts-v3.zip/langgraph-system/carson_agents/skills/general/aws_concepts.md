# AWS Concepts for JPMC Teams

## CDAO SDK
- JPMC's internal SDK for AWS Bedrock access
- NEVER use boto3 directly — always use `cdao.bedrock_byoa_invoke_model(data, payload)`
- Requires: AWS_ACCOUNT_NUMBER, AWS_REGION, WORKSPACE_ID

## Common AWS Services at JPMC
- **ECS (Fargate)**: Serverless containers — most common compute
- **EKS**: Kubernetes — for teams needing k8s features
- **RDS**: Managed databases (Aurora PostgreSQL common)
- **ALB**: Application Load Balancer — HTTP/HTTPS routing
- **NLB**: Network Load Balancer — TCP/UDP, lower latency
- **S3**: Object storage — configs, artifacts, logs
- **CloudWatch**: Monitoring, logs, alarms
- **IAM**: Identity and Access Management — roles, policies

## Credential Management
- AWS tokens expire — refresh via DevShell: `pci aws login`
- Watch for: `InvalidClientTokenId`, `ExpiredTokenException`
- If expired: tell user to refresh via DevShell and restart Carson

## Terraform Enterprise (TFE)
- Infrastructure as Code — all AWS resources managed via TFE
- Each team has an organization in TFE
- Workspaces map to service+environment combinations
