# AMPS Knowledge Base

## What is AMPS?
Advanced Message Processing System — a high-performance pub/sub messaging platform.
Used extensively in High Touch Workflow for real-time order and trade messaging.

## Key Concepts
- **Topics**: Message channels defined in `topics.xml`
- **Actions**: Processing rules defined in `actions.xml`
- **SOW (State of the World)**: Queryable message store
- **Bookmark**: Position marker for replay
- **Content filtering**: Subscribe with filters to receive only relevant messages

## Configuration Files
- `topics.xml`: Defines topic names, types, message expiry
- `actions.xml`: Defines transformations, routing, aggregation, maintenance schedules
- `deployment_policy.yml`: Region/environment-specific deployment config
- `amps.cfg`: Main server configuration

## AMPS Workflow Repositories
Repos named `high-touch-<product>-amps` contain workflow folders:
```
<repo-root>/
  rfq-feed/
    topics.xml
    actions.xml
  bond/
    topics.xml
    actions.xml
  ptf/
    topics.xml
    actions.xml
```

Each workflow folder contains the AMPS configuration for that product workflow.

## Action XML Patterns

### Daily Maintenance Action (midnight)
```xml
<Action>
  <On>
    <Module>amps-action-on-schedule</Module>
    <Options>
      <Every>00:00</Every>
      <Name>Maintenance for <topic_name></Name>
    </Options>
  </On>
  <Do>
    <Module>amps-action-do-delete-sow</Module>
    <Options>
      <Topic><topic_name></Topic>
      <MessageType>json</MessageType>
      <Filter>1=1</Filter>
    </Options>
  </Do>
</Action>
```

### Weekly Maintenance Action (Sundays at midnight)
```xml
<Action>
  <On>
    <Module>amps-action-on-schedule</Module>
    <Options>
      <Every>Sunday 00:00</Every>
      <Name>Weekly cleanup for <topic_name></Name>
    </Options>
  </On>
  <Do>
    <Module>amps-action-do-delete-sow</Module>
    <Options>
      <Topic><topic_name></Topic>
      <MessageType>json</MessageType>
      <Filter>1=1</Filter>
    </Options>
  </Do>
</Action>
```

## Schedule Types
- **Specific time**: `<Every>00:00</Every>` (daily at midnight)
- **Specific day/time**: `<Every>Friday at 18:00</Every>`
- **No cleanup needed**: Data persists indefinitely

## Common Questions
- "How do topics work?" -> Explain pub/sub with topics.xml structure
- "What's a SOW query?" -> State of World - queryable message store
- "How to add a new topic?" -> Edit topics.xml, add topic definition, then commit via feature branch
- "Which schedule should I use?" -> Depends on data retention needs: daily for transient, weekly for semi-persistent, none for permanent
- "How do I identify workflows in a repo?" -> List `feature/uat-*` branches OR check directory structure

## Repository Coordinates
- **Bitbucket Project**: ACAMPS (or as configured)
- **Default branch**: develop
- **UAT branches**: feature/uat-<workflow-name>
