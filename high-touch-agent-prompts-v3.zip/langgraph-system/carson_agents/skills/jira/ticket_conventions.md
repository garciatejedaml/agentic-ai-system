# Jira Ticket Conventions

## Ticket Prefixes
- The team's Jira project key is loaded from `config.yaml → team.project_key`
- Example: CREDITTECH-1234, AHTW-567

## Status Workflow
- To Do → In Progress → In Review → Done
- Use `update_issue_status` to transition tickets

## Story Point Estimates
- 1 point = trivial change (config, typo)
- 2 points = small feature or bugfix
- 3 points = medium feature with tests
- 5 points = large feature, multi-file
- 8+ points = epic-level, should be split

## Sprint Conventions
- Sprints are 2 weeks
- Sprint names follow: "Sprint {N} - {date range}"
- Use `get_sprints_for_board` to find current sprint, then `get_sprint_issues` for board view

## Comment Formatting
- When adding comments via `add_comment`, use Jira wiki markup:
  - `*bold*`, `_italic_`, `{code}inline{code}`
  - `{code:python}...{code}` for code blocks
