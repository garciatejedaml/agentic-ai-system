"""
Dynamic Skill Loader — Load agent skills from markdown files.

Skills are markdown files in the skills/ directory that provide
additional context and instructions for agents.

Structure:
    skills/
      jira/
        sprint_management.md
        ticket_templates.md
      git/
        pr_conventions.md
      general/
        amps_knowledge.md
        aws_concepts.md
"""
import os
import logging
from pathlib import Path
from typing import Dict, List, Optional

logger = logging.getLogger("carson.skills")


SKILLS_DIR = Path(__file__).parent


def load_skills_for_agent(agent_name: str) -> str:
    """
    Load all skill files for a specific agent.

    Returns concatenated skill content as a string to append to system prompt.
    """
    agent_skills_dir = SKILLS_DIR / agent_name

    if not agent_skills_dir.exists():
        return ""

    skills = []
    for skill_file in sorted(agent_skills_dir.glob("*.md")):
        try:
            content = skill_file.read_text(encoding="utf-8")
            skills.append(f"### Skill: {skill_file.stem}\n{content}")
        except Exception as e:
            logger.warning(f"Failed to load skill {skill_file}: {e}")

    if skills:
        logger.info(f"Loaded {len(skills)} skills for agent '{agent_name}'")
        return "\n\n" + "\n\n".join(skills)

    return ""


def list_available_skills() -> Dict[str, List[str]]:
    """List all available skills organized by agent."""
    result = {}
    for agent_dir in SKILLS_DIR.iterdir():
        if agent_dir.is_dir() and not agent_dir.name.startswith("_"):
            skills = [f.stem for f in agent_dir.glob("*.md")]
            if skills:
                result[agent_dir.name] = skills
    return result
