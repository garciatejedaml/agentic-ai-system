"""
Monsieur Planchet — The Majordomo (Planner Node).

Detects multi-step requests and orchestrates agents in sequence.
Named after d'Artagnan's resourceful servant who coordinated everyone.

Single-agent queries bypass the planner entirely (no overhead).
Multi-agent queries get decomposed into a plan:
  Step 1: Jira → get ticket details
  Step 2: Git → create branch using ticket context
  ...

Each step's result is passed as context to the next step.
"""
import json
import logging
from typing import Dict, Any, List, Optional

from .agent_state import CarsonState
from .llm import get_llm_client

logger = logging.getLogger("carson.planner")


PLANNER_SYSTEM_PROMPT = """You are Monsieur Planchet, the Majordomo of the Carson household.
Your role is to decompose complex, multi-agent requests into an ordered plan of steps.

## When to Plan
Only create a multi-step plan when the request CLEARLY requires multiple agents.
If it's a single-agent task, return a single step.

## Available Agents
- jira: Jira tickets, sprints, status transitions (tools: get_issue, search_issues, create_jira_issue, add_comment, update_issue_status)
- git: Bitbucket repos, branches, PRs, commits (tools: listRepositories, getBranches, createBranch, createPullRequest, commitFile)
- build: Jenkins CI/CD builds (tools: getJobs, getBuildDetails, getBuildConsoleOutput, triggerBuild)
- deploy: Spinnaker deployments (tools: get_pipelines, get_deployments, trigger_pipeline, rollback)
- terraform: TFE workspaces, plans (tools: list_workspaces, get_workspace_runs, get_plan_logs)
- docs: Confluence documentation (tools: search_pages, get_page, create_page, update_page)
- general: General knowledge, AMPS, AWS concepts (no tools — answers from knowledge)

## Common Multi-Step Patterns

"Create a branch for ticket AHTW-123":
  1. jira: get_issue(AHTW-123) → get title and details
  2. git: createBranch(feature/AHTW-123-{slugified-title})

"What's the status of my PR and its build?":
  1. git: getPullRequests → find the user's open PR
  2. build: getBuildDetails → get build status for that branch

"Deploy the latest build to UAT":
  1. build: getBuildDetails → verify latest build succeeded
  2. deploy: trigger_pipeline → trigger UAT pipeline (with confirmation)

"Create a ticket and start working on it":
  1. jira: create_jira_issue → create the ticket
  2. jira: update_issue_status → move to "In Progress"
  3. git: createBranch → create feature branch

"Build failed, what happened and is there a related ticket?":
  1. build: getBuildConsoleOutput → get failure logs
  2. jira: search_issues → search for related tickets

## Response Format
Return a JSON plan. NOTHING ELSE — no markdown, no explanation, just JSON:

For single-agent (no planning needed):
{"plan_type": "single", "agent": "jira", "reasoning": "Simple ticket lookup"}

For multi-agent:
{
  "plan_type": "multi",
  "steps": [
    {"step": 1, "agent": "jira", "action": "Get ticket AHTW-123 details", "extract": "title, status, description"},
    {"step": 2, "agent": "git", "action": "Create branch feature/AHTW-123-{title_slug} from develop", "depends_on": 1}
  ],
  "reasoning": "Need ticket details before creating branch"
}

RULES:
- Maximum 4 steps (keep plans tight)
- Each step has: step number, agent, action description, what to extract
- If step depends on a previous result, note "depends_on": step_number
- WRITE operations must note "confirm": true
"""


PLANNER_TOOLS = [
    {
        "name": "create_plan",
        "description": "Create an execution plan for the user's request",
        "input_schema": {
            "type": "object",
            "properties": {
                "plan_type": {
                    "type": "string",
                    "enum": ["single", "multi"],
                    "description": "Whether this needs a single agent or multiple"
                },
                "agent": {
                    "type": "string",
                    "description": "For single plans: the agent ID",
                    "enum": ["jira", "git", "build", "deploy", "terraform", "docs", "general"]
                },
                "steps": {
                    "type": "array",
                    "description": "For multi plans: ordered list of steps",
                    "items": {
                        "type": "object",
                        "properties": {
                            "step": {"type": "number", "description": "Step number (1-based)"},
                            "agent": {"type": "string", "description": "Agent ID for this step"},
                            "action": {"type": "string", "description": "What this step should do"},
                            "extract": {"type": "string", "description": "What data to extract from the result"},
                            "depends_on": {"type": "number", "description": "Step number this depends on"},
                            "confirm": {"type": "boolean", "description": "Whether this step needs user confirmation"}
                        },
                        "required": ["step", "agent", "action"]
                    }
                },
                "reasoning": {
                    "type": "string",
                    "description": "Brief explanation of the plan"
                }
            },
            "required": ["plan_type", "reasoning"]
        }
    }
]


def planner_node(state: CarsonState) -> CarsonState:
    """
    Analyze a request and create an execution plan.

    If the request is simple (single agent), creates a single-step plan.
    If complex (multi-agent), creates an ordered multi-step plan.

    Returns updated state with 'plan' field set.
    """
    user_request = state.get("user_request", "")
    logger.info(f"[planner] Analyzing: {user_request[:100]}")

    try:
        llm = get_llm_client()

        response = llm.converse(
            messages=[{"role": "user", "content": user_request}],
            system=[{"text": PLANNER_SYSTEM_PROMPT}],
            tools=PLANNER_TOOLS,
        )

        stop_reason = response.get("stop_reason", "end_turn")
        content = response.get("content", [])

        plan = None

        if stop_reason == "tool_use":
            for block in content:
                if block.get("type") == "tool_use" and block.get("name") == "create_plan":
                    plan = block.get("input", {})
                    break

        elif stop_reason == "end_turn":
            # Try to parse JSON from text response
            for block in content:
                if block.get("type") == "text":
                    text = block.get("text", "").strip()
                    try:
                        plan = json.loads(text)
                    except json.JSONDecodeError:
                        pass
                    break

        if plan is None:
            # Fallback: treat as single-agent, let router decide
            logger.warning("[planner] Could not create plan, falling back to router")
            return {
                **state,
                "plan": {"plan_type": "single", "reasoning": "Fallback — planner could not analyze"},
                "needs_planning": False,
            }

        plan_type = plan.get("plan_type", "single")
        logger.info(f"[planner] Plan type: {plan_type}, reasoning: {plan.get('reasoning', '')}")

        if plan_type == "multi":
            steps = plan.get("steps", [])
            logger.info(f"[planner] Multi-step plan with {len(steps)} steps:")
            for step in steps:
                logger.info(f"  Step {step['step']}: {step['agent']} → {step['action']}")

        return {
            **state,
            "plan": plan,
            "plan_steps_completed": [],
            "plan_current_step": 0,
            "needs_planning": plan_type == "multi",
            # For single plans, set intent directly so router can skip
            "intent": plan.get("agent", "") if plan_type == "single" else "",
        }

    except Exception as e:
        logger.error(f"[planner] Error: {e}. Falling back.")
        return {
            **state,
            "plan": {"plan_type": "single", "reasoning": f"Planner error: {e}"},
            "needs_planning": False,
        }


def plan_executor_node(state: CarsonState) -> CarsonState:
    """
    Execute the next step in a multi-step plan.

    Reads the current plan, determines which step to execute next,
    prepares the context from previous steps, and sets the intent
    for the agent to execute.

    After each agent completes, this node checks if there are more steps.
    """
    plan = state.get("plan", {})
    steps = plan.get("steps", [])
    completed = state.get("plan_steps_completed", [])
    current_step_idx = state.get("plan_current_step", 0)

    if current_step_idx >= len(steps):
        # All steps done — synthesize final response
        logger.info("[plan_executor] All plan steps completed")
        return {
            **state,
            "plan_done": True,
        }

    step = steps[current_step_idx]
    agent_id = step.get("agent", "general")
    action = step.get("action", "")
    needs_confirm = step.get("confirm", False)

    logger.info(f"[plan_executor] Executing step {current_step_idx + 1}/{len(steps)}: {agent_id} → {action}")

    # Build enriched request with context from previous steps
    enriched_request = _build_step_request(state, step, completed)

    return {
        **state,
        "intent": agent_id,
        "current_agent": agent_id,
        "user_request": enriched_request,
        "plan_current_step": current_step_idx,
        "original_request": state.get("original_request", state.get("user_request", "")),
    }


def plan_step_complete_node(state: CarsonState) -> CarsonState:
    """
    Called after an agent completes a plan step.
    Records the result and advances to the next step.
    """
    plan = state.get("plan", {})
    steps = plan.get("steps", [])
    completed = list(state.get("plan_steps_completed", []))
    current_step_idx = state.get("plan_current_step", 0)

    if current_step_idx < len(steps):
        step = steps[current_step_idx]
        completed.append({
            "step": step.get("step", current_step_idx + 1),
            "agent": step.get("agent", ""),
            "action": step.get("action", ""),
            "result": state.get("agent_response", ""),
        })

    next_step = current_step_idx + 1
    all_done = next_step >= len(steps)

    logger.info(
        f"[plan_step_complete] Step {current_step_idx + 1} done. "
        f"{'All steps complete.' if all_done else f'Next: step {next_step + 1}'}"
    )

    return {
        **state,
        "plan_steps_completed": completed,
        "plan_current_step": next_step,
        "plan_done": all_done,
    }


def plan_synthesizer_node(state: CarsonState) -> CarsonState:
    """
    Synthesize a final response from all completed plan steps.

    Combines the results of each step into a coherent Carson-style response.
    """
    completed = state.get("plan_steps_completed", [])
    original_request = state.get("original_request", state.get("user_request", ""))
    plan = state.get("plan", {})

    if not completed:
        return {
            **state,
            "agent_response": "I attempted to execute the plan but no steps completed successfully.",
        }

    try:
        llm = get_llm_client()

        # Build a summary prompt
        steps_summary = ""
        for c in completed:
            steps_summary += f"\n--- Step {c['step']} ({c['agent']}: {c['action']}) ---\n"
            steps_summary += c.get("result", "No result")[:500]
            steps_summary += "\n"

        synthesis_prompt = f"""You are Carson, the distinguished AI butler.
The user asked: "{original_request}"

Monsieur Planchet (the Majordomo) coordinated a multi-step plan.
Here are the results of each step:

{steps_summary}

Synthesize a single, coherent response that:
1. Addresses the user's original request
2. Summarizes what was accomplished across all steps
3. Notes any steps that need user confirmation (WRITE operations)
4. Maintains your butler persona (address as Sir/Madam)
5. Is concise — max 5-6 sentences

Do NOT list the steps mechanically. Weave the information naturally."""

        response = llm.converse(
            messages=[{"role": "user", "content": synthesis_prompt}],
            system=[{"text": "You are Carson, a distinguished British AI butler. Be concise and natural."}],
        )

        synthesis = ""
        for block in response.get("content", []):
            if block.get("type") == "text":
                synthesis += block.get("text", "")

        if not synthesis:
            # Fallback: simple concatenation
            parts = []
            for c in completed:
                parts.append(f"**{c['action']}**: {c.get('result', 'Completed')[:200]}")
            synthesis = "Very good. Here's what was accomplished:\n" + "\n".join(parts)

    except Exception as e:
        logger.error(f"[plan_synthesizer] Synthesis failed: {e}")
        # Fallback: return last step's result
        synthesis = completed[-1].get("result", "The plan was executed.")

    return {
        **state,
        "agent_response": synthesis,
        "current_agent": "planner",
    }


def _build_step_request(
    state: CarsonState,
    step: Dict[str, Any],
    completed: List[Dict[str, Any]],
) -> str:
    """
    Build an enriched request for the current step,
    injecting context from previous steps.
    """
    original_request = state.get("original_request", state.get("user_request", ""))
    action = step.get("action", "")
    depends_on = step.get("depends_on")

    # Start with the step's action description
    request = f"[Majordomo Plan — Step {step.get('step', '?')}]\n"
    request += f"Original user request: {original_request}\n"
    request += f"Your task for this step: {action}\n"

    # If this step depends on a previous step, include that result
    if depends_on is not None and completed:
        for prev in completed:
            if prev.get("step") == depends_on:
                request += f"\nContext from Step {depends_on} ({prev['agent']}):\n"
                request += prev.get("result", "No result")[:1000]
                request += "\n"
                break
    elif completed:
        # Include the most recent result as context
        last = completed[-1]
        request += f"\nContext from previous step ({last['agent']}):\n"
        request += last.get("result", "No result")[:500]
        request += "\n"

    request += f"\nExtract: {step.get('extract', 'key information')}"

    return request


def should_plan(state: CarsonState) -> str:
    """
    Conditional edge: determine if the request needs multi-step planning.

    Returns "plan" if multi-step, "route" if single-step.
    """
    plan = state.get("plan", {})
    if plan.get("plan_type") == "multi":
        return "plan"
    return "route"


def check_plan_done(state: CarsonState) -> str:
    """
    Conditional edge after a plan step completes.

    Returns "next_step" if more steps remain, "synthesize" if all done.
    """
    if state.get("plan_done", False):
        return "synthesize"
    return "next_step"
