# ==============================================================================
# Carson AI Butler — AWS Credential Refresh (PowerShell)
# ==============================================================================
# Quick script to refresh AWS credentials when they expire.
# Run this when Carson reports "InvalidClientTokenId" or "ExpiredTokenException".
#
# Usage: .\scripts\refresh-aws.ps1
# ==============================================================================

param(
    [switch]$Quiet
)

if (-not $Quiet) {
    Write-Host ""
    Write-Host "--- AWS Credential Refresh ---" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  When Carson reports expired credentials, follow these steps:" -ForegroundColor White
    Write-Host ""
    Write-Host "  1. Open DevShell (from your JPMC tools menu)" -ForegroundColor White
    Write-Host "  2. Run: pci aws login" -ForegroundColor Cyan
    Write-Host "  3. Wait for authentication to complete" -ForegroundColor White
    Write-Host "  4. Restart Carson service" -ForegroundColor White
    Write-Host ""
}

# Check if DevShell is available
$devShellPath = Get-Command "devshell" -ErrorAction SilentlyContinue
if ($devShellPath) {
    Write-Host "  DevShell found. Opening..." -ForegroundColor Green
    Start-Process "devshell"
} else {
    # Try common JPMC DevShell locations
    $commonPaths = @(
        "$env:LOCALAPPDATA\Programs\DevShell\DevShell.exe",
        "C:\Program Files\DevShell\DevShell.exe",
        "$env:USERPROFILE\AppData\Local\DevShell\DevShell.exe"
    )
    $found = $false
    foreach ($path in $commonPaths) {
        if (Test-Path $path) {
            Write-Host "  DevShell found at: $path" -ForegroundColor Green
            Start-Process $path
            $found = $true
            break
        }
    }
    if (-not $found) {
        Write-Host "  DevShell not found automatically." -ForegroundColor Yellow
        Write-Host "  Please open DevShell manually and run: pci aws login" -ForegroundColor Yellow
    }
}

Write-Host ""
Write-Host "  After refreshing credentials, restart Carson:" -ForegroundColor White
Write-Host "    python carson_service.py" -ForegroundColor Cyan
Write-Host ""
