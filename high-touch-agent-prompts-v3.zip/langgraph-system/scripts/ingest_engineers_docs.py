#!/usr/bin/env python3
"""
Carson Engineers Docs Ingestion — Scrape internal JPMC documentation and ingest into ChromaDB.

The engineers-docs MCP server uses Edge browser automation to access internal
JPMC documentation portals (developer guides, runbooks, architecture docs,
API references, etc.) that are not available in Confluence.

This script:
1. Connects to the engineers-docs MCP server
2. Fetches documentation pages (HTML)
3. Chunks and ingests them into ChromaDB for RAG

Usage:
    # Ingest all docs from the engineers-docs MCP
    python scripts/ingest_engineers_docs.py

    # Ingest specific URLs
    python scripts/ingest_engineers_docs.py --urls https://docs.internal.jpmc.com/guide1 https://docs.internal.jpmc.com/guide2

    # Ingest with custom collection
    python scripts/ingest_engineers_docs.py --collection jpmc_internal_docs

    # Fresh re-ingest
    python scripts/ingest_engineers_docs.py --fresh

    # Dry run
    python scripts/ingest_engineers_docs.py --dry-run
"""
import sys
import argparse
import logging
import json
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from carson_agents.config import load_config, get_rag_config, get_mcp_config
from carson_agents.rag.knowledge_base import CarsonKnowledgeBase

logger = logging.getLogger("carson.ingest.engineers_docs")


def get_engineers_docs_client():
    """
    Get the engineers-docs MCP client.

    This MCP server uses Edge/browser automation to scrape internal
    JPMC documentation pages that require authentication.
    """
    config = load_config()
    mcp_base = Path(config.get("mcp_servers_path", "../mcp-servers"))

    if not mcp_base.is_absolute():
        mcp_base = Path(__file__).parent.parent / mcp_base

    # The server might be named differently — try common variants
    possible_names = [
        "engineers-docs-mcp-server-python",
        "engineers-docs-mcp-server",
        "edge-docs-mcp-server-python",
        "docs-scraper-mcp-server-python",
    ]

    docs_path = None
    for name in possible_names:
        candidate = mcp_base / name
        if candidate.exists():
            docs_path = candidate
            break

    if docs_path is None:
        raise FileNotFoundError(
            f"Engineers-docs MCP server not found at: {mcp_base}\n"
            f"Tried: {', '.join(possible_names)}\n"
            f"Make sure the MCP server is cloned at the correct path."
        )

    if str(docs_path) not in sys.path:
        sys.path.insert(0, str(docs_path))

    # Try to import the client — name may vary
    try:
        from source.docs_client import get_docs_client
        return get_docs_client()
    except ImportError:
        try:
            from source.engineers_docs_client import get_engineers_docs_client as _get
            return _get()
        except ImportError:
            raise ImportError(
                f"Could not import docs client from {docs_path}/source/\n"
                f"Check the MCP server's source directory for the client module."
            )


def fetch_docs_from_mcp(client, urls: list = None) -> list:
    """
    Fetch documentation pages from the engineers-docs MCP server.

    If urls is provided, fetches those specific pages.
    Otherwise, asks the MCP to list available documentation and fetches all.

    Returns list of dicts with: url, title, html_content, doc_type
    """
    pages = []

    if urls:
        # Fetch specific URLs
        for url in urls:
            print(f"  Fetching: {url}")
            try:
                result = client.get_page(url)
                if isinstance(result, str):
                    result = json.loads(result)

                pages.append({
                    "url": url,
                    "title": result.get("title", url.split("/")[-1]),
                    "html_content": result.get("content", result.get("html", "")),
                    "doc_type": result.get("type", "internal_doc"),
                })
            except Exception as e:
                print(f"    WARNING: Failed to fetch {url}: {e}")
    else:
        # List all available docs
        print("  Listing available documentation...")
        try:
            doc_list = client.list_docs()
            if isinstance(doc_list, str):
                doc_list = json.loads(doc_list)

            docs = doc_list if isinstance(doc_list, list) else doc_list.get("docs", [])
            print(f"  Found {len(docs)} documentation pages")

            for idx, doc in enumerate(docs):
                doc_url = doc.get("url", doc.get("link", ""))
                doc_title = doc.get("title", doc.get("name", f"Doc {idx + 1}"))

                print(f"  [{idx + 1}/{len(docs)}] Fetching: {doc_title}")
                try:
                    result = client.get_page(doc_url)
                    if isinstance(result, str):
                        result = json.loads(result)

                    pages.append({
                        "url": doc_url,
                        "title": doc_title,
                        "html_content": result.get("content", result.get("html", "")),
                        "doc_type": doc.get("type", "internal_doc"),
                    })
                except Exception as e:
                    print(f"    WARNING: Failed to fetch '{doc_title}': {e}")

        except Exception as e:
            print(f"  ERROR: Could not list docs: {e}")
            print("  Try providing specific URLs with --urls")

    return pages


def main():
    parser = argparse.ArgumentParser(
        description="Ingest JPMC internal documentation into Carson's ChromaDB knowledge base"
    )
    parser.add_argument(
        "--urls", nargs="+", default=None,
        help="Specific documentation URLs to ingest"
    )
    parser.add_argument(
        "--collection", default="engineers_docs",
        help="ChromaDB collection name (default: engineers_docs)"
    )
    parser.add_argument(
        "--config", default=None,
        help="Path to config.yaml"
    )
    parser.add_argument(
        "--fresh", action="store_true",
        help="Delete existing collection before ingesting"
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Show what would be ingested without writing"
    )
    parser.add_argument(
        "--verbose", action="store_true",
        help="Enable verbose logging"
    )

    args = parser.parse_args()

    if args.verbose:
        logging.basicConfig(level=logging.DEBUG)
    else:
        logging.basicConfig(level=logging.INFO)

    config = load_config(args.config)
    rag_config = get_rag_config()
    persist_dir = rag_config.get("persist_dir", "./carson_kb")

    print()
    print("=" * 60)
    print("  Carson — Engineers Docs Knowledge Ingestion")
    print("=" * 60)
    print()
    print(f"  ChromaDB path:  {persist_dir}")
    print(f"  Collection:     {args.collection}")
    if args.urls:
        print(f"  URLs:           {len(args.urls)} specified")
    else:
        print(f"  Mode:           Fetch all available docs")
    if args.fresh:
        print(f"  Re-ingest:      Yes (delete + re-create)")
    if args.dry_run:
        print(f"  Dry run:        Yes")
    print()

    # --- Connect ---
    print("--- Connecting to Engineers Docs MCP ---")
    try:
        client = get_engineers_docs_client()
        print("  Connected successfully!")
    except Exception as e:
        print(f"  ERROR: {e}")
        print()
        print("  The engineers-docs MCP server uses Edge browser automation.")
        print("  Make sure:")
        print("  1. The MCP server is at the path in config.yaml -> mcp_servers_path")
        print("  2. Edge WebDriver is available on the VDI")
        print("  3. You are authenticated to the JPMC internal network")
        print()
        print("  Alternative: manually save pages as HTML files and use ingest_knowledge.py")
        sys.exit(1)
    print()

    # --- Fetch ---
    print("--- Fetching Documentation ---")
    pages = fetch_docs_from_mcp(client, urls=args.urls)
    print()

    if not pages:
        print("  No documentation pages found.")
        sys.exit(0)

    total_size = sum(len(p.get("html_content", "")) for p in pages)
    print(f"  Pages fetched:       {len(pages)}")
    print(f"  Total content size:  {total_size:,} chars ({total_size // 1024} KB)")
    print()

    # --- Convert to the format expected by ingest_confluence_pages ---
    # The Confluence chunking works great for any HTML, so we reuse it
    ingest_pages = []
    for page in pages:
        ingest_pages.append({
            "id": page.get("url", ""),
            "title": page.get("title", ""),
            "space_key": "engineers-docs",
            "html_content": page.get("html_content", ""),
            "url": page.get("url", ""),
        })

    if args.dry_run:
        print("--- DRY RUN — Chunking Preview ---")
        kb = CarsonKnowledgeBase(persist_dir=persist_dir)
        total_chunks = 0
        for page in ingest_pages:
            chunks = kb._chunk_confluence_html(
                page.get("html_content", ""),
                page.get("title", "Untitled"),
            )
            total_chunks += len(chunks)
            print(f"  {page['title']}: {len(chunks)} chunks")
        print()
        print(f"  Total chunks: {total_chunks}")
        print("  (Dry run — no data written)")
        sys.exit(0)

    # --- Ingest ---
    print("--- Ingesting into ChromaDB ---")
    kb = CarsonKnowledgeBase(persist_dir=persist_dir)

    if args.fresh:
        print(f"  Deleting collection '{args.collection}'...")
        kb.delete_collection(args.collection)

    count = kb.ingest_confluence_pages(ingest_pages, collection_name=args.collection)

    print()
    print("=" * 60)
    print(f"  Done! Ingested {count} chunks into '{args.collection}'")
    print(f"  Total docs in collection: {kb.get_collection_count(args.collection)}")
    print("=" * 60)
    print()


if __name__ == "__main__":
    main()
