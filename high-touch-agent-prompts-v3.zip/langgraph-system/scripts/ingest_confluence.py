#!/usr/bin/env python3
"""
Carson Confluence Ingestion — Download Confluence pages and ingest into ChromaDB.

This script connects to the Confluence MCP server, downloads all pages from
a given space (or specific pages), and feeds them into the CarsonKnowledgeBase
for RAG-powered answers.

Usage:
    # Ingest entire space
    python scripts/ingest_confluence.py --space AHTW

    # Ingest specific pages by ID
    python scripts/ingest_confluence.py --pages 12345 67890

    # Ingest with custom collection name
    python scripts/ingest_confluence.py --space AHTW --collection my_docs

    # Re-ingest (delete old collection first)
    python scripts/ingest_confluence.py --space AHTW --fresh

    # Dry run — show what would be ingested without writing to ChromaDB
    python scripts/ingest_confluence.py --space AHTW --dry-run
"""
import sys
import argparse
import logging
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from carson_agents.config import load_config, get_rag_config, get_team_config, get_mcp_config
from carson_agents.rag.knowledge_base import CarsonKnowledgeBase

logger = logging.getLogger("carson.ingest.confluence")


def get_confluence_client():
    """
    Get the Confluence MCP client.

    Imports from the MCP server directory configured in config.yaml.
    The client uses PYNETA_PROFILE env var for authentication.
    """
    config = load_config()
    mcp_base = Path(config.get("mcp_servers_path", "../mcp-servers"))

    # Resolve relative to project root
    if not mcp_base.is_absolute():
        mcp_base = Path(__file__).parent.parent / mcp_base

    confluence_path = mcp_base / "confluence-mcp-server-python"
    if not confluence_path.exists():
        raise FileNotFoundError(
            f"Confluence MCP server not found at: {confluence_path}\n"
            f"Make sure the MCP servers are cloned at the correct path."
        )

    if str(confluence_path) not in sys.path:
        sys.path.insert(0, str(confluence_path))

    from source.confluence_client import get_confluence_client as _get_client
    return _get_client()


def fetch_space_pages(client, space_key: str, limit: int = 500) -> list:
    """
    Fetch all pages from a Confluence space.

    Uses CQL to search for all pages in the space, then fetches
    each page's full content.

    Args:
        client: Confluence MCP client
        space_key: Confluence space key (e.g., "AHTW")
        limit: Maximum number of pages to fetch

    Returns:
        List of page dicts with id, title, space_key, html_content, url
    """
    print(f"  Searching for pages in space '{space_key}'...")

    # CQL query: all pages in the space
    cql = f'space = "{space_key}" AND type = "page"'
    results = client.cql(cql, limit=limit)

    pages_meta = results.get("results", [])
    print(f"  Found {len(pages_meta)} pages in '{space_key}'")

    pages = []
    for idx, page_meta in enumerate(pages_meta):
        page_id = page_meta.id if hasattr(page_meta, "id") else page_meta.get("id", "")
        title = page_meta.title if hasattr(page_meta, "title") else page_meta.get("title", "")

        print(f"  [{idx + 1}/{len(pages_meta)}] Fetching: {title}")

        try:
            # Fetch full page content (body.storage = raw Confluence HTML)
            page = client.get_page(str(page_id), expand="body.storage")

            html_content = ""
            if hasattr(page, "body") and hasattr(page.body, "storage"):
                html_content = page.body.storage.value
            elif isinstance(page, dict):
                html_content = (
                    page.get("body", {}).get("storage", {}).get("value", "")
                )

            url = ""
            if hasattr(page, "_links"):
                url = getattr(page._links, "webui", "")
            elif isinstance(page, dict):
                url = page.get("_links", {}).get("webui", "")

            pages.append({
                "id": str(page_id),
                "title": title,
                "space_key": space_key,
                "html_content": html_content,
                "url": url,
            })

        except Exception as e:
            logger.warning(f"  Failed to fetch page '{title}' ({page_id}): {e}")
            print(f"    WARNING: Could not fetch page '{title}': {e}")

    return pages


def fetch_pages_by_id(client, page_ids: list) -> list:
    """Fetch specific pages by their Confluence page IDs."""
    pages = []
    for page_id in page_ids:
        print(f"  Fetching page ID: {page_id}")
        try:
            page = client.get_page(str(page_id), expand="body.storage")

            html_content = ""
            title = ""
            space_key = ""
            url = ""

            if hasattr(page, "body") and hasattr(page.body, "storage"):
                html_content = page.body.storage.value
            elif isinstance(page, dict):
                html_content = page.get("body", {}).get("storage", {}).get("value", "")

            if hasattr(page, "title"):
                title = page.title
            elif isinstance(page, dict):
                title = page.get("title", "")

            if hasattr(page, "space") and hasattr(page.space, "key"):
                space_key = page.space.key
            elif isinstance(page, dict):
                space_key = page.get("space", {}).get("key", "")

            if hasattr(page, "_links"):
                url = getattr(page._links, "webui", "")

            pages.append({
                "id": str(page_id),
                "title": title,
                "space_key": space_key,
                "html_content": html_content,
                "url": url,
            })
        except Exception as e:
            print(f"    WARNING: Could not fetch page {page_id}: {e}")

    return pages


def main():
    parser = argparse.ArgumentParser(
        description="Ingest Confluence pages into Carson's ChromaDB knowledge base"
    )
    parser.add_argument(
        "--space", default=None,
        help="Confluence space key to ingest (e.g., AHTW). Fetches all pages in the space."
    )
    parser.add_argument(
        "--pages", nargs="+", default=None,
        help="Specific Confluence page IDs to ingest"
    )
    parser.add_argument(
        "--collection", default="confluence_docs",
        help="ChromaDB collection name (default: confluence_docs)"
    )
    parser.add_argument(
        "--config", default=None,
        help="Path to config.yaml"
    )
    parser.add_argument(
        "--fresh", action="store_true",
        help="Delete the existing collection before ingesting (clean re-ingest)"
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Show what would be ingested without writing to ChromaDB"
    )
    parser.add_argument(
        "--limit", type=int, default=500,
        help="Max pages to fetch from a space (default: 500)"
    )
    parser.add_argument(
        "--verbose", action="store_true",
        help="Enable verbose logging"
    )

    args = parser.parse_args()

    if args.verbose:
        logging.basicConfig(level=logging.DEBUG)
    else:
        logging.basicConfig(level=logging.INFO)

    # Load config
    config = load_config(args.config)
    rag_config = get_rag_config()

    if not rag_config.get("enabled"):
        print("WARNING: RAG is disabled in config.yaml (rag.enabled: false)")
        print("The ingestion will proceed, but Carson won't use the knowledge base")
        print("until you set rag.enabled: true in config.yaml")
        print()

    persist_dir = rag_config.get("persist_dir", "./carson_kb")

    # Determine space key
    space_key = args.space
    if not space_key and not args.pages:
        # Try to get from config
        team_config = get_team_config()
        space_key = team_config.get("confluence_space", "")
        if not space_key:
            print("ERROR: No space key provided. Use --space MYSPACE or set team.confluence_space in config.yaml")
            sys.exit(1)
        print(f"  Using space from config.yaml: {space_key}")

    print()
    print("=" * 60)
    print("  Carson — Confluence Knowledge Ingestion")
    print("=" * 60)
    print()
    print(f"  ChromaDB path:  {persist_dir}")
    print(f"  Collection:     {args.collection}")
    if space_key:
        print(f"  Space:          {space_key}")
    if args.pages:
        print(f"  Page IDs:       {', '.join(args.pages)}")
    if args.fresh:
        print(f"  Mode:           FRESH (delete + re-ingest)")
    if args.dry_run:
        print(f"  Mode:           DRY RUN (no writes)")
    print()

    # --- Connect to Confluence ---
    print("--- Connecting to Confluence ---")
    try:
        client = get_confluence_client()
        print("  Connected successfully!")
    except Exception as e:
        print(f"  ERROR: Could not connect to Confluence: {e}")
        print()
        print("  Make sure:")
        print("  1. The Confluence MCP server is at the path in config.yaml → mcp_servers_path")
        print("  2. PYNETA_PROFILE=local is set in your environment")
        print("  3. You have network access to Confluence")
        sys.exit(1)
    print()

    # --- Fetch pages ---
    print("--- Fetching Pages ---")
    if args.pages:
        pages = fetch_pages_by_id(client, args.pages)
    else:
        pages = fetch_space_pages(client, space_key, limit=args.limit)
    print()

    if not pages:
        print("  No pages found. Nothing to ingest.")
        sys.exit(0)

    # --- Show summary ---
    total_html_size = sum(len(p.get("html_content", "")) for p in pages)
    print(f"  Pages fetched:       {len(pages)}")
    print(f"  Total HTML size:     {total_html_size:,} chars ({total_html_size // 1024} KB)")
    print()

    if args.dry_run:
        print("--- DRY RUN — Chunking Preview ---")
        kb = CarsonKnowledgeBase(persist_dir=persist_dir)
        total_chunks = 0
        for page in pages:
            chunks = kb._chunk_confluence_html(
                page.get("html_content", ""),
                page.get("title", "Untitled"),
            )
            total_chunks += len(chunks)
            print(f"  {page['title']}: {len(chunks)} chunks")
            for c in chunks[:3]:
                preview = c["text"][:80].replace("\n", " ")
                print(f"    [{c['type']}] {c.get('heading', '')} — {preview}...")
            if len(chunks) > 3:
                print(f"    ... and {len(chunks) - 3} more chunks")
        print()
        print(f"  Total chunks that would be created: {total_chunks}")
        print("  (No data was written — run without --dry-run to ingest)")
        sys.exit(0)

    # --- Ingest into ChromaDB ---
    print("--- Ingesting into ChromaDB ---")
    kb = CarsonKnowledgeBase(persist_dir=persist_dir)

    if args.fresh:
        print(f"  Deleting existing collection '{args.collection}'...")
        kb.delete_collection(args.collection)

    count = kb.ingest_confluence_pages(pages, collection_name=args.collection)

    print()
    print("=" * 60)
    print(f"  Done! Ingested {count} chunks into '{args.collection}'")
    print(f"  Total docs in collection: {kb.get_collection_count(args.collection)}")
    print()
    print("  The knowledge base is now available for Carson's RAG queries.")
    print("  Make sure rag.enabled: true is set in config.yaml.")
    print("=" * 60)
    print()


if __name__ == "__main__":
    main()
