# ==============================================================================
# Carson AI Butler — Sync .github to Workspace Root (PowerShell)
# ==============================================================================
# The .github/copilot-instructions.md file lives in TWO places:
#   1. Inside the Carson repo (source of truth)
#   2. At the workspace root (so GitHub Copilot picks it up)
#
# This script copies the .github folder from the repo to the workspace root.
#
# Usage: .\scripts\sync-to-root.ps1
# ==============================================================================

param(
    [string]$WorkspaceRoot = "",
    [switch]$DryRun
)

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Split-Path -Parent $ScriptDir
$SourceGithub = Join-Path $ProjectRoot ".github"

if (-not $WorkspaceRoot) {
    # Default: two levels up from project root (assumes repo is in workspace/repos/carson/)
    $WorkspaceRoot = Split-Path -Parent (Split-Path -Parent $ProjectRoot)
}

$DestGithub = Join-Path $WorkspaceRoot ".github"

Write-Host ""
Write-Host "--- Sync .github to Workspace Root ---" -ForegroundColor Yellow
Write-Host "  Source: $SourceGithub" -ForegroundColor White
Write-Host "  Destination: $DestGithub" -ForegroundColor White
Write-Host ""

if (-not (Test-Path $SourceGithub)) {
    Write-Host "  ERROR: Source .github not found at $SourceGithub" -ForegroundColor Red
    exit 1
}

if ($DryRun) {
    Write-Host "  [DRY RUN] Would copy:" -ForegroundColor Cyan
    Get-ChildItem -Path $SourceGithub -Recurse -File | ForEach-Object {
        $relPath = $_.FullName.Substring($SourceGithub.Length)
        Write-Host "    $relPath -> $DestGithub$relPath"
    }
} else {
    if (-not (Test-Path $DestGithub)) {
        New-Item -ItemType Directory -Path $DestGithub -Force | Out-Null
    }

    Copy-Item -Path "$SourceGithub\*" -Destination $DestGithub -Recurse -Force
    Write-Host "  Synced successfully!" -ForegroundColor Green

    # Show what was copied
    Get-ChildItem -Path $DestGithub -Recurse -File | ForEach-Object {
        $relPath = $_.FullName.Substring($DestGithub.Length)
        Write-Host "    $relPath" -ForegroundColor Green
    }
}

Write-Host ""
