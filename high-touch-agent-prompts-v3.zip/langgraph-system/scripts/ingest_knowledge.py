#!/usr/bin/env python3
"""
Carson Knowledge Ingestion — Populate ChromaDB from repo files.

Usage:
    python scripts/ingest_knowledge.py [--repo-path .] [--collection repo_code]
"""
import sys
import argparse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from carson_agents.config import load_config, get_rag_config
from carson_agents.rag.knowledge_base import CarsonKnowledgeBase


def main():
    parser = argparse.ArgumentParser(description="Ingest files into Carson knowledge base")
    parser.add_argument("--repo-path", default=".", help="Path to repository (default: .)")
    parser.add_argument("--collection", default="repo_code", help="Collection name (default: repo_code)")
    parser.add_argument("--config", default=None, help="Path to config.yaml")
    args = parser.parse_args()

    config = load_config(args.config)
    rag_config = get_rag_config()

    if not rag_config.get("enabled"):
        print("RAG is disabled in config.yaml. Set rag.enabled: true first.")
        sys.exit(1)

    persist_dir = rag_config.get("persist_dir", "./carson_kb")
    kb = CarsonKnowledgeBase(persist_dir=persist_dir)

    print(f"Ingesting from: {args.repo_path}")
    print(f"Collection: {args.collection}")
    print(f"ChromaDB path: {persist_dir}")
    print()

    count = kb.ingest_repo(args.repo_path, collection_name=args.collection)

    print(f"\nDone! Ingested {count} chunks into '{args.collection}'")
    print(f"Total docs in collection: {kb.get_collection_count(args.collection)}")


if __name__ == "__main__":
    main()
