# ==============================================================================
# Carson AI Butler — Environment Setup (PowerShell)
# ==============================================================================
# Run this script once to set up the Carson environment on a Windows VDI.
# It configures user environment variables, installs Python dependencies,
# and sets up the workspace directory structure.
#
# Usage: .\scripts\setup-env.ps1
# ==============================================================================

param(
    [string]$PythonPath = "python",
    [string]$ConfigPath = "",
    [switch]$SkipPip,
    [switch]$Force
)

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  Carson AI Butler — Environment Setup" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

# --- Detect project root ---
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Split-Path -Parent $ScriptDir
Write-Host "Project root: $ProjectRoot"

# --- Check Python version ---
Write-Host ""
Write-Host "--- Checking Python ---" -ForegroundColor Yellow
try {
    $pyVersion = & $PythonPath --version 2>&1
    Write-Host "  Found: $pyVersion"
    $versionMatch = [regex]::Match($pyVersion, "Python (\d+)\.(\d+)")
    if ($versionMatch.Success) {
        $major = [int]$versionMatch.Groups[1].Value
        $minor = [int]$versionMatch.Groups[2].Value
        if ($major -lt 3 -or ($major -eq 3 -and $minor -lt 9)) {
            Write-Host "  WARNING: Python 3.9+ required. Found $major.$minor" -ForegroundColor Red
            if (-not $Force) {
                Write-Host "  Use -Force to proceed anyway, or install Python 3.9+" -ForegroundColor Red
                exit 1
            }
        }
    }
} catch {
    Write-Host "  ERROR: Python not found at '$PythonPath'" -ForegroundColor Red
    Write-Host "  Install Python 3.9+ or pass -PythonPath <path>" -ForegroundColor Red
    exit 1
}

# --- Install Python dependencies ---
if (-not $SkipPip) {
    Write-Host ""
    Write-Host "--- Installing Python Dependencies ---" -ForegroundColor Yellow
    $requirementsFile = Join-Path $ProjectRoot "requirements.txt"

    if (Test-Path $requirementsFile) {
        Write-Host "  Installing from: $requirementsFile"
        & $PythonPath -m pip install --upgrade pip 2>&1 | Out-Null
        & $PythonPath -m pip install -r $requirementsFile 2>&1
        if ($LASTEXITCODE -ne 0) {
            Write-Host "  WARNING: Some packages failed to install." -ForegroundColor Yellow
            Write-Host "  The CDAO SDK must be installed from JPMC's internal artifact repo." -ForegroundColor Yellow
        } else {
            Write-Host "  All dependencies installed successfully." -ForegroundColor Green
        }
    } else {
        Write-Host "  requirements.txt not found at $requirementsFile" -ForegroundColor Red
    }

    # Optional: install anthropic client if not using Bedrock
    Write-Host ""
    $installAnthropic = Read-Host "  Install Anthropic Python client? (for non-Bedrock usage) [y/N]"
    if ($installAnthropic -eq "y" -or $installAnthropic -eq "Y") {
        & $PythonPath -m pip install anthropic>=0.25.0 2>&1
        Write-Host "  Anthropic client installed." -ForegroundColor Green
    }
} else {
    Write-Host ""
    Write-Host "--- Skipping pip install (--SkipPip) ---" -ForegroundColor Yellow
}

# --- Set up environment variables ---
Write-Host ""
Write-Host "--- Environment Variables ---" -ForegroundColor Yellow

$envFile = Join-Path $ProjectRoot ".env"
$envExample = Join-Path $ProjectRoot ".env.example"

if ((Test-Path $envFile) -and -not $Force) {
    Write-Host "  .env file already exists. Use -Force to overwrite." -ForegroundColor Yellow
} elseif (Test-Path $envExample) {
    Copy-Item $envExample $envFile
    Write-Host "  Created .env from .env.example" -ForegroundColor Green
    Write-Host "  IMPORTANT: Edit .env with your actual credentials" -ForegroundColor Yellow
} else {
    Write-Host "  No .env.example found. Creating minimal .env..." -ForegroundColor Yellow
    @"
# Carson Environment Variables
AWS_ACCOUNT_NUMBER=
AWS_REGION=us-east-1
WORKSPACE_ID=
CARSON_PORT=8765
LOG_LEVEL=INFO
PYNETA_PROFILE=local
"@ | Out-File -FilePath $envFile -Encoding utf8
    Write-Host "  Created minimal .env — fill in your values" -ForegroundColor Green
}

# --- Set Windows user environment variables ---
Write-Host ""
$setUserEnv = Read-Host "  Set Carson env vars for current Windows user? [y/N]"
if ($setUserEnv -eq "y" -or $setUserEnv -eq "Y") {
    # PYNETA_PROFILE for MCP server auth
    [System.Environment]::SetEnvironmentVariable("PYNETA_PROFILE", "local", "User")
    Write-Host "  Set PYNETA_PROFILE=local" -ForegroundColor Green

    # Carson config path
    if ($ConfigPath) {
        [System.Environment]::SetEnvironmentVariable("CARSON_CONFIG", $ConfigPath, "User")
        Write-Host "  Set CARSON_CONFIG=$ConfigPath" -ForegroundColor Green
    }

    Write-Host "  User env vars set. Restart your terminal for changes to take effect." -ForegroundColor Yellow
}

# --- Create workspace directories ---
Write-Host ""
Write-Host "--- Workspace Directories ---" -ForegroundColor Yellow

$dirs = @(
    (Join-Path $ProjectRoot "carson_kb"),
    (Join-Path $ProjectRoot "logs")
)
foreach ($dir in $dirs) {
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
        Write-Host "  Created: $dir" -ForegroundColor Green
    } else {
        Write-Host "  Exists: $dir"
    }
}

# --- Verify MCP servers ---
Write-Host ""
Write-Host "--- MCP Server Check ---" -ForegroundColor Yellow

$mcpPath = Join-Path (Split-Path $ProjectRoot -Parent) "mcp-servers"
if (Test-Path $mcpPath) {
    $mcpServers = Get-ChildItem -Path $mcpPath -Directory | Where-Object { $_.Name -match "mcp-server" }
    Write-Host "  MCP servers directory: $mcpPath"
    foreach ($srv in $mcpServers) {
        Write-Host "    - $($srv.Name)" -ForegroundColor Green
    }
} else {
    Write-Host "  MCP servers directory not found at: $mcpPath" -ForegroundColor Yellow
    Write-Host "  Clone your team's MCP servers to that location." -ForegroundColor Yellow
}

# --- Run onboarding if no config.yaml ---
Write-Host ""
$configFile = Join-Path $ProjectRoot "config.yaml"
if (-not (Test-Path $configFile)) {
    Write-Host "--- No config.yaml found ---" -ForegroundColor Yellow
    $runOnboard = Read-Host "  Run interactive onboarding wizard? [Y/n]"
    if ($runOnboard -ne "n" -and $runOnboard -ne "N") {
        & $PythonPath (Join-Path $ScriptDir "onboarding.py")
    } else {
        Write-Host "  Copy config_template.yaml to config.yaml and edit manually." -ForegroundColor Yellow
    }
} else {
    Write-Host "  config.yaml found at: $configFile" -ForegroundColor Green
}

# --- Summary ---
Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  Setup Complete!" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Next steps:" -ForegroundColor White
Write-Host "  1. Edit .env with your credentials" -ForegroundColor White
Write-Host "  2. Refresh AWS creds: DevShell -> pci aws login" -ForegroundColor White
Write-Host "  3. Start Carson: $PythonPath carson_service.py" -ForegroundColor White
Write-Host "  4. (Optional) Ingest knowledge: $PythonPath scripts/ingest_knowledge.py" -ForegroundColor White
Write-Host ""
