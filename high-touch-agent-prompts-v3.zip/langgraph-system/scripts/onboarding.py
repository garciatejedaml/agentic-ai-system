#!/usr/bin/env python3
"""
Carson Onboarding Script — Interactive setup for new teams.

Guides users through:
1. Team information
2. LLM provider selection (Bedrock vs Anthropic direct)
3. Agent configuration
4. RAG setup
5. Generates config.yaml
"""
import os
import sys
import yaml
from pathlib import Path


def ask(prompt, default=None):
    """Ask a question with optional default."""
    if default:
        val = input(f"  {prompt} [{default}]: ").strip()
        return val if val else default
    return input(f"  {prompt}: ").strip()


def ask_yn(prompt, default=True):
    """Ask a yes/no question."""
    suffix = "[Y/n]" if default else "[y/N]"
    val = input(f"  {prompt} {suffix}: ").strip().lower()
    if not val:
        return default
    return val in ("y", "yes", "si", "sí")


def main():
    print()
    print("=" * 60)
    print("  Carson AI Butler — Team Onboarding")
    print("=" * 60)
    print()
    print("  This wizard will help you configure Carson for your team.")
    print("  Press Enter to accept defaults shown in [brackets].")
    print()

    config = {}

    # --- Team ---
    print("--- Team Information ---")
    team_name = ask("Team name", "My Team")
    project_key = ask("Jira project key", "MYPROJECT")
    jira_board_id = int(ask("Jira board ID (number)", "0"))
    confluence_space = ask("Confluence space key", "MYTEAM")
    tfe_org = ask("Terraform Enterprise organization", "my-org")
    print()

    # --- Bitbucket Projects ---
    print("--- Bitbucket Projects ---")
    print("  Teams can link one or more Bitbucket projects.")
    print("  Leave empty if your team has no Bitbucket project.")
    print()
    bb_projects = []
    while True:
        bb_key = ask("Bitbucket project key (or press Enter to finish)", "")
        if not bb_key:
            break
        bb_desc = ask(f"Description for {bb_key}", "")
        repos_str = ask(f"Specific repos in {bb_key} (comma-separated, or Enter for all)", "")
        repos = [r.strip() for r in repos_str.split(",") if r.strip()] if repos_str else []
        bb_projects.append({"key": bb_key, "description": bb_desc, "repositories": repos})
        print(f"  Added project: {bb_key}")
        if not ask_yn("Add another Bitbucket project?", False):
            break

    default_bb = ""
    if bb_projects:
        if len(bb_projects) == 1:
            default_bb = bb_projects[0]["key"]
        else:
            default_bb = ask("Default Bitbucket project", bb_projects[0]["key"])

    config["team"] = {
        "name": team_name,
        "project_key": project_key,
        "jira_board_id": jira_board_id,
        "confluence_space": confluence_space,
        "tfe_organization": tfe_org,
        "bitbucket_projects": bb_projects,
        "default_bitbucket_project": default_bb,
    }
    print()

    # --- LLM Provider ---
    print("--- LLM Provider ---")
    print("  Choose your LLM provider:")
    print("  1. Bedrock (JPMC CDAO SDK) — requires AWS credentials")
    print("  2. Anthropic (direct API) — requires ANTHROPIC_API_KEY")
    print()
    choice = ask("Enter 1 or 2", "1")

    if choice == "2":
        config["llm"] = {
            "provider": "anthropic",
            "model_id": ask("Anthropic model", "claude-sonnet-4-20250514"),
            "api_key_env": ask("API key env var name", "ANTHROPIC_API_KEY"),
        }
    else:
        config["llm"] = {
            "provider": "bedrock",
            "model_id": ask("Bedrock model ID", "anthropic.claude-3-5-sonnet-20241022-v2:0"),
            "model_arn": ask("Model ARN (or leave empty)", ""),
            "aws_account": ask("AWS Account Number", "043309362186"),
            "aws_region": ask("AWS Region", "us-east-1"),
            "workspace_id": ask("CDAO Workspace ID", "905183"),
            "is_execution_role": False,
        }
        # Remove empty model_arn
        if not config["llm"]["model_arn"]:
            del config["llm"]["model_arn"]
    print()

    # --- Agents ---
    print("--- Agent Configuration ---")
    print("  Enable/disable agents based on your team's tools:")
    agents = {}
    agent_names = {
        "jira": "Comptroller Jira (Jira tickets)",
        "git": "Mr. Brandson (Git/Bitbucket)",
        "build": "M. Jenkins (CI/CD builds)",
        "deploy": "Madame Spinnaker (Deployments)",
        "terraform": "M. Terraform Inspector (Infrastructure)",
        "docs": "Secretary Confluence (Documentation)",
        "general": "Inspector Clouseau (General knowledge)",
    }
    for agent_id, name in agent_names.items():
        enabled = ask_yn(f"Enable {name}?", True)
        agents[agent_id] = {"enabled": enabled}
    config["agents"] = agents
    print()

    # --- RAG ---
    print("--- RAG / Knowledge Base ---")
    rag_enabled = ask_yn("Enable ChromaDB RAG for context-aware answers?", False)
    config["rag"] = {
        "enabled": rag_enabled,
        "persist_dir": "./carson_kb",
    }
    if rag_enabled:
        config["rag"]["collections"] = [
            {"name": "repo_code", "source": ".", "extensions": [".py", ".md"]},
        ]
    print()

    # --- Service ---
    config["service"] = {
        "host": "0.0.0.0",
        "port": int(ask("Service port", "8765")),
        "debug": False,
    }

    config["mcp_servers_path"] = ask("MCP servers path (relative)", "../mcp-servers")

    # --- Write config ---
    config_path = Path(__file__).parent.parent / "config.yaml"
    print()
    print(f"  Writing configuration to: {config_path}")

    with open(config_path, "w", encoding="utf-8") as f:
        f.write("# Carson AI Butler — Generated Configuration\n")
        f.write(f"# Team: {config['team']['name']}\n")
        f.write(f"# Generated by onboarding.py\n\n")
        yaml.dump(config, f, default_flow_style=False, sort_keys=False)

    print()
    print("=" * 60)
    print("  Configuration saved!")
    print()
    print("  Next steps:")
    print(f"  1. Review config.yaml")
    print(f"  2. Set up environment: pip install -r requirements.txt")
    if config["llm"]["provider"] == "anthropic":
        print(f"  3. Set API key: export ANTHROPIC_API_KEY=your-key-here")
    else:
        print(f"  3. Refresh AWS credentials: DevShell → pci aws login")
    print(f"  4. Start Carson: python carson_service.py")
    if rag_enabled:
        print(f"  5. Ingest knowledge: python scripts/ingest_knowledge.py")
    print("=" * 60)
    print()


if __name__ == "__main__":
    main()
