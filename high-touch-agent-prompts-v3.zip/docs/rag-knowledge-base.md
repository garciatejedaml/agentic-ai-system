# Carson RAG Knowledge Base

Carson uses ChromaDB as its vector database for Retrieval-Augmented Generation (RAG). This gives the General Agent (Inspector Clouseau) access to team-specific knowledge when answering questions, without needing to call external APIs every time.

## How It Works

```
User asks a question
       |
       v
General Agent receives the question
       |
       v
RAG system queries ALL ChromaDB collections
(repo_code, confluence_docs, engineers_docs)
       |
       v
Top 5 most relevant chunks are injected
into the LLM prompt as context
       |
       v
Agent answers using the context naturally
(no "according to the knowledge base" phrasing)
```

## Collections

ChromaDB organizes data into **collections**. Each collection represents a different knowledge source:

| Collection | Source | Ingestion Script | Content |
|---|---|---|---|
| `repo_code` | Local repository files | `scripts/ingest_knowledge.py` | Python code, Markdown docs, YAML configs |
| `confluence_docs` | Confluence pages | `scripts/ingest_confluence.py` | Team documentation, runbooks, architecture docs |
| `engineers_docs` | JPMC internal docs portal | `scripts/ingest_engineers_docs.py` | Developer guides, API references, internal standards |

The General Agent queries ALL collections simultaneously and merges results by relevance (cosine similarity distance).

## Chunking Strategy

Different content types get chunked differently for optimal retrieval:

**Python files** — Split by function and class definitions. Each chunk starts with `# File: path/to/file.py` so the LLM knows the source. This means when you ask "how does the router work?", you get the actual `router_node()` function as context.

**Markdown files** — Split by heading sections (`#`, `##`, `###`). Each section becomes a chunk. This preserves the logical structure of documentation.

**Confluence HTML** — The most sophisticated chunking:
1. Code blocks (`<ac:structured-macro ac:name="code">`) are extracted as separate chunks
2. HTML tables are converted to `Column1 | Column2 | Column3` text format
3. Content is split by heading tags (`<h1>` through `<h6>`)
4. Large sections (>1500 chars) are further split by paragraph
5. All HTML tags are stripped, entities decoded, Confluence macros removed
6. Each chunk includes `[Page: Title] [Section Heading]` for context

**Engineers docs HTML** — Same chunking as Confluence (reuses the same HTML parser).

## Setup

### 1. Enable RAG in config.yaml

```yaml
rag:
  enabled: true
  persist_dir: "./carson_kb"
```

### 2. Ingest Repository Code

```bash
python scripts/ingest_knowledge.py --repo-path . --collection repo_code
```

### 3. Ingest Confluence Documentation

```bash
# Ingest entire space
python scripts/ingest_confluence.py --space AHTW

# Ingest specific pages
python scripts/ingest_confluence.py --pages 12345 67890

# Preview without writing (dry run)
python scripts/ingest_confluence.py --space AHTW --dry-run

# Fresh re-ingest (delete old data first)
python scripts/ingest_confluence.py --space AHTW --fresh
```

### 4. Ingest Engineers Docs (Internal JPMC Docs)

```bash
# Ingest all available docs
python scripts/ingest_engineers_docs.py

# Ingest specific URLs
python scripts/ingest_engineers_docs.py --urls https://docs.internal.jpmc.com/guide1

# Fresh re-ingest
python scripts/ingest_engineers_docs.py --fresh
```

## Sharing the Knowledge Base

The ChromaDB data lives in the `carson_kb/` directory (or wherever `rag.persist_dir` points). This directory contains SQLite databases and parquet files.

### Option A: Commit to the repo (recommended for small KBs)

If your knowledge base is small (< 50MB), you can commit it:

```bash
# Make sure the KB is populated
python scripts/ingest_knowledge.py
python scripts/ingest_confluence.py --space AHTW

# Add to git
git add carson_kb/
git commit -m "Add Carson knowledge base"
```

Pros: Every team member gets the KB instantly on clone. No setup needed.
Cons: Increases repo size. Stale if not re-ingested periodically.

### Option B: Distribute as a zip artifact

```bash
# Create the KB artifact
zip -r carson_kb.zip carson_kb/

# Share via Bitbucket releases, Confluence, or team share drive
```

Team members download and extract to `./carson_kb/`.

### Option C: Each member ingests locally (recommended for large KBs)

Add ingestion to onboarding:

```bash
# Part of team onboarding
python scripts/setup-env.ps1
python scripts/ingest_knowledge.py
python scripts/ingest_confluence.py --space AHTW
python scripts/ingest_engineers_docs.py
```

Pros: Always fresh. No repo bloat.
Cons: Requires Confluence/docs access and takes time.

### Option D: Scheduled re-ingestion

Set up a cron job or Windows Task Scheduler to re-ingest periodically:

```bash
# Weekly Confluence re-ingest (cron example)
0 6 * * 1 cd /path/to/carson && python scripts/ingest_confluence.py --space AHTW --fresh
```

## Inspecting the Knowledge Base

You can inspect what's in your ChromaDB from Python:

```python
from carson_agents.rag.knowledge_base import CarsonKnowledgeBase

kb = CarsonKnowledgeBase(persist_dir="./carson_kb")

# List collections
print(kb.list_collections())
# ['repo_code', 'confluence_docs', 'engineers_docs']

# Count documents per collection
for coll in kb.list_collections():
    print(f"  {coll}: {kb.get_collection_count(coll)} chunks")

# Test a query
results = kb.query_multiple(
    "How does the AMPS messaging system work?",
    collection_names=kb.list_collections(),
    n_results=3,
)
for r in results[:5]:
    print(f"  [{r['collection']}] {r['metadata'].get('source', '?')}")
    print(f"    {r['text'][:100]}...")
    print()
```

## Troubleshooting

**"chromadb not installed"** — Run `pip install chromadb`

**"RAG is disabled in config.yaml"** — Set `rag.enabled: true` in `config.yaml`

**No results from queries** — Check that collections have data: `kb.get_collection_count("confluence_docs")`

**Stale data** — Re-ingest with `--fresh` flag to delete and rebuild the collection

**Large KB slow to start** — ChromaDB loads indexes on first query. Subsequent queries are fast. Consider reducing collection size by filtering pages during ingestion.

## Architecture Notes

- ChromaDB uses its built-in default embedding function (all-MiniLM-L6-v2 via sentence-transformers)
- If sentence-transformers is not installed, ChromaDB falls back to a simpler embedding
- For production use, consider installing sentence-transformers for better embedding quality:
  `pip install sentence-transformers`
- The knowledge base is completely optional. Carson works fine without it, the General Agent just won't have RAG context for answers.
