# ==============================================================================
# Carson AI Butler — Full Setup Script (PowerShell)
# ==============================================================================
# This is the ONLY script you need to run. It handles everything:
#   1. Extracts the zip (if needed)
#   2. Locates or clones MCP servers
#   3. Verifies VS Code + Copilot setup
#   4. (Optional) Sets up LangGraph/Bedrock for AHTW team
#
# Usage:
#   .\scripts\setup-carson.ps1                    # Interactive mode
#   .\scripts\setup-carson.ps1 -McpSource "C:\Users\F702937\mcp-servers"  # Specify MCP path
#   .\scripts\setup-carson.ps1 -Mode copilot      # Copilot-only (skip LangGraph)
#   .\scripts\setup-carson.ps1 -Mode full          # Full setup with LangGraph
# ==============================================================================

param(
    [string]$McpSource = "",
    [ValidateSet("copilot", "full", "")]
    [string]$Mode = "",
    [switch]$Force
)

$ErrorActionPreference = "Stop"

# --- Banner ---
function Write-Banner {
    Write-Host ""
    Write-Host "  ============================================================" -ForegroundColor Cyan
    Write-Host "                                                              " -ForegroundColor Cyan
    Write-Host "    CARSON AI BUTLER — Setup Wizard                           " -ForegroundColor Cyan
    Write-Host "    'At your service, Sir.'                                   " -ForegroundColor White
    Write-Host "                                                              " -ForegroundColor Cyan
    Write-Host "  ============================================================" -ForegroundColor Cyan
    Write-Host ""
}

function Write-Step {
    param([string]$Number, [string]$Title)
    Write-Host ""
    Write-Host "  --- Step $Number : $Title ---" -ForegroundColor Yellow
}

function Write-Ok {
    param([string]$Msg)
    Write-Host "    [OK] $Msg" -ForegroundColor Green
}

function Write-Warn {
    param([string]$Msg)
    Write-Host "    [!!] $Msg" -ForegroundColor Yellow
}

function Write-Err {
    param([string]$Msg)
    Write-Host "    [XX] $Msg" -ForegroundColor Red
}

function Ask-YN {
    param([string]$Prompt, [bool]$Default = $true)
    $suffix = if ($Default) { "[Y/n]" } else { "[y/N]" }
    $answer = Read-Host "    $Prompt $suffix"
    if ([string]::IsNullOrEmpty($answer)) { return $Default }
    return ($answer -match "^[yYsS]")
}

# ==============================================================================
Write-Banner

# --- Detect project root ---
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Split-Path -Parent $ScriptDir

# Check if we're inside the repo or if we need to guide extraction
if (-not (Test-Path (Join-Path $ProjectRoot ".github\copilot-instructions.md"))) {
    Write-Err "copilot-instructions.md not found. Are you running this from inside the Carson repo?"
    Write-Host "    Expected structure: high-touch-agent-prompts\scripts\setup-carson.ps1" -ForegroundColor White
    Write-Host ""
    Write-Host "    If you downloaded the zip, extract it first:" -ForegroundColor White
    Write-Host "    Expand-Archive high-touch-agent-prompts-v3.zip -DestinationPath high-touch-agent-prompts" -ForegroundColor White
    Write-Host "    cd high-touch-agent-prompts" -ForegroundColor White
    Write-Host "    .\scripts\setup-carson.ps1" -ForegroundColor White
    exit 1
}

Write-Host "  Project root: $ProjectRoot" -ForegroundColor Gray

# ==============================================================================
# STEP 1: Choose Mode
# ==============================================================================
Write-Step "1" "Choose Setup Mode"

if (-not $Mode) {
    Write-Host "    Carson has two modes:" -ForegroundColor White
    Write-Host ""
    Write-Host "    [1] Copilot-only  — For most users. No AWS, no API keys." -ForegroundColor White
    Write-Host "                        Copilot reads .github/copilot-instructions.md" -ForegroundColor Gray
    Write-Host "                        and agents/*.agent.md automatically." -ForegroundColor Gray
    Write-Host ""
    Write-Host "    [2] Full (Copilot + LangGraph) — For AHTW team with Bedrock access." -ForegroundColor White
    Write-Host "                        Adds multi-step planner, RAG, and orchestration." -ForegroundColor Gray
    Write-Host ""
    $modeChoice = Read-Host "    Enter 1 or 2"
    $Mode = if ($modeChoice -eq "2") { "full" } else { "copilot" }
}

if ($Mode -eq "full") {
    Write-Ok "Full mode selected (Copilot + LangGraph)"
} else {
    Write-Ok "Copilot-only mode selected"
}

# ==============================================================================
# STEP 2: Locate MCP Servers
# ==============================================================================
Write-Step "2" "Locate MCP Servers"

$mcpTarget = Join-Path $ProjectRoot "mcp-servers"
$requiredMcps = @(
    "jira-mcp-server-python",
    "bitbucket-mcp-server-python",
    "jenkins-mcp-server-python",
    "spinnaker-mcp-server-python",
    "confluence-mcp-server-python",
    "tfe-mcp-server-python",
    "engineers-docs-mcp-server-python"
)

if (Test-Path $mcpTarget) {
    Write-Host "    Found mcp-servers/ in project root." -ForegroundColor White
    $existingMcps = Get-ChildItem -Path $mcpTarget -Directory | Where-Object { $_.Name -match "mcp-server" }
    foreach ($mcp in $existingMcps) {
        Write-Ok $mcp.Name
    }
    $missing = $requiredMcps | Where-Object { -not (Test-Path (Join-Path $mcpTarget $_)) }
    if ($missing) {
        Write-Warn "Missing MCP servers:"
        foreach ($m in $missing) {
            Write-Host "      - $m" -ForegroundColor Yellow
        }
    }
} else {
    Write-Host "    No mcp-servers/ folder found in project." -ForegroundColor White
    Write-Host ""

    # Try to auto-detect common locations
    $commonPaths = @(
        (Join-Path (Split-Path $ProjectRoot -Parent) "mcp-servers"),
        "C:\Users\$env:USERNAME\workspace\mcp-servers",
        "C:\Users\$env:USERNAME\repos\mcp-servers",
        "D:\workspace\mcp-servers"
    )

    $foundPath = ""
    foreach ($path in $commonPaths) {
        if (Test-Path $path) {
            $foundPath = $path
            break
        }
    }

    if ($foundPath) {
        Write-Host "    Found MCP servers at: $foundPath" -ForegroundColor White
        if (Ask-YN "Copy MCP servers from there?") {
            $McpSource = $foundPath
        }
    }

    if (-not $McpSource) {
        Write-Host ""
        Write-Host "    Where are your MCP servers? Options:" -ForegroundColor White
        Write-Host "      [1] Enter the path where they are" -ForegroundColor White
        Write-Host "      [2] I'll clone them myself later" -ForegroundColor White
        Write-Host ""
        $mcpChoice = Read-Host "    Enter 1 or 2"

        if ($mcpChoice -eq "1") {
            $McpSource = Read-Host "    Full path to mcp-servers folder"
        }
    }

    if ($McpSource -and (Test-Path $McpSource)) {
        Write-Host "    Copying MCP servers..." -ForegroundColor White

        # Check if it's a flat folder with all servers or a parent folder
        $hasServers = Get-ChildItem -Path $McpSource -Directory | Where-Object { $_.Name -match "mcp-server" }

        if ($hasServers) {
            Copy-Item -Recurse $McpSource $mcpTarget
            Write-Ok "MCP servers copied to $mcpTarget"
        } else {
            Write-Err "No MCP server folders found in $McpSource"
            Write-Host "    Expected folders like: jira-mcp-server-python, bitbucket-mcp-server-python" -ForegroundColor Yellow
        }
    } else {
        Write-Warn "MCP servers not configured. You'll need to add them later."
        Write-Host "    Clone them into: $mcpTarget" -ForegroundColor Gray
        Write-Host "    Or create symlinks if they exist elsewhere." -ForegroundColor Gray
        New-Item -ItemType Directory -Path $mcpTarget -Force | Out-Null
    }
}

# ==============================================================================
# STEP 3: Verify VS Code / Copilot Configuration
# ==============================================================================
Write-Step "3" "Verify Copilot Configuration"

$copilotFile = Join-Path $ProjectRoot ".github\copilot-instructions.md"
$mcpJson = Join-Path $ProjectRoot ".vscode\mcp.json"
$agentsDir = Join-Path $ProjectRoot "agents"

if (Test-Path $copilotFile) {
    $fileSize = (Get-Item $copilotFile).Length / 1KB
    Write-Ok "copilot-instructions.md found ($([math]::Round($fileSize,1)) KB)"
} else {
    Write-Err "copilot-instructions.md NOT FOUND — Copilot won't know about Carson"
}

if (Test-Path $mcpJson) {
    Write-Ok "mcp.json found — MCP server configuration ready"
} else {
    Write-Err "mcp.json NOT FOUND — Copilot won't connect to MCP servers"
}

if (Test-Path $agentsDir) {
    $agentFiles = Get-ChildItem -Path $agentsDir -Filter "*.agent.md"
    Write-Ok "$($agentFiles.Count) agent files found:"
    foreach ($agent in $agentFiles) {
        $agentName = $agent.BaseName -replace '\.agent$', ''
        Write-Host "      - $agentName" -ForegroundColor Gray
    }
} else {
    Write-Err "agents/ directory NOT FOUND"
}

# Verify mcp.json paths match reality
if (Test-Path $mcpJson) {
    $mcpConfig = Get-Content $mcpJson -Raw | ConvertFrom-Json
    $servers = $mcpConfig.servers.PSObject.Properties
    Write-Host ""
    Write-Host "    MCP server status:" -ForegroundColor White
    foreach ($srv in $servers) {
        $cwd = $srv.Value.cwd -replace '\$\{workspaceFolder\}', $ProjectRoot
        if (Test-Path $cwd) {
            Write-Ok "$($srv.Name) → $cwd"
        } else {
            Write-Warn "$($srv.Name) → $cwd (NOT FOUND)"
        }
    }
}

# ==============================================================================
# STEP 4: LangGraph Setup (only in full mode)
# ==============================================================================
if ($Mode -eq "full") {
    Write-Step "4" "LangGraph / Bedrock Setup"

    $langGraphDir = Join-Path $ProjectRoot "langgraph-system"

    if (-not (Test-Path $langGraphDir)) {
        Write-Err "langgraph-system/ directory not found"
    } else {
        # Python check
        try {
            $pyVersion = & python --version 2>&1
            Write-Ok "Python found: $pyVersion"
        } catch {
            Write-Err "Python not found. Install Python 3.9+ for LangGraph mode."
        }

        # Install dependencies
        $reqFile = Join-Path $langGraphDir "requirements.txt"
        if (Test-Path $reqFile) {
            if (Ask-YN "Install Python dependencies from requirements.txt?") {
                Write-Host "    Installing..." -ForegroundColor White
                & python -m pip install -r $reqFile 2>&1 | Out-Null
                if ($LASTEXITCODE -eq 0) {
                    Write-Ok "Dependencies installed"
                } else {
                    Write-Warn "Some dependencies failed (CDAO SDK needs internal repo)"
                }
            }
        }

        # .env setup
        $envFile = Join-Path $langGraphDir ".env"
        $envExample = Join-Path $langGraphDir ".env.example"
        if (-not (Test-Path $envFile)) {
            if (Test-Path $envExample) {
                Copy-Item $envExample $envFile
                Write-Ok "Created .env from .env.example"
                Write-Warn "EDIT .env with your CDAO/Bedrock configuration!"
            }
        } else {
            Write-Ok ".env already exists"
        }

        # Onboarding wizard
        $configFile = Join-Path $langGraphDir "config.yaml"
        if (-not (Test-Path $configFile)) {
            if (Ask-YN "Run the Carson team configuration wizard?") {
                & python (Join-Path $langGraphDir "scripts\onboarding.py")
            } else {
                Write-Host "    Copy config_template.yaml to config.yaml and edit manually." -ForegroundColor Gray
            }
        } else {
            Write-Ok "config.yaml already exists"
        }

        # AWS reminder
        Write-Host ""
        Write-Warn "Don't forget to refresh AWS credentials before starting LangGraph:"
        Write-Host "      DevShell → pci aws login" -ForegroundColor Gray
    }
}

# ==============================================================================
# SUMMARY
# ==============================================================================
Write-Host ""
Write-Host "  ============================================================" -ForegroundColor Cyan
Write-Host "    Setup Complete!                                            " -ForegroundColor Green
Write-Host "  ============================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "  How to use Carson:" -ForegroundColor White
Write-Host ""
Write-Host "    1. Open this folder in VS Code:" -ForegroundColor White
Write-Host "       code $ProjectRoot" -ForegroundColor Gray
Write-Host ""
Write-Host "    2. Open Copilot Chat (Ctrl+Shift+I)" -ForegroundColor White
Write-Host "       Carson is already active — just ask him anything!" -ForegroundColor Gray
Write-Host ""
Write-Host "    3. Try:" -ForegroundColor White
Write-Host '       "Carson, show me the open bugs in this sprint"' -ForegroundColor Gray
Write-Host '       "Carson, create a branch for CREDITTECH-456"' -ForegroundColor Gray
Write-Host '       "Carson, check the last Jenkins build"' -ForegroundColor Gray
Write-Host ""

if ($Mode -eq "full") {
    Write-Host "  LangGraph mode (optional):" -ForegroundColor White
    Write-Host "    cd langgraph-system" -ForegroundColor Gray
    Write-Host "    python carson_service.py" -ForegroundColor Gray
    Write-Host ""
}

Write-Host "  Need help? Ask Carson: 'What can you do?'" -ForegroundColor White
Write-Host ""
