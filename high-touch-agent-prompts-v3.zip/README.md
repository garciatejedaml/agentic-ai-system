# Carson AI Butler — Multi-Agent System for JPMC Teams

Carson is an AI butler that works through **GitHub Copilot** to help development teams manage their workflow across Jira, Bitbucket, Jenkins, Spinnaker, Confluence, and Terraform Enterprise.

## Quick Start (Copilot Mode — No Bedrock Needed)

1. Clone this repo into your workspace
2. Open VS Code with GitHub Copilot enabled
3. Copilot reads `.github/copilot-instructions.md` automatically
4. Configure MCP servers in `.vscode/mcp.json` (edit paths to match your setup)
5. Start chatting with Copilot — Carson is ready

That's it. No API keys, no AWS Bedrock, no Python service needed.

## How It Works

```
User types in Copilot Chat
       |
       v
Copilot reads .github/copilot-instructions.md
(Carson persona + routing rules)
       |
       v
Copilot identifies the right agent (agents/*.agent.md)
       |
       v
Agent uses MCP tools (configured in .vscode/mcp.json)
to interact with Jira, Bitbucket, Jenkins, etc.
       |
       v
Carson responds with results
```

## Specialists

| Agent | Name | What They Do |
|---|---|---|
| Jira | Comptroller Jira | Tickets, sprints, stories, status transitions |
| Git | Mr. Brandson | Repos, branches, PRs, commits, code review |
| Build | M. Jenkins | CI/CD builds, logs, test results |
| Deploy | Madame Spinnaker | Deployments, rollbacks, environment status |
| Terraform | M. Terraform Inspector | TFE workspaces, plans, state, AWS resources |
| Docs | Secretary Confluence | Page search, creation, documentation |
| General | Inspector Clouseau | AMPS, AWS concepts, team knowledge |

## For Teams With AWS Bedrock Access (Optional)

If your team has CDAO SDK / Bedrock access, you can run the **LangGraph service** for enhanced capabilities:

- Multi-step agent orchestration with memory
- ChromaDB RAG for knowledge-base queries (Confluence, internal docs)
- Conversation history across requests
- Quality inspection node

```bash
cd langgraph-system/
python scripts/onboarding.py    # Interactive setup
python carson_service.py         # Start the service
```

See `langgraph-system/` and `docs/rag-knowledge-base.md` for details.

## Using This for Other Teams

This repo is designed to be team-agnostic. To onboard a new team:

1. Fork or clone this repo
2. Edit the team-specific values:
   - `.github/copilot-instructions.md` — update team name, project keys, routing keywords
   - `.vscode/mcp.json` — update MCP server paths
   - `skills/` — add your team's domain knowledge
   - `agents/*.agent.md` — customize agent personas if desired
3. If using LangGraph: `cp langgraph-system/config_template.yaml langgraph-system/config.yaml` and fill in your team's details

The agents, skills, and MCP tools are all generic. The only team-specific parts are configuration values.

## Repository Structure

```
high-touch-agent-prompts/
├── .github/
│   └── copilot-instructions.md    ← Main entry point (Copilot reads this)
├── agents/                         ← Agent persona definitions
│   ├── carson-concierge.agent.md  ← Router / main Carson persona
│   ├── jira.agent.md
│   ├── git.agent.md
│   ├── build.agent.md
│   ├── deploy.agent.md
│   ├── docs.agent.md
│   ├── terraform.agent.md
│   └── general.agent.md
├── skills/                         ← Domain knowledge per agent
│   ├── git/pr_conventions.md
│   ├── build/jenkins_patterns.md
│   ├── deploy/spinnaker_mappings.md
│   ├── docs/confluence_patterns.md
│   ├── terraform/infrastructure_patterns.md
│   ├── jira/ticket_conventions.md
│   └── general/
│       ├── amps_knowledge.md
│       └── aws_concepts.md
├── .vscode/
│   └── mcp.json                    ← MCP server configuration
├── scripts/
│   ├── setup-env.ps1              ← Windows VDI environment setup
│   ├── refresh-aws.ps1            ← AWS credential refresh helper
│   └── sync-to-root.ps1          ← Sync .github to workspace root
├── docs/
│   └── rag-knowledge-base.md      ← ChromaDB RAG documentation
└── langgraph-system/               ← OPTIONAL: Python LangGraph service
    ├── config.yaml                ← Team configuration
    ├── carson_service.py          ← Flask HTTP service
    ├── carson_agents/             ← Python agent implementations
    │   ├── agents/                ← 7 specialist agents
    │   ├── router/                ← LLM-based routing
    │   ├── llm/                   ← Provider-agnostic LLM (Bedrock + Anthropic)
    │   ├── rag/                   ← ChromaDB knowledge base
    │   └── skills/                ← Skill loader
    └── scripts/
        ├── onboarding.py          ← Interactive setup wizard
        ├── ingest_knowledge.py    ← RAG: ingest repo files
        ├── ingest_confluence.py   ← RAG: ingest Confluence pages
        └── ingest_engineers_docs.py ← RAG: ingest internal JPMC docs
```

## MCP Servers Required

These MCP servers must be cloned alongside this repo:
- `jira-mcp-server-python`
- `bitbucket-mcp-server-python` (camelCase tools)
- `jenkins-mcp-server-python` (camelCase tools)
- `spinnaker-mcp-server-python`
- `confluence-mcp-server-python`
- `tfe-mcp-server-python`
- `engineers-docs-mcp-server-python` (optional)

Set `PYNETA_PROFILE=local` in your environment for authentication.
